# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Compendium",
    "author" : "Ben Ikeler", 
    "description" : "",
    "blender" : (4, 3, 0),
    "version" : (3, 13, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import bmesh
from bpy.app.handlers import persistent
import os
import math
from mathutils import Vector


addon_keymaps = {}
_icons = None
general_fns = {'sna_objectlist': [], 'sna_unselected': [], 'sna_rotamount': 0.0, }
mirrorempty = {'sna_objectname': '', 'sna_newempty': '', 'sna_foundobject': False, 'sna_modname': '', }
pie__sculpt = {'sna_brushpath': '', }


def find_user_keyconfig(key):
    km, kmi = addon_keymaps[key]
    for item in bpy.context.window_manager.keyconfigs.user.keymaps[km.name].keymap_items:
        found_item = False
        if kmi.idname == item.idname:
            found_item = True
            for name in dir(kmi.properties):
                if not name in ["bl_rna", "rna_type"] and not name[0] == "_":
                    if name in kmi.properties and name in item.properties and not kmi.properties[name] == item.properties[name]:
                        found_item = False
        if found_item:
            return item
    print(f"Couldn't find keymap item for {key}, using addon keymap instead. This won't be saved across sessions!")
    return kmi


movetocollection_s3_vars_20F20 = {
'sna_objectstomove': [], 
'sna_collectiontoreturn': None, 
'sna_newcollectioncreated': False, 
}


def sna_moveobjectstocollection_397D9_20F20(CollectionName, ListOfOjbects):
    if (len(ListOfOjbects) > 0):
        if property_exists("bpy.data.collections[CollectionName]", globals(), locals()):
            sna_fnlinkunlink_41AEA(CollectionName, ListOfOjbects)
            movetocollection_s3_vars_20F20['sna_collectiontoreturn'] = bpy.data.collections[CollectionName]
            movetocollection_s3_vars_20F20['sna_newcollectioncreated'] = False
        else:
            collection_752A1 = bpy.data.collections.new(name=CollectionName, )
            bpy.context.scene.collection.children.link(child=collection_752A1, )
            sna_fnlinkunlink_41AEA(CollectionName, ListOfOjbects)
            movetocollection_s3_vars_20F20['sna_collectiontoreturn'] = collection_752A1
            movetocollection_s3_vars_20F20['sna_newcollectioncreated'] = True
        return [movetocollection_s3_vars_20F20['sna_collectiontoreturn'], movetocollection_s3_vars_20F20['sna_newcollectioncreated']]


localhidecollection_vars_04E8B = {
'sna_iscollectionfound': False, 
'sna_foundcollection': None, 
}


def sna_hidecollectioninviewport_32E38_04E8B(CollectionName, Options):
    localhidecollection_vars_04E8B['sna_iscollectionfound'] = False
    localhidecollection_vars_04E8B['sna_foundcollection'] = None
    for i_99DD9 in range(len(bpy.data.collections)):
        if (bpy.data.collections[i_99DD9].name == CollectionName):
            localhidecollection_vars_04E8B['sna_iscollectionfound'] = True
            localhidecollection_vars_04E8B['sna_foundcollection'] = bpy.data.collections[i_99DD9]
            break
    if localhidecollection_vars_04E8B['sna_iscollectionfound']:
        if Options == "Local":
            sna_hidelocal_4CC08(CollectionName)
        elif Options == "Global":
            sna_hideglobal_430FD(localhidecollection_vars_04E8B['sna_foundcollection'])
        elif Options == "Both":
            sna_hidelocal_4CC08(CollectionName)
            sna_hideglobal_430FD(localhidecollection_vars_04E8B['sna_foundcollection'])
        else:
            pass


movetocollection_s3_vars_63B66 = {
'sna_objectstomove': [], 
}


def sna_moveobjectstocollection_397D9_63B66(CollectionName, ListOfOjbects):
    if (len(ListOfOjbects) > 0):
        if property_exists("bpy.data.collections[CollectionName]", globals(), locals()):
            sna_fnlinkunlink_41AEA(CollectionName, ListOfOjbects)
            return bpy.data.collections[CollectionName]
        else:
            collection_752A1 = bpy.data.collections.new(name=CollectionName, )
            bpy.context.scene.collection.children.link(child=collection_752A1, )
            sna_fnlinkunlink_41AEA(CollectionName, ListOfOjbects)
            return collection_752A1


localhidecollection_vars_F9EA4 = {
'sna_iscollectionfound': False, 
'sna_foundcollection': None, 
}


def sna_hidecollectioninviewport_32E38_F9EA4(CollectionName, Options):
    localhidecollection_vars_F9EA4['sna_iscollectionfound'] = False
    localhidecollection_vars_F9EA4['sna_foundcollection'] = None
    for i_99DD9 in range(len(bpy.data.collections)):
        if (bpy.data.collections[i_99DD9].name == CollectionName):
            localhidecollection_vars_F9EA4['sna_iscollectionfound'] = True
            localhidecollection_vars_F9EA4['sna_foundcollection'] = bpy.data.collections[i_99DD9]
            break
    if localhidecollection_vars_F9EA4['sna_iscollectionfound']:
        if Options == "Local":
            sna_hidelocal_4CC08(CollectionName)
        elif Options == "Global":
            sna_hideglobal_430FD(localhidecollection_vars_F9EA4['sna_foundcollection'])
        elif Options == "Both":
            sna_hidelocal_4CC08(CollectionName)
            sna_hideglobal_430FD(localhidecollection_vars_F9EA4['sna_foundcollection'])
        else:
            pass


def sna_hidelocal_4CC08(CollectionName):
    exec("bpy.context.view_layer.layer_collection.children.get('Your_Collection_Name').hide_viewport = True".replace('Your_Collection_Name', CollectionName))


def sna_hideglobal_430FD(Collection):
    Collection.hide_viewport = True


movetocollection_s3_vars_58084 = {
'sna_objectstomove': [], 
}


def sna_moveobjectstocollection_397D9_58084(CollectionName, ListOfOjbects):
    if (len(ListOfOjbects) > 0):
        if property_exists("bpy.data.collections[CollectionName]", globals(), locals()):
            sna_fnlinkunlink_41AEA(CollectionName, ListOfOjbects)
            return bpy.data.collections[CollectionName]
        else:
            collection_752A1 = bpy.data.collections.new(name=CollectionName, )
            bpy.context.scene.collection.children.link(child=collection_752A1, )
            sna_fnlinkunlink_41AEA(CollectionName, ListOfOjbects)
            return collection_752A1


def sna_fnlinkunlink_41AEA(CollectionName, ListOfObjects):
    movetocollection_s3_vars_58084['sna_objectstomove'] = []
    for i_5B107 in range(len(ListOfObjects)):
        movetocollection_s3_vars_58084['sna_objectstomove'].append(ListOfObjects[i_5B107])
    for i_18D5A in range(len(ListOfObjects)):
        for i_BE9A3 in range(len(ListOfObjects[i_18D5A].users_collection)):
            if (ListOfObjects[i_18D5A].users_collection[i_BE9A3].name == CollectionName):
                movetocollection_s3_vars_58084['sna_objectstomove'].remove(ListOfObjects[i_18D5A])
    for i_EC7E0 in range(len(movetocollection_s3_vars_58084['sna_objectstomove'])):
        for i_726C8 in range(len(movetocollection_s3_vars_58084['sna_objectstomove'][i_EC7E0].users_collection)):
            movetocollection_s3_vars_58084['sna_objectstomove'][i_EC7E0].users_collection[i_726C8].objects.unlink(object=movetocollection_s3_vars_58084['sna_objectstomove'][i_EC7E0], )
    for i_9A186 in range(len(movetocollection_s3_vars_58084['sna_objectstomove'])):
        bpy.data.collections[CollectionName].objects.link(object=movetocollection_s3_vars_58084['sna_objectstomove'][i_9A186], )


def find_areas_of_type(screen, area_type):
    areas = []
    for area in screen.areas:
        if area.type == area_type:
            areas.append(area)
    return areas


def sna_getobjectproperty_427FF_5BA5F(ObjectName):
    return bpy.data.objects[ObjectName]


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


def sna_add_to_dopesheet_mt_editor_menus_3436A(self, context):
    if not (False):
        layout = self.layout
        row_A79BE = layout.row(heading='', align=False)
        row_A79BE.alert = False
        row_A79BE.enabled = True
        row_A79BE.active = True
        row_A79BE.use_property_split = False
        row_A79BE.use_property_decorate = False
        row_A79BE.scale_x = 1.0
        row_A79BE.scale_y = 1.0
        row_A79BE.alignment = 'Expand'.upper()
        row_A79BE.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_A79BE.operator('sna.add_new_action_9e4b3', text='New Action', icon_value=31, emboss=True, depress=False)


class SNA_OT_Add_New_Action_9E4B3(bpy.types.Operator):
    bl_idname = "sna.add_new_action_9e4b3"
    bl_label = "Add New Action"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnaddaction_FD1E9()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnaddaction_FD1E9():
    action_50A59 = bpy.data.actions.new(name='NewAction', )
    action_50A59.use_fake_user = True
    if property_exists("bpy.context.view_layer.objects.active.animation_data", globals(), locals()):
        bpy.context.view_layer.objects.active.animation_data.action = action_50A59
    else:
        anim_data_B61DC = bpy.context.view_layer.objects.active.animation_data_create()
        bpy.context.view_layer.objects.active.animation_data.action = action_50A59


class SNA_PT_COMPENDIUM_00470(bpy.types.Panel):
    bl_label = 'Compendium'
    bl_idname = 'SNA_PT_COMPENDIUM_00470'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_83AF6 = layout.column(heading='', align=False)
        col_83AF6.alert = False
        col_83AF6.enabled = True
        col_83AF6.active = True
        col_83AF6.use_property_split = False
        col_83AF6.use_property_decorate = False
        col_83AF6.scale_x = 1.0
        col_83AF6.scale_y = 1.0
        col_83AF6.alignment = 'Expand'.upper()
        col_83AF6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_FC6E1 = col_83AF6.row(heading='', align=False)
        row_FC6E1.alert = False
        row_FC6E1.enabled = True
        row_FC6E1.active = True
        row_FC6E1.use_property_split = False
        row_FC6E1.use_property_decorate = False
        row_FC6E1.scale_x = 1.0
        row_FC6E1.scale_y = 1.0
        row_FC6E1.alignment = 'Expand'.upper()
        row_FC6E1.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_FC6E1.label(text='Control Panel', icon_value=0)
        row_17323 = row_FC6E1.row(heading='', align=False)
        row_17323.alert = False
        row_17323.enabled = True
        row_17323.active = True
        row_17323.use_property_split = False
        row_17323.use_property_decorate = False
        row_17323.scale_x = 1.0
        row_17323.scale_y = 1.0
        row_17323.alignment = 'Right'.upper()
        row_17323.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_17323.operator('sna.toggle_settings_04ec7', text='', icon_value=140, emboss=True, depress=bpy.context.scene.sna_showrendersettings)
        split_70E87 = col_83AF6.split(factor=0.5, align=True)
        split_70E87.alert = False
        split_70E87.enabled = True
        split_70E87.active = True
        split_70E87.use_property_split = False
        split_70E87.use_property_decorate = False
        split_70E87.scale_x = 1.0
        split_70E87.scale_y = 1.0
        split_70E87.alignment = 'Expand'.upper()
        if not True: split_70E87.operator_context = "EXEC_DEFAULT"
        op = split_70E87.operator('sna.toggle_tools_f006f', text='', icon_value=117, emboss=True, depress=bpy.context.scene.sna_showtools)
        op = split_70E87.operator('sna.toggle_workflow_panel_c058b', text='', icon_value=284, emboss=True, depress=bpy.context.scene.sna_showworkflow)
        split_EDA05 = col_83AF6.split(factor=1.0, align=True)
        split_EDA05.alert = False
        split_EDA05.enabled = True
        split_EDA05.active = True
        split_EDA05.use_property_split = False
        split_EDA05.use_property_decorate = False
        split_EDA05.scale_x = 1.0
        split_EDA05.scale_y = 1.0
        split_EDA05.alignment = 'Expand'.upper()
        if not True: split_EDA05.operator_context = "EXEC_DEFAULT"
        op = split_EDA05.operator('sna.toggle_item_info_b0c71', text='', icon_value=133, emboss=True, depress=bpy.context.scene.sna_showiteminfo)


class SNA_OT_Toggle_Tools_F006F(bpy.types.Operator):
    bl_idname = "sna.toggle_tools_f006f"
    bl_label = "Toggle Tools"
    bl_description = "Show Tools Panel"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showtools = (not bpy.context.scene.sna_showtools)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Settings_04Ec7(bpy.types.Operator):
    bl_idname = "sna.toggle_settings_04ec7"
    bl_label = "Toggle Settings"
    bl_description = "Show Settings Panel"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showrendersettings = (not bpy.context.scene.sna_showrendersettings)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Item_Info_B0C71(bpy.types.Operator):
    bl_idname = "sna.toggle_item_info_b0c71"
    bl_label = "Toggle Item Info"
    bl_description = "Show Item Info Panel"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showiteminfo = (not bpy.context.scene.sna_showiteminfo)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Workflow_Panel_C058B(bpy.types.Operator):
    bl_idname = "sna.toggle_workflow_panel_c058b"
    bl_label = "Toggle Workflow Panel"
    bl_description = "Show  Workflow Panel"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showworkflow = (not bpy.context.scene.sna_showworkflow)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_MT_A3D1B(bpy.types.Menu):
    bl_idname = "SNA_MT_A3D1B"
    bl_label = "Compendium"

    @classmethod
    def poll(cls, context):
        return not ((not ('OBJECT'==bpy.context.mode or 'EDIT_MESH'==bpy.context.mode)))

    def draw(self, context):
        layout = self.layout.menu_pie()
        if 'EDIT_MESH'==bpy.context.mode:
            if bpy.context.tool_settings.mesh_select_mode[0]:
                op = layout.operator('mesh.dissolve_verts', text='Dissolve Verts', icon_value=0, emboss=True, depress=False)
            else:
                if bpy.context.tool_settings.mesh_select_mode[1]:
                    op = layout.operator('mesh.dissolve_edges', text='Dissolve Edges', icon_value=0, emboss=True, depress=False)
                    op.use_verts = True
                else:
                    op = layout.operator('mesh.delete', text='Delete Faces Only', icon_value=0, emboss=True, depress=False)
                    op.type = 'ONLY_FACE'
        else:
            op = layout.operator('sna.set_orientation_local_059e9', text='Local', icon_value=578, emboss=True, depress=False)
        if 'OBJECT'==bpy.context.mode:
            row_D0581 = layout.row(heading='', align=False)
            row_D0581.alert = False
            row_D0581.enabled = True
            row_D0581.active = True
            row_D0581.use_property_split = False
            row_D0581.use_property_decorate = False
            row_D0581.scale_x = 1.0
            row_D0581.scale_y = 1.0
            row_D0581.alignment = 'Expand'.upper()
            row_D0581.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            box_A45EB = row_D0581.box()
            box_A45EB.alert = False
            box_A45EB.enabled = True
            box_A45EB.active = True
            box_A45EB.use_property_split = False
            box_A45EB.use_property_decorate = False
            box_A45EB.alignment = 'Expand'.upper()
            box_A45EB.scale_x = 1.0
            box_A45EB.scale_y = 1.0
            if not True: box_A45EB.operator_context = "EXEC_DEFAULT"
            col_E2851 = box_A45EB.column(heading='', align=False)
            col_E2851.alert = False
            col_E2851.enabled = True
            col_E2851.active = True
            col_E2851.use_property_split = False
            col_E2851.use_property_decorate = False
            col_E2851.scale_x = 1.0
            col_E2851.scale_y = 1.0
            col_E2851.alignment = 'Expand'.upper()
            col_E2851.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_E2851.operator('sna.show_ops_f6c25', text='', icon_value=(96 if bpy.context.scene.sna_showops else 97), emboss=bpy.context.scene.sna_showops, depress=bpy.context.scene.sna_showops)
            op = col_E2851.operator('object.move_to_collection', text='', icon_value=235, emboss=False, depress=False)
            if bpy.context.scene.sna_showops:
                box_BE977 = row_D0581.box()
                box_BE977.alert = False
                box_BE977.enabled = True
                box_BE977.active = True
                box_BE977.use_property_split = False
                box_BE977.use_property_decorate = False
                box_BE977.alignment = 'Expand'.upper()
                box_BE977.scale_x = 1.0
                box_BE977.scale_y = 1.0
                if not True: box_BE977.operator_context = "EXEC_DEFAULT"
                col_63BC5 = box_BE977.column(heading='', align=True)
                col_63BC5.alert = False
                col_63BC5.enabled = True
                col_63BC5.active = True
                col_63BC5.use_property_split = False
                col_63BC5.use_property_decorate = False
                col_63BC5.scale_x = 1.0
                col_63BC5.scale_y = 1.0
                col_63BC5.alignment = 'Expand'.upper()
                col_63BC5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_15F16 = col_63BC5.row(heading='', align=True)
                row_15F16.alert = False
                row_15F16.enabled = True
                row_15F16.active = True
                row_15F16.use_property_split = False
                row_15F16.use_property_decorate = False
                row_15F16.scale_x = 1.2000000476837158
                row_15F16.scale_y = 1.2000000476837158
                row_15F16.alignment = 'Expand'.upper()
                row_15F16.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                op = row_15F16.operator('sna.mirror_empty_f8d10', text='', icon_value=309, emboss=True, depress=False)
                if bpy.context.view_layer.objects.active.type == 'MESH':
                    op = row_15F16.operator('object.modifier_add', text='', icon_value=451, emboss=True, depress=False)
                    op.type = 'MIRROR'
                op = row_15F16.operator('sna.send_selectedto_backup_5ac5a', text='', icon_value=625, emboss=True, depress=False)
                row_ADCEE = col_63BC5.row(heading='', align=True)
                row_ADCEE.alert = False
                row_ADCEE.enabled = True
                row_ADCEE.active = True
                row_ADCEE.use_property_split = False
                row_ADCEE.use_property_decorate = False
                row_ADCEE.scale_x = 1.2000000476837158
                row_ADCEE.scale_y = 1.2000000476837158
                row_ADCEE.alignment = 'Expand'.upper()
                row_ADCEE.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                op = row_ADCEE.operator('sna.duplicate_send_to_backup_8be30', text='', icon_value=62, emboss=True, depress=False)
        else:
            op = layout.operator('mesh.vert_connect_path', text='Join', icon_value=0, emboss=True, depress=False)
        if 'EDIT_MESH'==bpy.context.mode:
            if sna_fngetactive_F6274():
                op = layout.operator('mesh.merge', text='At Last', icon_value=0, emboss=True, depress=False)
                op.type = 'LAST'
            else:
                if bpy.context.tool_settings.mesh_select_mode[2]:
                    op = layout.operator('mesh.select_linked', text='Select Linked', icon_value=0, emboss=True, depress=False)
                else:
                    layout.separator(factor=1.0)
        else:
            op = layout.operator('sna.set_orientation_global_52453', text='Global', icon_value=577, emboss=True, depress=False)
        if 'OBJECT'==bpy.context.mode:
            layout.prop(bpy.data.scenes['Scene'].tool_settings, 'use_snap', text='', icon_value=0, emboss=True)
        else:
            row_3550D = layout.row(heading='', align=True)
            row_3550D.alert = False
            row_3550D.enabled = True
            row_3550D.active = True
            row_3550D.use_property_split = False
            row_3550D.use_property_decorate = False
            row_3550D.scale_x = 1.2000000476837158
            row_3550D.scale_y = 1.5
            row_3550D.alignment = 'Expand'.upper()
            row_3550D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_3550D.prop(bpy.data.scenes['Scene'].tool_settings, 'use_mesh_automerge', text='', icon_value=0, emboss=True)
            row_3550D.prop(bpy.data.scenes['Scene'].tool_settings, 'use_proportional_edit', text='', icon_value=0, emboss=True)
            row_3550D.prop(bpy.data.scenes['Scene'].tool_settings, 'use_snap', text='', icon_value=0, emboss=True)
        col_68C1A = layout.column(heading='', align=False)
        col_68C1A.alert = False
        col_68C1A.enabled = True
        col_68C1A.active = True
        col_68C1A.use_property_split = False
        col_68C1A.use_property_decorate = False
        col_68C1A.scale_x = 1.0
        col_68C1A.scale_y = 1.0
        col_68C1A.alignment = 'Expand'.upper()
        col_68C1A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_AC21F = col_68C1A.row(heading='', align=True)
        row_AC21F.alert = False
        row_AC21F.enabled = True
        row_AC21F.active = True
        row_AC21F.use_property_split = False
        row_AC21F.use_property_decorate = False
        row_AC21F.scale_x = 1.2000000476837158
        row_AC21F.scale_y = 1.5
        row_AC21F.alignment = 'Expand'.upper()
        row_AC21F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_AC21F.operator('sna.set_orientation_global_52453', text='', icon_value=577, emboss=True, depress=False)
        op = row_AC21F.operator('sna.set_orientation_local_059e9', text='', icon_value=578, emboss=True, depress=False)
        op = row_AC21F.operator('sna.set_orientation_normal_b13bc', text='', icon_value=579, emboss=True, depress=False)
        row_33CC2 = col_68C1A.row(heading='', align=True)
        row_33CC2.alert = False
        row_33CC2.enabled = True
        row_33CC2.active = True
        row_33CC2.use_property_split = False
        row_33CC2.use_property_decorate = False
        row_33CC2.scale_x = 1.2000000476837158
        row_33CC2.scale_y = 1.5
        row_33CC2.alignment = 'Expand'.upper()
        row_33CC2.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_33CC2.operator('sna.transform_pivot_individual_ea6e3', text='', icon_value=549, emboss=True, depress=False)
        op = row_33CC2.operator('sna.transform_pivot_cursor_4cdc9', text='', icon_value=548, emboss=True, depress=False)
        op = row_33CC2.operator('sna.transform_pivot_median_dfa9e', text='', icon_value=550, emboss=True, depress=False)
        if 'OBJECT'==bpy.context.mode:
            box_CFA38 = layout.box()
            box_CFA38.alert = False
            box_CFA38.enabled = True
            box_CFA38.active = True
            box_CFA38.use_property_split = False
            box_CFA38.use_property_decorate = False
            box_CFA38.alignment = 'Expand'.upper()
            box_CFA38.scale_x = 1.0
            box_CFA38.scale_y = 1.0
            if not True: box_CFA38.operator_context = "EXEC_DEFAULT"
            col_8863B = box_CFA38.column(heading='', align=True)
            col_8863B.alert = False
            col_8863B.enabled = True
            col_8863B.active = True
            col_8863B.use_property_split = False
            col_8863B.use_property_decorate = False
            col_8863B.scale_x = 1.0
            col_8863B.scale_y = 1.0
            col_8863B.alignment = 'Expand'.upper()
            col_8863B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_247FC = col_8863B.row(heading='', align=True)
            row_247FC.alert = False
            row_247FC.enabled = True
            row_247FC.active = True
            row_247FC.use_property_split = False
            row_247FC.use_property_decorate = False
            row_247FC.scale_x = 1.2000000476837158
            row_247FC.scale_y = 1.2000000476837158
            row_247FC.alignment = 'Expand'.upper()
            row_247FC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_247FC.operator('sna.add_single_vert_bfe7d', text='', icon_value=58, emboss=True, depress=False)
            op = row_247FC.operator('sna.add_edge_2ddef', text='', icon_value=567, emboss=True, depress=False)
            op = row_247FC.operator('sna.add_bezier_pipe_e6f6d', text='', icon_value=259, emboss=True, depress=False)
            row_9BDF4 = col_8863B.row(heading='', align=True)
            row_9BDF4.alert = False
            row_9BDF4.enabled = True
            row_9BDF4.active = True
            row_9BDF4.use_property_split = False
            row_9BDF4.use_property_decorate = False
            row_9BDF4.scale_x = 1.2000000476837158
            row_9BDF4.scale_y = 1.2000000476837158
            row_9BDF4.alignment = 'Expand'.upper()
            row_9BDF4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_9BDF4.operator('sna.add_bezier_rectangle_f8009', text='', icon_value=199, emboss=True, depress=False)
            op = row_9BDF4.operator('sna.add_empty_curve_43edf', text='', icon_value=70, emboss=True, depress=False)
            op = row_9BDF4.operator('sna.add_square_curve_6290e', text='', icon_value=681, emboss=True, depress=False)
        else:
            box_7F50B = layout.box()
            box_7F50B.alert = False
            box_7F50B.enabled = True
            box_7F50B.active = True
            box_7F50B.use_property_split = False
            box_7F50B.use_property_decorate = False
            box_7F50B.alignment = 'Expand'.upper()
            box_7F50B.scale_x = 1.0
            box_7F50B.scale_y = 1.0
            if not True: box_7F50B.operator_context = "EXEC_DEFAULT"
            col_C9B5A = box_7F50B.column(heading='', align=False)
            col_C9B5A.alert = False
            col_C9B5A.enabled = True
            col_C9B5A.active = True
            col_C9B5A.use_property_split = False
            col_C9B5A.use_property_decorate = False
            col_C9B5A.scale_x = 1.0
            col_C9B5A.scale_y = 1.0
            col_C9B5A.alignment = 'Expand'.upper()
            col_C9B5A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_A5A46 = col_C9B5A.row(heading='', align=True)
            row_A5A46.alert = False
            row_A5A46.enabled = True
            row_A5A46.active = True
            row_A5A46.use_property_split = False
            row_A5A46.use_property_decorate = False
            row_A5A46.scale_x = 1.0
            row_A5A46.scale_y = 1.0
            row_A5A46.alignment = 'Expand'.upper()
            row_A5A46.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_A5A46.operator('mesh.knife_tool', text='', icon_value=456, emboss=True, depress=False)
            op.use_occlude_geometry = True
            op.xray = True
        if 'OBJECT'==bpy.context.mode:
            col_679D0 = layout.column(heading='', align=False)
            col_679D0.alert = False
            col_679D0.enabled = True
            col_679D0.active = True
            col_679D0.use_property_split = False
            col_679D0.use_property_decorate = False
            col_679D0.scale_x = 1.0
            col_679D0.scale_y = 1.0
            col_679D0.alignment = 'Expand'.upper()
            col_679D0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_679D0.label(text='Special Show/Hide', icon_value=0)
            split_3FF7B = col_679D0.split(factor=0.5, align=True)
            split_3FF7B.alert = False
            split_3FF7B.enabled = True
            split_3FF7B.active = True
            split_3FF7B.use_property_split = False
            split_3FF7B.use_property_decorate = False
            split_3FF7B.scale_x = 1.0
            split_3FF7B.scale_y = 1.2000000476837158
            split_3FF7B.alignment = 'Expand'.upper()
            if not True: split_3FF7B.operator_context = "EXEC_DEFAULT"
            op = split_3FF7B.operator('sna.special_hide_unselected_29928', text='Unselected', icon_value=12, emboss=True, depress=False)
            op = split_3FF7B.operator('sna.special_hide_selected_1c458', text='Selected', icon_value=12, emboss=True, depress=False)
            op = col_679D0.operator('sna.special_show_all_7e124', text='Show All', icon_value=13, emboss=True, depress=False)
        else:
            if bpy.context.tool_settings.mesh_select_mode[0]:
                op = layout.operator('transform.vert_slide', text='Slide Vert', icon_value=0, emboss=True, depress=False)
            else:
                layout.separator(factor=1.0)
        op = layout.operator('view3d.view_selected', text='', icon_value=101, emboss=True, depress=False)


def sna_fngetactive_F6274():
    me = bpy.context.active_object.data
    has_active = None
    bm = bmesh.from_edit_mesh(me)
    has_active
    for elem in reversed(bm.select_history):
        if isinstance(elem, bmesh.types.BMVert):
            has_active = True
            print(has_active)
            return has_active
        else:
            has_active = False
            return has_active
    return has_active


class SNA_OT_Forgotten_Tools_Link_F1Fdb(bpy.types.Operator):
    bl_idname = "sna.forgotten_tools_link_f1fdb"
    bl_label = "Forgotten Tools Link"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('bpy.ops.wm.url_open(url="https://stanpancakes.gumroad.com/l/JJNfR")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Edge_Flow_Link_Fd608(bpy.types.Operator):
    bl_idname = "sna.edge_flow_link_fd608"
    bl_label = "Edge Flow Link"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('bpy.ops.wm.url_open(url="https://github.com/BenjaminSauder/EdgeFlow/releases")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_AddonPreferences_63B78(bpy.types.AddonPreferences):
    bl_idname = __package__

    def draw(self, context):
        if not (False):
            layout = self.layout 
            layout.label(text='Keyboard Shortcuts', icon_value=0)
            layout.prop(find_user_keyconfig('74368'), 'type', text='Compendium Pie Menu', full_event=True)
            layout.prop(find_user_keyconfig('9C020'), 'type', text='Modes Pie Menu', full_event=True)
            layout.prop(find_user_keyconfig('3EA7D'), 'type', text='Sculpt Pie Menu', full_event=True)
            layout.prop(find_user_keyconfig('ADF2F'), 'type', text='Emulate Mouse 3', full_event=True)
            box_1A4F1 = layout.box()
            box_1A4F1.alert = False
            box_1A4F1.enabled = True
            box_1A4F1.active = True
            box_1A4F1.use_property_split = False
            box_1A4F1.use_property_decorate = False
            box_1A4F1.alignment = 'Expand'.upper()
            box_1A4F1.scale_x = 1.0
            box_1A4F1.scale_y = 1.0
            if not True: box_1A4F1.operator_context = "EXEC_DEFAULT"
            box_00D28 = box_1A4F1.box()
            box_00D28.alert = False
            box_00D28.enabled = True
            box_00D28.active = True
            box_00D28.use_property_split = False
            box_00D28.use_property_decorate = False
            box_00D28.alignment = 'Expand'.upper()
            box_00D28.scale_x = 1.0
            box_00D28.scale_y = 1.0
            if not True: box_00D28.operator_context = "EXEC_DEFAULT"
            row_F1237 = box_00D28.row(heading='', align=False)
            row_F1237.alert = False
            row_F1237.enabled = True
            row_F1237.active = True
            row_F1237.use_property_split = False
            row_F1237.use_property_decorate = False
            row_F1237.scale_x = 1.0
            row_F1237.scale_y = 1.0
            row_F1237.alignment = 'Left'.upper()
            row_F1237.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_F1237.label(text='Shift E', icon_value=0)
            row_930BF = row_F1237.row(heading='', align=True)
            row_930BF.alert = False
            row_930BF.enabled = True
            row_930BF.active = True
            row_930BF.use_property_split = False
            row_930BF.use_property_decorate = False
            row_930BF.scale_x = 1.0
            row_930BF.scale_y = 1.0
            row_930BF.alignment = 'Left'.upper()
            row_930BF.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_930BF.operator('sna.toggle_off_shift_es_f193c', text='Off', icon_value=0, emboss=True, depress=False)
            op = row_930BF.operator('sna.toggle_on_shift_es_8ad96', text='On', icon_value=0, emboss=True, depress=False)
            row_4D9B3 = box_00D28.row(heading='', align=False)
            row_4D9B3.alert = False
            row_4D9B3.enabled = True
            row_4D9B3.active = True
            row_4D9B3.use_property_split = False
            row_4D9B3.use_property_decorate = False
            row_4D9B3.scale_x = 1.0
            row_4D9B3.scale_y = 1.0
            row_4D9B3.alignment = 'Left'.upper()
            row_4D9B3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_4D9B3.label(text='Mesh > Edge Crease', icon_value=0)
            row_4D9B3.prop(bpy.context.window_manager.keyconfigs.active.keymaps['Mesh'].keymap_items['transform.edge_crease'], 'active', text='', icon_value=0, emboss=False)
            row_E78BE = box_00D28.row(heading='', align=False)
            row_E78BE.alert = False
            row_E78BE.enabled = True
            row_E78BE.active = True
            row_E78BE.use_property_split = False
            row_E78BE.use_property_decorate = False
            row_E78BE.scale_x = 1.0
            row_E78BE.scale_y = 1.0
            row_E78BE.alignment = 'Left'.upper()
            row_E78BE.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_E78BE.label(text='Pose > Breakdowner', icon_value=0)
            row_E78BE.prop(bpy.context.window_manager.keyconfigs.user.keymaps['Pose'].keymap_items['pose.breakdown'], 'active', text='', icon_value=0, emboss=False)
            row_1C059 = box_1A4F1.row(heading='', align=False)
            row_1C059.alert = False
            row_1C059.enabled = True
            row_1C059.active = True
            row_1C059.use_property_split = False
            row_1C059.use_property_decorate = False
            row_1C059.scale_x = 1.0
            row_1C059.scale_y = 1.0
            row_1C059.alignment = 'Left'.upper()
            row_1C059.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_1C059.label(text='Use Default Pie (If using Compendium Modes Pie, disable this option)', icon_value=0)
            row_1C059.prop(bpy.context.window_manager.keyconfigs.user.keymaps['Object Non-modal'].keymap_items['view3d.object_mode_pie_or_toggle'], 'active', text='', icon_value=0, emboss=False)
            row_80452 = box_1A4F1.row(heading='', align=False)
            row_80452.alert = False
            row_80452.enabled = True
            row_80452.active = True
            row_80452.use_property_split = False
            row_80452.use_property_decorate = False
            row_80452.scale_x = 1.0
            row_80452.scale_y = 1.0
            row_80452.alignment = 'Left'.upper()
            row_80452.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_80452.label(text='Tab Key Object Mode (Also turn off if using Compendium Modes Pie)', icon_value=0)
            row_80452.prop(bpy.context.window_manager.keyconfigs.user.keymaps['Object Non-modal'].keymap_items['object.mode_set'], 'active', text='', icon_value=0, emboss=False)
            box_B7100 = layout.box()
            box_B7100.alert = False
            box_B7100.enabled = True
            box_B7100.active = True
            box_B7100.use_property_split = False
            box_B7100.use_property_decorate = False
            box_B7100.alignment = 'Expand'.upper()
            box_B7100.scale_x = 1.0
            box_B7100.scale_y = 1.0
            if not True: box_B7100.operator_context = "EXEC_DEFAULT"
            box_B7100.label(text='Changelog Version ' + str(tuple((3, 13, 0))).replace('(', '').replace(')', '').replace(',', '.').replace(' ', '') + ':', icon_value=0)
            col_C0F38 = box_B7100.column(heading='', align=False)
            col_C0F38.alert = False
            col_C0F38.enabled = True
            col_C0F38.active = True
            col_C0F38.use_property_split = False
            col_C0F38.use_property_decorate = False
            col_C0F38.scale_x = 1.0
            col_C0F38.scale_y = 1.0
            col_C0F38.alignment = 'Expand'.upper()
            col_C0F38.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_C0F38.label(text='Added: New Weight Paint wrkflow options for Auto Selecting various selection modes', icon_value=58)


class SNA_OT_Togglem3_8535A(bpy.types.Operator):
    bl_idname = "sna.togglem3_8535a"
    bl_label = "ToggleM3"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.preferences.inputs.use_mouse_emulate_3_button = (not bpy.context.preferences.inputs.use_mouse_emulate_3_button)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnshiftefalse_18B1F(Toggle):
    bpy.context.window_manager.keyconfigs.active.keymaps['Mesh'].keymap_items['transform.edge_crease'].active = Toggle
    bpy.context.window_manager.keyconfigs.user.keymaps['Pose'].keymap_items['pose.breakdown'].active = Toggle


class SNA_OT_Toggle_Off_Shift_Es_F193C(bpy.types.Operator):
    bl_idname = "sna.toggle_off_shift_es_f193c"
    bl_label = "Toggle Off Shift Es"
    bl_description = "Sets all default Shift E keys to false so they wont interfere with compendium pies"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnshiftefalse_18B1F(False)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


@persistent
def load_post_handler_F84BC(dummy):
    sna_fnshiftefalse_18B1F(False)


class SNA_OT_Toggle_On_Shift_Es_8Ad96(bpy.types.Operator):
    bl_idname = "sna.toggle_on_shift_es_8ad96"
    bl_label = "Toggle On Shift Es"
    bl_description = "Sets all default Shift E keys to true so they behave as default Blender intended"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnshiftefalse_18B1F(True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnsetsnaptoface_EAB45():
    bpy.context.scene.tool_settings.snap_elements = set(['FACE'])
    bpy.context.scene.tool_settings.use_snap_rotate = True
    bpy.context.scene.tool_settings.use_snap_translate = True
    bpy.context.scene.tool_settings.use_snap_align_rotation = True
    bpy.context.scene.tool_settings.snap_target = 'CENTER'


def sna_fnsendobjectstobackup_8AF45(Objects):
    if Objects:
        collection_0_20f20, isnewcollection_1_20f20 = sna_moveobjectstocollection_397D9_20F20('Backup Objects', Objects)
        if isnewcollection_1_20f20:
            sna_hidecollectioninviewport_32E38_04E8B('Backup Objects', 'Local')
            collection_0_20f20.hide_render = True


def sna_fnsetshadingmatcap_2CFE1():
    bpy.context.area.spaces.active.shading.type = 'SOLID'
    bpy.context.area.spaces.active.shading.light = 'MATCAP'
    bpy.context.area.spaces.active.shading.color_type = 'OBJECT'


def sna_fnsetshadingflat_3CF87():
    bpy.context.area.spaces.active.shading.type = 'SOLID'
    bpy.context.area.spaces.active.shading.light = 'FLAT'
    bpy.context.area.spaces.active.shading.color_type = 'VERTEX'


def sna_fnsetshadingpreview_A8938():
    bpy.context.area.spaces.active.shading.type = 'MATERIAL'


def sna_fnspecialhideobjects_9AA75(Objects):
    if Objects:
        for i_638E9 in range(len(Objects)):
            Objects[i_638E9].sna_lastcollection = Objects[i_638E9].users_collection[0].name
        collection_0_63b66 = sna_moveobjectstocollection_397D9_63B66('HiddenObjects', Objects)
        sna_hidecollectioninviewport_32E38_F9EA4('HiddenObjects', 'Local')


def sna_fnspecialshow_F6D84():
    general_fns['sna_objectlist'] = []
    if property_exists("bpy.data.collections['HiddenObjects']", globals(), locals()):
        for i_04CD0 in range(len(bpy.data.collections['HiddenObjects'].all_objects)):
            if (bpy.data.collections['HiddenObjects'].all_objects[i_04CD0].sna_lastcollection != 'original'):
                general_fns['sna_objectlist'].append(bpy.data.collections['HiddenObjects'].all_objects[i_04CD0])
        for i_7461B in range(len(general_fns['sna_objectlist'])):
            collection_0_58084 = sna_moveobjectstocollection_397D9_58084(general_fns['sna_objectlist'][i_7461B].sna_lastcollection, [general_fns['sna_objectlist'][i_7461B]])

            def delayed_93EF5():
                general_fns['sna_objectlist'][i_7461B].sna_lastcollection = 'original'
            bpy.app.timers.register(delayed_93EF5, first_interval=0.10000000149011612)


def sna_fnspecialhideselected_5B387():
    sna_fnspecialhideobjects_9AA75(list(bpy.context.view_layer.objects.selected))


def sna_fnspecialhideunselected_75825():
    general_fns['sna_unselected'] = []
    general_fns['sna_unselected'] = list(bpy.data.objects)
    for i_87D1D in range(len(bpy.context.view_layer.objects.selected)-1,-1,-1):
        general_fns['sna_unselected'].remove(bpy.context.view_layer.objects.selected[i_87D1D])
    sna_fnspecialhideobjects_9AA75(general_fns['sna_unselected'])


def sna_fnsendselectedtobackup_26B39():
    sna_fnsendobjectstobackup_8AF45(list(bpy.context.view_layer.objects.selected))


def sna_fnduplicatesendtobackup_9725B():
    prev_context = bpy.context.area.type
    bpy.context.area.type = 'VIEW_3D'
    bpy.ops.object.duplicate('INVOKE_DEFAULT', )
    bpy.context.area.type = prev_context
    sna_fnsendobjectstobackup_8AF45(list(bpy.context.view_layer.objects.selected))


def sna_fnsetsculptworkflow_577DB():
    bpy.context.scene.sna_sculptworkflow = True
    bpy.context.scene.sna_vpworkflow = False
    bpy.context.scene.sna_wpworkflow = False


def sna_fnsetvpworkflow_85088():
    bpy.context.scene.sna_sculptworkflow = False
    bpy.context.scene.sna_vpworkflow = True
    bpy.context.scene.sna_wpworkflow = False


def sna_fnsetwpworkflow_C2AE4():
    bpy.context.scene.sna_sculptworkflow = False
    bpy.context.scene.sna_vpworkflow = False
    bpy.context.scene.sna_wpworkflow = True


def sna_fnueanimationpreset_55B54():
    menu_idname = 'RENDER_MT_framerate_presets'
    bpy.context.scene.render.fps = 30
    bpy.context.scene.render.fps_base = 1


def sna_fnaddloctocamlocations_C9867():
    if (bpy.context.scene.sna_locationname != ''):
        item_1BCB2 = bpy.context.scene.sna_camlocs.add()
        item_1BCB2.location = bpy.context.view_layer.objects.active.location
        bpy.context.view_layer.objects.active.rotation_mode = 'QUATERNION'
        item_1BCB2.rotation = bpy.context.view_layer.objects.active.rotation_quaternion
        item_1BCB2.name = bpy.context.scene.sna_locationname
        bpy.context.scene.sna_locationname = ''
        bpy.context.view_layer.objects.active.rotation_mode = 'XYZ'


def sna_fnsetcamera_D5305(ID):
    bpy.context.view_layer.objects.active.location = bpy.context.scene.sna_camlocs[ID].location
    bpy.context.view_layer.objects.active.rotation_mode = 'QUATERNION'
    bpy.context.view_layer.objects.active.rotation_quaternion = bpy.context.scene.sna_camlocs[ID].rotation
    bpy.context.view_layer.objects.active.rotation_mode = 'XYZ'


def sna_fnremovecamloc_3E2C4(ID):
    if len(bpy.context.scene.sna_camlocs) > ID:
        bpy.context.scene.sna_camlocs.remove(ID)


def sna_fnrendersettingsquarepreset_F1CC4(Resolution):
    bpy.context.scene.render.resolution_x = Resolution
    bpy.context.scene.render.resolution_y = Resolution


def sna_fnsetscreenresolution_CE81E(X_Res, Y_Res):
    bpy.context.scene.render.resolution_x = X_Res
    bpy.context.scene.render.resolution_y = Y_Res


def sna_fnueall_90778():
    sna_fnueanimationpreset_55B54()


def sna_fnresetprojectsettings_46FE4():
    bpy.context.scene.unit_settings.system = 'METRIC'
    bpy.context.scene.unit_settings.length_unit = 'METERS'
    bpy.context.scene.unit_settings.scale_length = 1.0
    sna_fnsetview3dtoscale_ACEE9(1.0)


def sna_fnsetview3dtoscale_ACEE9(Scale):
    for i_84A60 in range(len(find_areas_of_type(bpy.context.screen, 'VIEW_3D'))):
        if property_exists("find_areas_of_type(bpy.context.screen, 'VIEW_3D')[i_84A60].spaces[0].overlay.grid_scale", globals(), locals()):
            find_areas_of_type(bpy.context.screen, 'VIEW_3D')[i_84A60].spaces[0].overlay.grid_scale = Scale


def sna_fnappendsinglevert_96F0D():
    before_data = list(bpy.data.objects)
    bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'compendium_assets.blend') + r'\Object', filename='SingleVert', link=False)
    new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
    appended_2DFAB = None if not new_data else new_data[0]


def sna_fnappendxedge_0338F():
    before_data = list(bpy.data.objects)
    bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'compendium_assets.blend') + r'\Object', filename='X_Edge', link=False)
    new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
    appended_C96A4 = None if not new_data else new_data[0]


def sna_fnappendbezierpipe_C52BC():
    before_data = list(bpy.data.objects)
    bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'compendium_assets.blend') + r'\Object', filename='BezierPipe', link=False)
    new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
    appended_F2685 = None if not new_data else new_data[0]


def sna_fnquickrotate_60446(RotateAmount):
    if 'OBJECT'==bpy.context.mode:
        if property_exists("bpy.context.view_layer.objects.active", globals(), locals()):
            if bpy.context.scene.sna_ispositive:
                general_fns['sna_rotamount'] = math.radians(RotateAmount)
            else:
                general_fns['sna_rotamount'] = math.radians(float(RotateAmount * -1.0))
            if bpy.context.scene.sna_x_axis:
                bpy.context.view_layer.objects.active.rotation_euler = (float(bpy.context.view_layer.objects.active.rotation_euler[0] + general_fns['sna_rotamount']), bpy.context.view_layer.objects.active.rotation_euler[1], bpy.context.view_layer.objects.active.rotation_euler[2])
            if bpy.context.scene.sna_y_axis:
                bpy.context.view_layer.objects.active.rotation_euler = (bpy.context.view_layer.objects.active.rotation_euler[0], float(bpy.context.view_layer.objects.active.rotation_euler[1] + general_fns['sna_rotamount']), bpy.context.view_layer.objects.active.rotation_euler[2])
            if bpy.context.scene.sna_z_axis:
                bpy.context.view_layer.objects.active.rotation_euler = (bpy.context.view_layer.objects.active.rotation_euler[0], bpy.context.view_layer.objects.active.rotation_euler[1], float(bpy.context.view_layer.objects.active.rotation_euler[2] + general_fns['sna_rotamount']))


def sna_fnappendbezierrec_4B7BE():
    before_data = list(bpy.data.objects)
    bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'compendium_assets.blend') + r'\Object', filename='BezierRectangle', link=False)
    new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
    appended_E035F = None if not new_data else new_data[0]


def sna_fnappendemtpycurve_4CDA1():
    before_data = list(bpy.data.objects)
    bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'compendium_assets.blend') + r'\Object', filename='EmptyCurve', link=False)
    new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
    appended_5DC78 = None if not new_data else new_data[0]


def sna_fnappendsquarecurve_846BC():
    before_data = list(bpy.data.objects)
    bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'compendium_assets.blend') + r'\Object', filename='SquareCurve', link=False)
    new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
    appended_CBC89 = None if not new_data else new_data[0]


class SNA_OT_Set_Orientation_Global_52453(bpy.types.Operator):
    bl_idname = "sna.set_orientation_global_52453"
    bl_label = "Set Orientation Global"
    bl_description = "Set the transform orientation to Globall"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetorientationglobal_490EC()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnsetorientationglobal_490EC():
    bpy.data.scenes['Scene'].transform_orientation_slots[0].type = 'GLOBAL'


class SNA_OT_Set_Orientation_Local_059E9(bpy.types.Operator):
    bl_idname = "sna.set_orientation_local_059e9"
    bl_label = "Set Orientation Local"
    bl_description = "Set the transform orientation to Local"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetorientationlocal_33E95()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnsetorientationlocal_33E95():
    bpy.data.scenes['Scene'].transform_orientation_slots[0].type = 'LOCAL'


class SNA_OT_Set_Orientation_Normal_B13Bc(bpy.types.Operator):
    bl_idname = "sna.set_orientation_normal_b13bc"
    bl_label = "Set Orientation Normal"
    bl_description = "Set the transform orientation to Normal"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetorientationnormal_E7406()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnsetorientationnormal_E7406():
    bpy.data.scenes['Scene'].transform_orientation_slots[0].type = 'NORMAL'


class SNA_OT_Transform_Pivot_Median_Dfa9E(bpy.types.Operator):
    bl_idname = "sna.transform_pivot_median_dfa9e"
    bl_label = "Transform Pivot Median"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Transform_Pivot_Cursor_4Cdc9(bpy.types.Operator):
    bl_idname = "sna.transform_pivot_cursor_4cdc9"
    bl_label = "Transform Pivot Cursor"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Transform_Pivot_Individual_Ea6E3(bpy.types.Operator):
    bl_idname = "sna.transform_pivot_individual_ea6e3"
    bl_label = "Transform Pivot Individual"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.context.scene.tool_settings.transform_pivot_point = 'INDIVIDUAL_ORIGINS'")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_X_Fa140(bpy.types.Operator):
    bl_idname = "sna.zero_x_fa140"
    bl_label = "Zero X"
    bl_description = "Set object Location X to 0"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.location = (0.0, bpy.context.view_layer.objects.active.location[1], bpy.context.view_layer.objects.active.location[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_Y_4Bafe(bpy.types.Operator):
    bl_idname = "sna.zero_y_4bafe"
    bl_label = "Zero Y"
    bl_description = "Set object Location Y to 0"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.location = (bpy.context.view_layer.objects.active.location[0], 0.0, bpy.context.view_layer.objects.active.location[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_Z_B09F4(bpy.types.Operator):
    bl_idname = "sna.zero_z_b09f4"
    bl_label = "Zero Z"
    bl_description = "Set object Location Z to 0"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.location = (bpy.context.view_layer.objects.active.location[0], bpy.context.view_layer.objects.active.location[1], 0.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_X_Rot_4E822(bpy.types.Operator):
    bl_idname = "sna.zero_x_rot_4e822"
    bl_label = "Zero X Rot"
    bl_description = "Set object Rotation X to 0"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.rotation_euler = (0.0, bpy.context.view_layer.objects.active.rotation_euler[1], bpy.context.view_layer.objects.active.rotation_euler[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_Y_Rot_D3731(bpy.types.Operator):
    bl_idname = "sna.zero_y_rot_d3731"
    bl_label = "Zero Y Rot"
    bl_description = "Set object Rotation Y to 0"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.rotation_euler = (bpy.context.view_layer.objects.active.rotation_euler[0], 0.0, bpy.context.view_layer.objects.active.rotation_euler[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_Z_Rot_E6449(bpy.types.Operator):
    bl_idname = "sna.zero_z_rot_e6449"
    bl_label = "Zero Z Rot"
    bl_description = "Set object Rotation Z to 0"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.rotation_euler = (bpy.context.view_layer.objects.active.rotation_euler[0], bpy.context.view_layer.objects.active.rotation_euler[1], 0.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_X_Scale_2286B(bpy.types.Operator):
    bl_idname = "sna.reset_x_scale_2286b"
    bl_label = "Reset X Scale"
    bl_description = "Set object Scale X to 1"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.scale = (1.0, bpy.context.view_layer.objects.active.scale[1], bpy.context.view_layer.objects.active.scale[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Y_Scale_21706(bpy.types.Operator):
    bl_idname = "sna.reset_y_scale_21706"
    bl_label = "Reset Y Scale"
    bl_description = "Set object Scale Y to 1"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.scale = (bpy.context.view_layer.objects.active.scale[0], 1.0, bpy.context.view_layer.objects.active.scale[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Z_Scale_C3816(bpy.types.Operator):
    bl_idname = "sna.reset_z_scale_c3816"
    bl_label = "Reset Z Scale"
    bl_description = "Set object Scale X to 1"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.scale = (bpy.context.view_layer.objects.active.scale[0], bpy.context.view_layer.objects.active.scale[1], 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Show_Ops_F6C25(bpy.types.Operator):
    bl_idname = "sna.show_ops_f6c25"
    bl_label = "Show Ops"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showops = (not bpy.context.scene.sna_showops)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Mirror_Empty_F8D10(bpy.types.Operator):
    bl_idname = "sna.mirror_empty_f8d10"
    bl_label = "Mirror Empty"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnmirrorcompemtpy_CCFBA()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Send_Selectedto_Backup_5Ac5A(bpy.types.Operator):
    bl_idname = "sna.send_selectedto_backup_5ac5a"
    bl_label = "Send SelectedTo Backup"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsendselectedtobackup_26B39()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Snap_To_Face_Preset_5Ffa6(bpy.types.Operator):
    bl_idname = "sna.snap_to_face_preset_5ffa6"
    bl_label = "Snap To Face Preset"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetsnaptoface_EAB45()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Show_Creases_48169(bpy.types.Operator):
    bl_idname = "sna.toggle_show_creases_48169"
    bl_label = "Toggle Show Creases"
    bl_description = "Show Creases on Objects"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.area.spaces.active.overlay.show_edge_crease = (not bpy.context.area.spaces.active.overlay.show_edge_crease)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Show_Sharps_28E50(bpy.types.Operator):
    bl_idname = "sna.toggle_show_sharps_28e50"
    bl_label = "Toggle Show Sharps"
    bl_description = "Show Sharps on Objects"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.area.spaces.active.overlay.show_edge_sharp = (not bpy.context.area.spaces.active.overlay.show_edge_sharp)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Show_Bevels_Cb2F7(bpy.types.Operator):
    bl_idname = "sna.toggle_show_bevels_cb2f7"
    bl_label = "Toggle Show Bevels"
    bl_description = "Show Bevels on Objects"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.area.spaces.active.overlay.show_edge_bevel_weight = (not bpy.context.area.spaces.active.overlay.show_edge_bevel_weight)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Show_Seams_7408D(bpy.types.Operator):
    bl_idname = "sna.toggle_show_seams_7408d"
    bl_label = "Toggle Show Seams"
    bl_description = "Show Seams on Objects"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.area.spaces.active.overlay.show_edge_seams = (not bpy.context.area.spaces.active.overlay.show_edge_seams)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Shading_Matcap_E9F4F(bpy.types.Operator):
    bl_idname = "sna.set_shading_matcap_e9f4f"
    bl_label = "Set Shading MatCap"
    bl_description = "Set Viewport Shading: Solid, MatCap, Object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetshadingmatcap_2CFE1()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Shading_Flat_87Cbc(bpy.types.Operator):
    bl_idname = "sna.set_shading_flat_87cbc"
    bl_label = "Set Shading Flat"
    bl_description = "Set Viewport Shading: Solid, Flat, Attribute"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetshadingflat_3CF87()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Shading_Preview_9Ad3C(bpy.types.Operator):
    bl_idname = "sna.set_shading_preview_9ad3c"
    bl_label = "Set Shading Preview"
    bl_description = "Set Viewport Shading: Material Preview"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetshadingpreview_A8938()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Special_Hide_Selected_1C458(bpy.types.Operator):
    bl_idname = "sna.special_hide_selected_1c458"
    bl_label = "Special Hide Selected"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnspecialhideselected_5B387()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Special_Show_All_7E124(bpy.types.Operator):
    bl_idname = "sna.special_show_all_7e124"
    bl_label = "Special Show All"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnspecialshow_F6D84()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Special_Hide_Unselected_29928(bpy.types.Operator):
    bl_idname = "sna.special_hide_unselected_29928"
    bl_label = "Special Hide Unselected"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnspecialhideunselected_75825()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Wireframe_C8C58(bpy.types.Operator):
    bl_idname = "sna.toggle_wireframe_c8c58"
    bl_label = "Toggle Wireframe"
    bl_description = "Show wireframe on active object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.show_wire = (not bpy.context.view_layer.objects.active.show_wire)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Duplicate_Send_To_Backup_8Be30(bpy.types.Operator):
    bl_idname = "sna.duplicate_send_to_backup_8be30"
    bl_label = "Duplicate Send To Backup"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnduplicatesendtobackup_9725B()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Display_In_Front_67De2(bpy.types.Operator):
    bl_idname = "sna.toggle_display_in_front_67de2"
    bl_label = "Toggle Display In Front"
    bl_description = "Toggle show in front for amature bones"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.show_in_front = (not bpy.context.view_layer.objects.active.show_in_front)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Show_Stretch_8Ca4E(bpy.types.Operator):
    bl_idname = "sna.toggle_show_stretch_8ca4e"
    bl_label = "Toggle Show Stretch"
    bl_description = "Show UV stretch heatmap"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.area.spaces[0].uv_editor.show_stretch = (not bpy.context.area.spaces[0].uv_editor.show_stretch)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Vertex_Paint_Workflow_B1688(bpy.types.Operator):
    bl_idname = "sna.set_vertex_paint_workflow_b1688"
    bl_label = "Set Vertex Paint Workflow"
    bl_description = "Changes tools to quickly adapt to a vertex painting workflow"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetvpworkflow_85088()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Weight_Paint_Workflow_C2Eda(bpy.types.Operator):
    bl_idname = "sna.set_weight_paint_workflow_c2eda"
    bl_label = "Set Weight Paint Workflow"
    bl_description = "Changes tools to quickly adapt to a weight painting workflow"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetwpworkflow_C2AE4()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Sculpt_Workflow_27F56(bpy.types.Operator):
    bl_idname = "sna.set_sculpt_workflow_27f56"
    bl_label = "Set Sculpt Workflow"
    bl_description = "Changes tools to quickly adapt to a  scupting workflow"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetsculptworkflow_577DB()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Ue_Projects_Settings_D25Db(bpy.types.Operator):
    bl_idname = "sna.ue_projects_settings_d25db"
    bl_label = "UE Projects Settings"
    bl_description = "Set all project setting to be compatible with exporting to UE"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnueall_90778()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Camera_Loaction_1E5F9(bpy.types.Operator):
    bl_idname = "sna.add_camera_loaction_1e5f9"
    bl_label = "Add Camera Loaction"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnaddloctocamlocations_C9867()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Setcameratolocation_78754(bpy.types.Operator):
    bl_idname = "sna.setcameratolocation_78754"
    bl_label = "SetCameraToLocation"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_id: bpy.props.IntProperty(name='ID', description='', options={'HIDDEN'}, default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetcamera_D5305(self.sna_id)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Remove_Camera_Location_37A38(bpy.types.Operator):
    bl_idname = "sna.remove_camera_location_37a38"
    bl_label = "Remove Camera Location"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_id: bpy.props.IntProperty(name='ID', description='', options={'HIDDEN'}, default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnremovecamloc_3E2C4(self.sna_id)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Square_Preset_18Bb4(bpy.types.Operator):
    bl_idname = "sna.set_square_preset_18bb4"
    bl_label = " Set Square Preset"
    bl_description = "Preset for setting the render to a square resolution. "
    bl_options = {"REGISTER", "UNDO"}
    sna_resolution: bpy.props.IntProperty(name='Resolution', description='', options={'HIDDEN'}, default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnrendersettingsquarepreset_F1CC4(self.sna_resolution)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Screen_Reset_45D5E(bpy.types.Operator):
    bl_idname = "sna.set_screen_reset_45d5e"
    bl_label = " Set Screen Reset"
    bl_description = "Preset for setting the render to a square resolution. "
    bl_options = {"REGISTER", "UNDO"}
    sna_xres: bpy.props.IntProperty(name='XRes', description='', options={'HIDDEN'}, default=0, subtype='NONE')
    sna_yres: bpy.props.IntProperty(name='YRes', description='', options={'HIDDEN'}, default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetscreenresolution_CE81E(self.sna_xres, self.sna_yres)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Workflow_Options_05D4C(bpy.types.Operator):
    bl_idname = "sna.toggle_workflow_options_05d4c"
    bl_label = "Toggle Workflow Options"
    bl_description = "Shows and hides the options for specified workflow"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showwfoptions = (not bpy.context.scene.sna_showwfoptions)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Project_Settings_4A619(bpy.types.Operator):
    bl_idname = "sna.reset_project_settings_4a619"
    bl_label = "Reset Project Settings"
    bl_description = "Reset project settings to the default new file settings. (Remove UE Settings)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnresetprojectsettings_46FE4()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Setviewportgridue_B1102(bpy.types.Operator):
    bl_idname = "sna.setviewportgridue_b1102"
    bl_label = "SetViewportGridUE"
    bl_description = "Sets all viewport grids to 0.01 to match the 0.01/centimeters settings"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetview3dtoscale_ACEE9(0.009999999776482582)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Single_Vert_Bfe7D(bpy.types.Operator):
    bl_idname = "sna.add_single_vert_bfe7d"
    bl_label = "Add Single Vert"
    bl_description = "Adds a single vert object to project"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnappendsinglevert_96F0D()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Edge_2Ddef(bpy.types.Operator):
    bl_idname = "sna.add_edge_2ddef"
    bl_label = "Add Edge"
    bl_description = "Adds a single edge object to project"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnappendxedge_0338F()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Orientation_Parent_9Fa00(bpy.types.Operator):
    bl_idname = "sna.set_orientation_parent_9fa00"
    bl_label = "Set Orientation Parent"
    bl_description = "Set the transform orientation to Parent"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetorientationparent_34D09()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnsetorientationparent_34D09():
    bpy.data.scenes['Scene'].transform_orientation_slots[0].type = 'PARENT'


class SNA_OT_Add_Bezier_Pipe_E6F6D(bpy.types.Operator):
    bl_idname = "sna.add_bezier_pipe_e6f6d"
    bl_label = "Add Bezier Pipe"
    bl_description = "Add simple bezier curve with a circle profile"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnappendbezierpipe_C52BC()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Rotation_Axis_D9Af5(bpy.types.Operator):
    bl_idname = "sna.set_rotation_axis_d9af5"
    bl_label = "Set Rotation Axis"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_axis: bpy.props.StringProperty(name='Axis', description='', options={'HIDDEN'}, default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (self.sna_axis == 'X'):
            bpy.context.scene.sna_x_axis = (not bpy.context.scene.sna_x_axis)
        else:
            if (self.sna_axis == 'Y'):
                bpy.context.scene.sna_y_axis = (not bpy.context.scene.sna_y_axis)
            else:
                if (self.sna_axis == 'Z'):
                    bpy.context.scene.sna_z_axis = (not bpy.context.scene.sna_z_axis)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Is_Positive_Axis_Fd57D(bpy.types.Operator):
    bl_idname = "sna.set_is_positive_axis_fd57d"
    bl_label = "Set Is Positive Axis"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_positiveclicked: bpy.props.BoolProperty(name='PositiveClicked', description='', options={'HIDDEN'}, default=False)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if self.sna_positiveclicked:
            bpy.context.scene.sna_ispositive = True
        else:
            bpy.context.scene.sna_ispositive = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Quick_Rotate_Active_Object_Db0Ac(bpy.types.Operator):
    bl_idname = "sna.quick_rotate_active_object_db0ac"
    bl_label = "Quick Rotate Active Object"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_amount: bpy.props.FloatProperty(name='Amount', description='', options={'HIDDEN'}, default=0.0, subtype='NONE', unit='NONE', step=3, precision=6)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnquickrotate_60446(self.sna_amount)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Bezier_Rectangle_F8009(bpy.types.Operator):
    bl_idname = "sna.add_bezier_rectangle_f8009"
    bl_label = "Add Bezier Rectangle"
    bl_description = "Add simple bezier curve with a rectangle profile"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnappendbezierrec_4B7BE()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Empty_Curve_43Edf(bpy.types.Operator):
    bl_idname = "sna.add_empty_curve_43edf"
    bl_label = "Add Empty Curve"
    bl_description = "Add empty curve object (for easy use of the pen tool)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnappendemtpycurve_4CDA1()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Square_Curve_6290E(bpy.types.Operator):
    bl_idname = "sna.add_square_curve_6290e"
    bl_label = "Add Square Curve"
    bl_description = "Add square curve object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnappendsquarecurve_846BC()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnviewportuniversal_70EA3(layout_function, ):
    row_314F8 = layout_function.row(heading='', align=False)
    row_314F8.alert = False
    row_314F8.enabled = True
    row_314F8.active = True
    row_314F8.use_property_split = False
    row_314F8.use_property_decorate = False
    row_314F8.scale_x = 1.0
    row_314F8.scale_y = 1.0
    row_314F8.alignment = 'Expand'.upper()
    row_314F8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_E3402 = row_314F8.column(heading='', align=False)
    col_E3402.alert = False
    col_E3402.enabled = True
    col_E3402.active = True
    col_E3402.use_property_split = False
    col_E3402.use_property_decorate = False
    col_E3402.scale_x = 1.4500000476837158
    col_E3402.scale_y = 3.299999952316284
    col_E3402.alignment = 'Expand'.upper()
    col_E3402.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    op = col_E3402.operator('view3d.toggle_xray', text='', icon_value=614, emboss=True, depress=bpy.context.area.spaces.active.shading.show_xray)
    col_08A16 = row_314F8.column(heading='', align=True)
    col_08A16.alert = False
    col_08A16.enabled = True
    col_08A16.active = True
    col_08A16.use_property_split = False
    col_08A16.use_property_decorate = False
    col_08A16.scale_x = 1.0
    col_08A16.scale_y = 1.100000023841858
    col_08A16.alignment = 'Expand'.upper()
    col_08A16.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    op = col_08A16.operator('sna.set_shading_matcap_e9f4f', text='Matcap', icon_value=312, emboss=True, depress=False)
    op = col_08A16.operator('sna.set_shading_flat_87cbc', text='Flat Attribute', icon_value=611, emboss=True, depress=False)
    op = col_08A16.operator('sna.set_shading_preview_9ad3c', text='Material Preview', icon_value=612, emboss=True, depress=False)


def sna_fnmirrorcompemtpy_CCFBA():
    if bpy.context.view_layer.objects.selected:
        mirrorempty['sna_objectname'] = bpy.context.view_layer.objects.active.name
        if bpy.context.scene.sna_usecompendiumempty:
            sna_fnfindempty_6DACB()
        else:
            sna_fncreateempty_0F0F5()


def sna_fnfindempty_6DACB():
    for i_55B66 in range(len(bpy.data.objects)):
        if (bpy.data.objects[i_55B66].name == 'CompendiumEmpty'):
            mirrorempty['sna_foundobject'] = True
            break
    if mirrorempty['sna_foundobject']:
        sna_fnaddmirroremptymod_E16E4('CompendiumEmpty')
    else:
        sna_fncreateempty_0F0F5()


def sna_fncreateempty_0F0F5():
    bpy.ops.object.empty_add('INVOKE_DEFAULT', type='PLAIN_AXES', radius=1.0, align='WORLD', location=(0.0, 0.0, 0.0), rotation=(0.0, 0.0, 0.0), scale=(1.0, 1.0, 1.0))
    bpy.context.view_layer.objects.active.name = 'CompendiumEmpty'
    mirrorempty['sna_newempty'] = bpy.context.view_layer.objects.active.name
    sna_fnaddmirroremptymod_E16E4(mirrorempty['sna_newempty'])


def sna_fnaddmirroremptymod_E16E4(EmptyName):
    modifier_B2CEA = bpy.data.objects[mirrorempty['sna_objectname']].modifiers.new(name='Mirror Empty Mod', type='MIRROR', )
    output_0_5ba5f = sna_getobjectproperty_427FF_5BA5F(EmptyName)
    modifier_B2CEA.mirror_object = output_0_5ba5f


class SNA_PT_EDIT_TOOLS_5C0B2(bpy.types.Panel):
    bl_label = 'Edit Tools'
    bl_idname = 'SNA_PT_EDIT_TOOLS_5C0B2'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 3
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not (bpy.context.scene.sna_showtools and 'EDIT_MESH'==bpy.context.mode)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='OPS', icon_value=0)
        box_1B8F3 = layout.box()
        box_1B8F3.alert = False
        box_1B8F3.enabled = True
        box_1B8F3.active = True
        box_1B8F3.use_property_split = False
        box_1B8F3.use_property_decorate = False
        box_1B8F3.alignment = 'Expand'.upper()
        box_1B8F3.scale_x = 1.0
        box_1B8F3.scale_y = 1.0
        if not True: box_1B8F3.operator_context = "EXEC_DEFAULT"
        col_6F0F4 = box_1B8F3.column(heading='', align=False)
        col_6F0F4.alert = False
        col_6F0F4.enabled = True
        col_6F0F4.active = True
        col_6F0F4.use_property_split = False
        col_6F0F4.use_property_decorate = False
        col_6F0F4.scale_x = 1.0
        col_6F0F4.scale_y = 1.0
        col_6F0F4.alignment = 'Expand'.upper()
        col_6F0F4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        if property_exists("bpy.context.preferences.addons['forgotten_tools']", globals(), locals()):
            col_63071 = col_6F0F4.column(heading='', align=False)
            col_63071.alert = False
            col_63071.enabled = True
            col_63071.active = True
            col_63071.use_property_split = False
            col_63071.use_property_decorate = False
            col_63071.scale_x = 1.0
            col_63071.scale_y = 1.0
            col_63071.alignment = 'Expand'.upper()
            col_63071.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_63071.label(text='Forgotten Tools', icon_value=0)
            op = col_63071.operator('mesh.forgotten_separate_duplicate', text='Separate Duplicate', icon_value=0, emboss=True, depress=False)
            op = col_63071.operator('forgotten.mesh_straighten', text='Straighten', icon_value=0, emboss=True, depress=False)
            op = col_63071.operator('forgotten.mesh_hinge', text='Hinge', icon_value=0, emboss=True, depress=False)
        if property_exists("bpy.context.preferences.addons['bl_ext.blender_org.looptools']", globals(), locals()):
            col_55FE6 = col_6F0F4.column(heading='', align=False)
            col_55FE6.alert = False
            col_55FE6.enabled = True
            col_55FE6.active = True
            col_55FE6.use_property_split = False
            col_55FE6.use_property_decorate = False
            col_55FE6.scale_x = 1.0
            col_55FE6.scale_y = 1.0
            col_55FE6.alignment = 'Expand'.upper()
            col_55FE6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_55FE6.label(text='LoopTools', icon_value=0)
            op = col_55FE6.operator('mesh.looptools_relax', text='Relax', icon_value=0, emboss=True, depress=False)
            op.regular = True
            op = col_55FE6.operator('mesh.looptools_flatten', text='Flatten', icon_value=0, emboss=True, depress=False)
            op.influence = 100.0
            op = col_55FE6.operator('mesh.looptools_circle', text='Circle', icon_value=0, emboss=True, depress=False)
        if property_exists("bpy.context.preferences.addons['bl_ext.user_default.EdgeFlow']", globals(), locals()):
            col_77A4E = col_6F0F4.column(heading='', align=False)
            col_77A4E.alert = False
            col_77A4E.enabled = True
            col_77A4E.active = True
            col_77A4E.use_property_split = False
            col_77A4E.use_property_decorate = False
            col_77A4E.scale_x = 1.0
            col_77A4E.scale_y = 1.0
            col_77A4E.alignment = 'Expand'.upper()
            col_77A4E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_77A4E.label(text='Edge Flow', icon_value=0)
            op = col_77A4E.operator('mesh.set_edge_flow', text='Set Edge Flow', icon_value=0, emboss=True, depress=False)
            op = col_77A4E.operator('mesh.set_edge_linear', text='Set Linear Flow', icon_value=0, emboss=True, depress=False)
            op = col_77A4E.operator('mesh.set_edge_curve', text='Set Edge Curve', icon_value=0, emboss=True, depress=False)


class SNA_PT_ITEM_INFO_7E877(bpy.types.Panel):
    bl_label = 'Item Info'
    bl_idname = 'SNA_PT_ITEM_INFO_7E877'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 1
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not bpy.context.scene.sna_showiteminfo))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if bpy.context.view_layer.objects.active:
            col_81D10 = layout.column(heading='', align=False)
            col_81D10.alert = False
            col_81D10.enabled = True
            col_81D10.active = True
            col_81D10.use_property_split = False
            col_81D10.use_property_decorate = False
            col_81D10.scale_x = 1.0
            col_81D10.scale_y = 1.0
            col_81D10.alignment = 'Expand'.upper()
            col_81D10.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_81D10.label(text='Location', icon_value=0)
            row_2533A = col_81D10.row(heading='', align=True)
            row_2533A.alert = False
            row_2533A.enabled = True
            row_2533A.active = True
            row_2533A.use_property_split = False
            row_2533A.use_property_decorate = False
            row_2533A.scale_x = 1.0
            row_2533A.scale_y = 1.0
            row_2533A.alignment = 'Expand'.upper()
            row_2533A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_31DDF = row_2533A.column(heading='', align=True)
            col_31DDF.alert = False
            col_31DDF.enabled = True
            col_31DDF.active = True
            col_31DDF.use_property_split = False
            col_31DDF.use_property_decorate = False
            col_31DDF.scale_x = 1.0
            col_31DDF.scale_y = 1.0
            col_31DDF.alignment = 'Expand'.upper()
            col_31DDF.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_31DDF.prop(bpy.context.view_layer.objects.active, 'location', text='', icon_value=0, emboss=True)
            col_7500E = row_2533A.column(heading='', align=True)
            col_7500E.alert = False
            col_7500E.enabled = True
            col_7500E.active = True
            col_7500E.use_property_split = False
            col_7500E.use_property_decorate = False
            col_7500E.scale_x = 1.25
            col_7500E.scale_y = 1.0
            col_7500E.alignment = 'Right'.upper()
            col_7500E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_7500E.operator('sna.zero_x_fa140', text='', icon_value=16, emboss=True, depress=False)
            op = col_7500E.operator('sna.zero_y_4bafe', text='', icon_value=16, emboss=True, depress=False)
            op = col_7500E.operator('sna.zero_z_b09f4', text='', icon_value=16, emboss=True, depress=False)
            col_81D10.label(text='Rotation', icon_value=0)
            row_F7C5B = col_81D10.row(heading='', align=True)
            row_F7C5B.alert = False
            row_F7C5B.enabled = True
            row_F7C5B.active = True
            row_F7C5B.use_property_split = False
            row_F7C5B.use_property_decorate = False
            row_F7C5B.scale_x = 1.0
            row_F7C5B.scale_y = 1.0
            row_F7C5B.alignment = 'Expand'.upper()
            row_F7C5B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_69E30 = row_F7C5B.column(heading='', align=True)
            col_69E30.alert = False
            col_69E30.enabled = True
            col_69E30.active = True
            col_69E30.use_property_split = False
            col_69E30.use_property_decorate = False
            col_69E30.scale_x = 1.0
            col_69E30.scale_y = 1.0
            col_69E30.alignment = 'Expand'.upper()
            col_69E30.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_69E30.prop(bpy.context.view_layer.objects.active, 'rotation_euler', text='', icon_value=0, emboss=True)
            col_D81DD = row_F7C5B.column(heading='', align=True)
            col_D81DD.alert = False
            col_D81DD.enabled = True
            col_D81DD.active = True
            col_D81DD.use_property_split = False
            col_D81DD.use_property_decorate = False
            col_D81DD.scale_x = 1.25
            col_D81DD.scale_y = 1.0
            col_D81DD.alignment = 'Right'.upper()
            col_D81DD.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_D81DD.operator('sna.zero_x_rot_4e822', text='', icon_value=16, emboss=True, depress=False)
            op = col_D81DD.operator('sna.zero_y_rot_d3731', text='', icon_value=16, emboss=True, depress=False)
            op = col_D81DD.operator('sna.zero_z_rot_e6449', text='', icon_value=16, emboss=True, depress=False)
            col_81D10.label(text='Scale', icon_value=0)
            row_B5371 = col_81D10.row(heading='', align=True)
            row_B5371.alert = False
            row_B5371.enabled = True
            row_B5371.active = True
            row_B5371.use_property_split = False
            row_B5371.use_property_decorate = False
            row_B5371.scale_x = 1.0
            row_B5371.scale_y = 1.0
            row_B5371.alignment = 'Expand'.upper()
            row_B5371.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_B814F = row_B5371.column(heading='', align=True)
            col_B814F.alert = False
            col_B814F.enabled = True
            col_B814F.active = True
            col_B814F.use_property_split = False
            col_B814F.use_property_decorate = False
            col_B814F.scale_x = 1.0
            col_B814F.scale_y = 1.0
            col_B814F.alignment = 'Expand'.upper()
            col_B814F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_B814F.prop(bpy.context.view_layer.objects.active, 'scale', text='', icon_value=0, emboss=True)
            col_98DBC = row_B5371.column(heading='', align=True)
            col_98DBC.alert = False
            col_98DBC.enabled = True
            col_98DBC.active = True
            col_98DBC.use_property_split = False
            col_98DBC.use_property_decorate = False
            col_98DBC.scale_x = 1.25
            col_98DBC.scale_y = 1.0
            col_98DBC.alignment = 'Right'.upper()
            col_98DBC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_98DBC.operator('sna.reset_x_scale_2286b', text='', icon_value=16, emboss=True, depress=False)
            op = col_98DBC.operator('sna.reset_y_scale_21706', text='', icon_value=16, emboss=True, depress=False)
            op = col_98DBC.operator('sna.reset_z_scale_c3816', text='', icon_value=16, emboss=True, depress=False)
        else:
            layout.label(text='No Active Item', icon_value=0)
        if bpy.context.view_layer.objects.active:
            col_0A475 = layout.column(heading='', align=False)
            col_0A475.alert = False
            col_0A475.enabled = True
            col_0A475.active = True
            col_0A475.use_property_split = False
            col_0A475.use_property_decorate = False
            col_0A475.scale_x = 1.0
            col_0A475.scale_y = 1.2000000476837158
            col_0A475.alignment = 'Expand'.upper()
            col_0A475.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_0A475.operator('sna.toggle_wireframe_c8c58', text='Show Wireframe', icon_value=613, emboss=True, depress=bpy.context.view_layer.objects.active.show_wire)
            if bpy.context.view_layer.objects.active.type == 'ARMATURE':
                op = col_0A475.operator('sna.toggle_display_in_front_67de2', text='Bones In Front', icon_value=172, emboss=True, depress=bpy.context.view_layer.objects.active.show_in_front)


class SNA_PT_OBJECT_TOOLS_95067(bpy.types.Panel):
    bl_label = 'Object Tools'
    bl_idname = 'SNA_PT_OBJECT_TOOLS_95067'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 3
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not (bpy.context.scene.sna_showtools and 'OBJECT'==bpy.context.mode)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='OPS', icon_value=0)
        box_0A9C5 = layout.box()
        box_0A9C5.alert = False
        box_0A9C5.enabled = True
        box_0A9C5.active = True
        box_0A9C5.use_property_split = False
        box_0A9C5.use_property_decorate = False
        box_0A9C5.alignment = 'Expand'.upper()
        box_0A9C5.scale_x = 1.0
        box_0A9C5.scale_y = 1.0
        if not True: box_0A9C5.operator_context = "EXEC_DEFAULT"
        col_6FAD6 = box_0A9C5.column(heading='', align=False)
        col_6FAD6.alert = False
        col_6FAD6.enabled = True
        col_6FAD6.active = True
        col_6FAD6.use_property_split = False
        col_6FAD6.use_property_decorate = False
        col_6FAD6.scale_x = 1.0
        col_6FAD6.scale_y = 1.0
        col_6FAD6.alignment = 'Expand'.upper()
        col_6FAD6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_6FAD6.operator('object.origin_set', text='Set Origin (Volume)', icon_value=0, emboss=True, depress=False)
        op.type = 'ORIGIN_CENTER_OF_VOLUME'
        op = col_6FAD6.operator('object.origin_set', text='Set Origin (Cursor)', icon_value=0, emboss=True, depress=False)
        op.type = 'ORIGIN_CURSOR'
        op = col_6FAD6.operator('object.convert', text='Convert To Mesh', icon_value=0, emboss=True, depress=False)
        op.target = 'MESH'
        box_0BC5B = layout.box()
        box_0BC5B.alert = False
        box_0BC5B.enabled = True
        box_0BC5B.active = True
        box_0BC5B.use_property_split = False
        box_0BC5B.use_property_decorate = False
        box_0BC5B.alignment = 'Expand'.upper()
        box_0BC5B.scale_x = 1.0
        box_0BC5B.scale_y = 1.0
        if not True: box_0BC5B.operator_context = "EXEC_DEFAULT"
        col_2A392 = box_0BC5B.column(heading='', align=False)
        col_2A392.alert = False
        col_2A392.enabled = True
        col_2A392.active = True
        col_2A392.use_property_split = False
        col_2A392.use_property_decorate = False
        col_2A392.scale_x = 1.0
        col_2A392.scale_y = 1.0
        col_2A392.alignment = 'Expand'.upper()
        col_2A392.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_2A392.label(text='Quick Rotate', icon_value=0)
        row_9EB9D = col_2A392.row(heading='', align=True)
        row_9EB9D.alert = False
        row_9EB9D.enabled = True
        row_9EB9D.active = True
        row_9EB9D.use_property_split = False
        row_9EB9D.use_property_decorate = False
        row_9EB9D.scale_x = 1.0
        row_9EB9D.scale_y = 1.2699999809265137
        row_9EB9D.alignment = 'Expand'.upper()
        row_9EB9D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_9EB9D.operator('sna.set_rotation_axis_d9af5', text='X', icon_value=0, emboss=True, depress=bpy.context.scene.sna_x_axis)
        op.sna_axis = 'X'
        op = row_9EB9D.operator('sna.set_rotation_axis_d9af5', text='Y', icon_value=0, emboss=True, depress=bpy.context.scene.sna_y_axis)
        op.sna_axis = 'Y'
        op = row_9EB9D.operator('sna.set_rotation_axis_d9af5', text='Z', icon_value=0, emboss=True, depress=bpy.context.scene.sna_z_axis)
        op.sna_axis = 'Z'
        col_2A392.separator(factor=0.1419999599456787)
        row_68D2F = col_2A392.row(heading='', align=True)
        row_68D2F.alert = False
        row_68D2F.enabled = True
        row_68D2F.active = True
        row_68D2F.use_property_split = False
        row_68D2F.use_property_decorate = False
        row_68D2F.scale_x = 1.0
        row_68D2F.scale_y = 1.2699999809265137
        row_68D2F.alignment = 'Expand'.upper()
        row_68D2F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_7E472 = row_68D2F.row(heading='', align=True)
        row_7E472.alert = False
        row_7E472.enabled = True
        row_7E472.active = True
        row_7E472.use_property_split = False
        row_7E472.use_property_decorate = False
        row_7E472.scale_x = 1.5
        row_7E472.scale_y = 1.2000000476837158
        row_7E472.alignment = 'Expand'.upper()
        row_7E472.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_7E472.operator('sna.set_is_positive_axis_fd57d', text='', icon_value=87, emboss=True, depress=(not bpy.context.scene.sna_ispositive))
        op.sna_positiveclicked = False
        op = row_7E472.operator('sna.set_is_positive_axis_fd57d', text='', icon_value=45, emboss=True, depress=bpy.context.scene.sna_ispositive)
        op.sna_positiveclicked = True
        row_852CA = row_68D2F.row(heading='', align=False)
        row_852CA.alert = False
        row_852CA.enabled = True
        row_852CA.active = True
        row_852CA.use_property_split = False
        row_852CA.use_property_decorate = False
        row_852CA.scale_x = 1.0
        row_852CA.scale_y = 1.2699999809265137
        row_852CA.alignment = 'Expand'.upper()
        row_852CA.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_852CA.operator('sna.quick_rotate_active_object_db0ac', text='15', icon_value=0, emboss=True, depress=False)
        op.sna_amount = 15.0
        op = row_852CA.operator('sna.quick_rotate_active_object_db0ac', text='45', icon_value=0, emboss=True, depress=False)
        op.sna_amount = 45.0
        op = row_852CA.operator('sna.quick_rotate_active_object_db0ac', text='90', icon_value=0, emboss=True, depress=False)
        op.sna_amount = 90.0
        box_EF552 = layout.box()
        box_EF552.alert = False
        box_EF552.enabled = True
        box_EF552.active = True
        box_EF552.use_property_split = False
        box_EF552.use_property_decorate = False
        box_EF552.alignment = 'Expand'.upper()
        box_EF552.scale_x = 1.0
        box_EF552.scale_y = 1.0
        if not True: box_EF552.operator_context = "EXEC_DEFAULT"
        col_909AE = box_EF552.column(heading='', align=False)
        col_909AE.alert = False
        col_909AE.enabled = True
        col_909AE.active = True
        col_909AE.use_property_split = False
        col_909AE.use_property_decorate = False
        col_909AE.scale_x = 1.0
        col_909AE.scale_y = 1.0
        col_909AE.alignment = 'Expand'.upper()
        col_909AE.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_909AE.label(text='Explode Options', icon_value=0)
        col_909AE.prop(bpy.context.scene, 'sna_margin', text='Margin', icon_value=0, emboss=True)
        col_909AE.prop(bpy.context.scene, 'sna_items', text='Axis', icon_value=0, emboss=True)
        row_DD7F3 = col_909AE.row(heading='', align=True)
        row_DD7F3.alert = False
        row_DD7F3.enabled = True
        row_DD7F3.active = True
        row_DD7F3.use_property_split = False
        row_DD7F3.use_property_decorate = False
        row_DD7F3.scale_x = 1.0
        row_DD7F3.scale_y = 1.2699999809265137
        row_DD7F3.alignment = 'Expand'.upper()
        row_DD7F3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_CFA20 = row_DD7F3.column(heading='', align=True)
        col_CFA20.alert = False
        col_CFA20.enabled = True
        col_CFA20.active = True
        col_CFA20.use_property_split = False
        col_CFA20.use_property_decorate = False
        col_CFA20.scale_x = 1.0
        col_CFA20.scale_y = 2.0
        col_CFA20.alignment = 'Expand'.upper()
        col_CFA20.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_CFA20.operator('sna.explode_selected_05499', text='Explode', icon_value=441, emboss=True, depress=False)
        row_5C81D = row_DD7F3.row(heading='', align=True)
        row_5C81D.alert = False
        row_5C81D.enabled = True
        row_5C81D.active = True
        row_5C81D.use_property_split = False
        row_5C81D.use_property_decorate = False
        row_5C81D.scale_x = 1.0
        row_5C81D.scale_y = 1.0
        row_5C81D.alignment = 'Right'.upper()
        row_5C81D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_CF894 = row_5C81D.column(heading='', align=True)
        col_CF894.alert = False
        col_CF894.enabled = True
        col_CF894.active = True
        col_CF894.use_property_split = False
        col_CF894.use_property_decorate = False
        col_CF894.scale_x = 1.1799999475479126
        col_CF894.scale_y = 1.0
        col_CF894.alignment = 'Expand'.upper()
        col_CF894.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_CF894.operator('sna.reset_all_world_origin_943b2', text='', icon_value=647, emboss=True, depress=False)
        op = col_CF894.operator('view3d.snap_selected_to_cursor', text='', icon_value=548, emboss=True, depress=False)


class SNA_OT_Explode_Selected_05499(bpy.types.Operator):
    bl_idname = "sna.explode_selected_05499"
    bl_label = "Explode Selected"
    bl_description = "Evenly space all selected objects along specified axis"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnexplodeselected_32E49()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnexplodeselected_32E49():
    objects = bpy.context.view_layer.objects.selected
    margin = bpy.context.scene.sna_margin
    axis = bpy.context.scene.sna_items

    def explode_objects(objects, axis, margin):
        # Sort objects based on their current location
        sorted_objects = sorted(objects, key=lambda obj: obj.location)
        # Get the starting position at (0, 0, 0)
        current_position = Vector((0, 0, 0))
        # Explode objects along the chosen axis
        for obj in sorted_objects:
            bbox = get_bbox(obj)
            obj.location = current_position
            # Update position based on bounding box size + margin along the chosen axis
            if axis == 'x':
                current_position.x += bbox['size'].x + margin
            elif axis == '-x':
                current_position.x -= bbox['size'].x + margin
            elif axis == 'y':
                current_position.y += bbox['size'].y + margin
            elif axis == '-y':
                current_position.y -= bbox['size'].y + margin
            elif axis == 'z':
                current_position.z += bbox['size'].z + margin
            elif axis == '-z':
                current_position.z -= bbox['size'].z + margin

    def get_bbox(obj):
        corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
        # Get world space Min / Max
        box_min = Vector((corners[0].x, corners[0].y, corners[0].z))
        box_max = Vector((corners[0].x, corners[0].y, corners[0].z))
        for corner in corners:
            box_min.x = min(box_min.x, corner.x)
            box_min.y = min(box_min.y, corner.y)
            box_min.z = min(box_min.z, corner.z)
            box_max.x = max(box_max.x, corner.x)
            box_max.y = max(box_max.y, corner.y)
            box_max.z = max(box_max.z, corner.z)
        return {
            'min': box_min, 
            'max': box_max, 
            'size': box_max - box_min,
            'center': box_min + (box_max - box_min) / 2
        }
    explode_objects(objects, axis, margin)


class SNA_OT_Reset_All_World_Origin_943B2(bpy.types.Operator):
    bl_idname = "sna.reset_all_world_origin_943b2"
    bl_label = "Reset All World Origin"
    bl_description = "Set location of selected objects to 0,0,0"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnresettoworld_9870B()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnresettoworld_9870B():
    for i_9FC85 in range(len(bpy.context.view_layer.objects.selected)):
        bpy.context.view_layer.objects.selected[i_9FC85].location = (0.0, 0.0, 0.0)


class SNA_PT_SETTINGS_PANEL_F2E9C(bpy.types.Panel):
    bl_label = 'Settings Panel'
    bl_idname = 'SNA_PT_SETTINGS_PANEL_F2E9C'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 5
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not bpy.context.scene.sna_showrendersettings))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Compendium Settings', icon_value=0)
        box_407F8 = layout.box()
        box_407F8.alert = False
        box_407F8.enabled = True
        box_407F8.active = True
        box_407F8.use_property_split = False
        box_407F8.use_property_decorate = False
        box_407F8.alignment = 'Expand'.upper()
        box_407F8.scale_x = 1.0
        box_407F8.scale_y = 1.0
        if not True: box_407F8.operator_context = "EXEC_DEFAULT"
        box_407F8.prop(bpy.context.scene, 'sna_usecompendiumempty', text='Use Compendium Empty', icon_value=0, emboss=True)
        box_407F8.prop(bpy.context.preferences.inputs, 'use_mouse_emulate_3_button', text='Emulate Mouse 3', icon_value=0, emboss=True)
        layout.label(text='File Presets:', icon_value=0)
        box_11461 = layout.box()
        box_11461.alert = False
        box_11461.enabled = True
        box_11461.active = True
        box_11461.use_property_split = False
        box_11461.use_property_decorate = False
        box_11461.alignment = 'Expand'.upper()
        box_11461.scale_x = 1.0
        box_11461.scale_y = 1.0
        if not True: box_11461.operator_context = "EXEC_DEFAULT"
        col_EFDAA = box_11461.column(heading='', align=False)
        col_EFDAA.alert = False
        col_EFDAA.enabled = True
        col_EFDAA.active = True
        col_EFDAA.use_property_split = False
        col_EFDAA.use_property_decorate = False
        col_EFDAA.scale_x = 1.0
        col_EFDAA.scale_y = 1.0
        col_EFDAA.alignment = 'Expand'.upper()
        col_EFDAA.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_EFDAA.label(text='Workspace', icon_value=0)
        op = col_EFDAA.operator('sna.snap_to_face_preset_5ffa6', text='Snap To Face', icon_value=564, emboss=True, depress=False)
        col_350B9 = box_11461.column(heading='', align=False)
        col_350B9.alert = False
        col_350B9.enabled = True
        col_350B9.active = True
        col_350B9.use_property_split = False
        col_350B9.use_property_decorate = False
        col_350B9.scale_x = 1.0
        col_350B9.scale_y = 1.0
        col_350B9.alignment = 'Expand'.upper()
        col_350B9.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_350B9.label(text='UE5', icon_value=0)
        row_930E4 = col_350B9.row(heading='', align=True)
        row_930E4.alert = False
        row_930E4.enabled = True
        row_930E4.active = True
        row_930E4.use_property_split = False
        row_930E4.use_property_decorate = False
        row_930E4.scale_x = 1.0
        row_930E4.scale_y = 1.0
        row_930E4.alignment = 'Expand'.upper()
        row_930E4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_930E4.operator('sna.ue_projects_settings_d25db', text='UE Project Setttings', icon_value=664, emboss=True, depress=False)
        layout.label(text='Render Settings:', icon_value=0)
        box_DBA4D = layout.box()
        box_DBA4D.alert = False
        box_DBA4D.enabled = True
        box_DBA4D.active = True
        box_DBA4D.use_property_split = False
        box_DBA4D.use_property_decorate = False
        box_DBA4D.alignment = 'Expand'.upper()
        box_DBA4D.scale_x = 1.0
        box_DBA4D.scale_y = 1.0
        if not True: box_DBA4D.operator_context = "EXEC_DEFAULT"
        box_DBA4D.prop(bpy.context.scene.render, 'film_transparent', text='Transparent Background', icon_value=0, emboss=True)
        box_47E4A = box_DBA4D.box()
        box_47E4A.alert = False
        box_47E4A.enabled = True
        box_47E4A.active = True
        box_47E4A.use_property_split = False
        box_47E4A.use_property_decorate = False
        box_47E4A.alignment = 'Expand'.upper()
        box_47E4A.scale_x = 1.0
        box_47E4A.scale_y = 1.0
        if not True: box_47E4A.operator_context = "EXEC_DEFAULT"
        col_6E868 = box_47E4A.column(heading='', align=False)
        col_6E868.alert = False
        col_6E868.enabled = True
        col_6E868.active = True
        col_6E868.use_property_split = False
        col_6E868.use_property_decorate = False
        col_6E868.scale_x = 1.0
        col_6E868.scale_y = 1.0
        col_6E868.alignment = 'Expand'.upper()
        col_6E868.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_6E868.label(text='Screen Res', icon_value=0)
        row_3DB22 = col_6E868.row(heading='', align=True)
        row_3DB22.alert = False
        row_3DB22.enabled = True
        row_3DB22.active = True
        row_3DB22.use_property_split = False
        row_3DB22.use_property_decorate = False
        row_3DB22.scale_x = 1.0
        row_3DB22.scale_y = 1.0
        row_3DB22.alignment = 'Expand'.upper()
        row_3DB22.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_3DB22.operator('sna.set_screen_reset_45d5e', text='Low', icon_value=0, emboss=True, depress=False)
        op.sna_xres = 1280
        op.sna_yres = 720
        op = row_3DB22.operator('sna.set_screen_reset_45d5e', text='Full HD', icon_value=0, emboss=True, depress=False)
        op.sna_xres = 1920
        op.sna_yres = 1080
        op = row_3DB22.operator('sna.set_screen_reset_45d5e', text='Full HD', icon_value=0, emboss=True, depress=False)
        op.sna_xres = 2560
        op.sna_yres = 1440
        box_5A13A = box_DBA4D.box()
        box_5A13A.alert = False
        box_5A13A.enabled = True
        box_5A13A.active = True
        box_5A13A.use_property_split = False
        box_5A13A.use_property_decorate = False
        box_5A13A.alignment = 'Expand'.upper()
        box_5A13A.scale_x = 1.0
        box_5A13A.scale_y = 1.0
        if not True: box_5A13A.operator_context = "EXEC_DEFAULT"
        col_D0A88 = box_5A13A.column(heading='', align=False)
        col_D0A88.alert = False
        col_D0A88.enabled = True
        col_D0A88.active = True
        col_D0A88.use_property_split = False
        col_D0A88.use_property_decorate = False
        col_D0A88.scale_x = 1.0
        col_D0A88.scale_y = 1.0
        col_D0A88.alignment = 'Expand'.upper()
        col_D0A88.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_D0A88.label(text='Square Res', icon_value=0)
        row_E2A29 = col_D0A88.row(heading='', align=True)
        row_E2A29.alert = False
        row_E2A29.enabled = True
        row_E2A29.active = True
        row_E2A29.use_property_split = False
        row_E2A29.use_property_decorate = False
        row_E2A29.scale_x = 1.0
        row_E2A29.scale_y = 1.0
        row_E2A29.alignment = 'Expand'.upper()
        row_E2A29.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_E2A29.operator('sna.set_square_preset_18bb4', text='720', icon_value=0, emboss=True, depress=False)
        op.sna_resolution = 720
        op = row_E2A29.operator('sna.set_square_preset_18bb4', text='1080', icon_value=0, emboss=True, depress=False)
        op.sna_resolution = 1080
        op = row_E2A29.operator('sna.set_square_preset_18bb4', text='1920', icon_value=0, emboss=True, depress=False)
        op.sna_resolution = 1920
        box_DBA4D.prop(bpy.context.scene.render.image_settings, 'file_format', text='', icon_value=0, emboss=True)


class SNA_PT_VERTEX_PAINT_TOOLS_CAE53(bpy.types.Panel):
    bl_label = 'Vertex Paint Tools'
    bl_idname = 'SNA_PT_VERTEX_PAINT_TOOLS_CAE53'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'VCM'
    bl_order = 3
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not 'PAINT_VERTEX'==bpy.context.mode))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_fnviewportuniversal_70EA3(layout_function, )


class SNA_PT_WEIGHT_PAINT_TOOLS_6B5ED(bpy.types.Panel):
    bl_label = 'Weight Paint Tools'
    bl_idname = 'SNA_PT_WEIGHT_PAINT_TOOLS_6B5ED'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 3
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not ('PAINT_WEIGHT'==bpy.context.mode and bpy.context.scene.sna_showtools)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_1BB24 = layout.column(heading='', align=False)
        col_1BB24.alert = False
        col_1BB24.enabled = True
        col_1BB24.active = True
        col_1BB24.use_property_split = False
        col_1BB24.use_property_decorate = False
        col_1BB24.scale_x = 1.0
        col_1BB24.scale_y = 1.0
        col_1BB24.alignment = 'Expand'.upper()
        col_1BB24.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_1BB24.separator(factor=1.0)
        col_1BB24.label(text='Weight Paint', icon_value=0)
        row_8451C = col_1BB24.row(heading='', align=True)
        row_8451C.alert = False
        row_8451C.enabled = True
        row_8451C.active = True
        row_8451C.use_property_split = False
        row_8451C.use_property_decorate = False
        row_8451C.scale_x = 1.4500000476837158
        row_8451C.scale_y = 1.3899999856948853
        row_8451C.alignment = 'Expand'.upper()
        row_8451C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_E7972 = row_8451C.row(heading='', align=True)
        row_E7972.alert = False
        row_E7972.enabled = True
        row_E7972.active = True
        row_E7972.use_property_split = False
        row_E7972.use_property_decorate = False
        row_E7972.scale_x = 1.0
        row_E7972.scale_y = 1.0
        row_E7972.alignment = 'Expand'.upper()
        row_E7972.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_E7972.prop(bpy.data.scenes['Scene'].tool_settings.unified_paint_settings, 'weight', text='Weight', icon_value=0, emboss=True)
        row_0F41B = row_8451C.row(heading='', align=True)
        row_0F41B.alert = False
        row_0F41B.enabled = True
        row_0F41B.active = True
        row_0F41B.use_property_split = False
        row_0F41B.use_property_decorate = False
        row_0F41B.scale_x = 1.0
        row_0F41B.scale_y = 1.0
        row_0F41B.alignment = 'Right'.upper()
        row_0F41B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_0F41B.operator('sna.custom_set_weight_2f5d4', text='', icon_value=124, emboss=True, depress=False)


class SNA_OT_Custom_Set_Weight_2F5D4(bpy.types.Operator):
    bl_idname = "sna.custom_set_weight_2f5d4"
    bl_label = "Custom Set Weight"
    bl_description = "Set weight of selected verts and refreshes view"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        prev_context = bpy.context.area.type
        bpy.context.area.type = 'VIEW_3D'
        bpy.ops.paint.weight_set('INVOKE_DEFAULT', )
        bpy.context.area.type = prev_context
        if bpy.context and bpy.context.screen:
            for a in bpy.context.screen.areas:
                a.tag_redraw()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_WORKFLOW_304C1(bpy.types.Panel):
    bl_label = 'Workflow'
    bl_idname = 'SNA_PT_WORKFLOW_304C1'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 2
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not bpy.context.scene.sna_showworkflow))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Viewport', icon_value=0)
        box_7A73C = layout.box()
        box_7A73C.alert = False
        box_7A73C.enabled = True
        box_7A73C.active = True
        box_7A73C.use_property_split = False
        box_7A73C.use_property_decorate = False
        box_7A73C.alignment = 'Expand'.upper()
        box_7A73C.scale_x = 1.0
        box_7A73C.scale_y = 1.0
        if not True: box_7A73C.operator_context = "EXEC_DEFAULT"
        layout_function = box_7A73C
        sna_fnviewportuniversal_70EA3(layout_function, )
        if 'EDIT_MESH'==bpy.context.mode:
            row_02D6E = box_7A73C.row(heading='', align=True)
            row_02D6E.alert = False
            row_02D6E.enabled = True
            row_02D6E.active = True
            row_02D6E.use_property_split = False
            row_02D6E.use_property_decorate = False
            row_02D6E.scale_x = 1.0
            row_02D6E.scale_y = 1.100000023841858
            row_02D6E.alignment = 'Expand'.upper()
            row_02D6E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_02D6E.operator('sna.toggle_show_creases_48169', text='Crease', icon_value=0, emboss=True, depress=bpy.context.area.spaces.active.overlay.show_edge_crease)
            op = row_02D6E.operator('sna.toggle_show_sharps_28e50', text='Sharp', icon_value=0, emboss=True, depress=bpy.context.area.spaces.active.overlay.show_edge_sharp)
            op = row_02D6E.operator('sna.toggle_show_bevels_cb2f7', text='Bevel', icon_value=0, emboss=True, depress=bpy.context.area.spaces.active.overlay.show_edge_bevel_weight)
            op = row_02D6E.operator('sna.toggle_show_seams_7408d', text='Seams', icon_value=0, emboss=True, depress=bpy.context.area.spaces.active.overlay.show_edge_seams)
        if (bpy.context.view_layer.objects.active == None):
            pass
        else:
            if bpy.context.view_layer.objects.active.type == 'CAMERA':
                box_7A73C.prop(bpy.context.area.spaces[0], 'lock_camera', text='Camera To View', icon_value=(621 if bpy.context.area.spaces[0].lock_camera else 617), emboss=True)
        if (bpy.context.view_layer.objects.active == None):
            pass
        else:
            if bpy.context.view_layer.objects.active.type == 'CAMERA':
                box_0A973 = box_7A73C.box()
                box_0A973.alert = False
                box_0A973.enabled = True
                box_0A973.active = True
                box_0A973.use_property_split = False
                box_0A973.use_property_decorate = False
                box_0A973.alignment = 'Expand'.upper()
                box_0A973.scale_x = 1.0
                box_0A973.scale_y = 1.0
                if not True: box_0A973.operator_context = "EXEC_DEFAULT"
                col_569F9 = box_0A973.column(heading='', align=False)
                col_569F9.alert = False
                col_569F9.enabled = True
                col_569F9.active = True
                col_569F9.use_property_split = False
                col_569F9.use_property_decorate = False
                col_569F9.scale_x = 1.0
                col_569F9.scale_y = 1.0
                col_569F9.alignment = 'Expand'.upper()
                col_569F9.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                col_569F9.label(text='Camera Locations', icon_value=0)
                row_65B5A = col_569F9.row(heading='', align=True)
                row_65B5A.alert = False
                row_65B5A.enabled = True
                row_65B5A.active = True
                row_65B5A.use_property_split = False
                row_65B5A.use_property_decorate = False
                row_65B5A.scale_x = 1.0
                row_65B5A.scale_y = 1.0
                row_65B5A.alignment = 'Expand'.upper()
                row_65B5A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_FD1A0 = row_65B5A.row(heading='', align=False)
                row_FD1A0.alert = False
                row_FD1A0.enabled = True
                row_FD1A0.active = True
                row_FD1A0.use_property_split = False
                row_FD1A0.use_property_decorate = False
                row_FD1A0.scale_x = 1.0
                row_FD1A0.scale_y = 1.0
                row_FD1A0.alignment = 'Expand'.upper()
                row_FD1A0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_FD1A0.prop(bpy.context.scene, 'sna_locationname', text='', icon_value=0, emboss=True)
                row_D10F3 = row_65B5A.row(heading='', align=False)
                row_D10F3.alert = False
                row_D10F3.enabled = True
                row_D10F3.active = True
                row_D10F3.use_property_split = False
                row_D10F3.use_property_decorate = False
                row_D10F3.scale_x = 1.0
                row_D10F3.scale_y = 1.0
                row_D10F3.alignment = 'Right'.upper()
                row_D10F3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                op = row_D10F3.operator('sna.add_camera_loaction_1e5f9', text='', icon_value=31, emboss=True, depress=False)
                col_569F9.separator(factor=1.0)
                for i_25855 in range(len(bpy.context.scene.sna_camlocs)):
                    row_3F6B2 = col_569F9.row(heading='', align=True)
                    row_3F6B2.alert = False
                    row_3F6B2.enabled = True
                    row_3F6B2.active = True
                    row_3F6B2.use_property_split = False
                    row_3F6B2.use_property_decorate = False
                    row_3F6B2.scale_x = 1.0
                    row_3F6B2.scale_y = 1.0
                    row_3F6B2.alignment = 'Expand'.upper()
                    row_3F6B2.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                    row_71A8B = row_3F6B2.row(heading='', align=True)
                    row_71A8B.alert = False
                    row_71A8B.enabled = True
                    row_71A8B.active = True
                    row_71A8B.use_property_split = False
                    row_71A8B.use_property_decorate = False
                    row_71A8B.scale_x = 1.0
                    row_71A8B.scale_y = 1.0
                    row_71A8B.alignment = 'Expand'.upper()
                    row_71A8B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                    op = row_71A8B.operator('sna.setcameratolocation_78754', text=bpy.context.scene.sna_camlocs[i_25855].name, icon_value=0, emboss=True, depress=False)
                    op.sna_id = i_25855
                    row_6D4AC = row_3F6B2.row(heading='', align=True)
                    row_6D4AC.alert = False
                    row_6D4AC.enabled = True
                    row_6D4AC.active = True
                    row_6D4AC.use_property_split = False
                    row_6D4AC.use_property_decorate = False
                    row_6D4AC.scale_x = 1.0
                    row_6D4AC.scale_y = 1.0
                    row_6D4AC.alignment = 'Right'.upper()
                    row_6D4AC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                    op = row_6D4AC.operator('sna.remove_camera_location_37a38', text='', icon_value=87, emboss=True, depress=False)
                    op.sna_id = i_25855
        col_E705A = layout.column(heading='', align=True)
        col_E705A.alert = False
        col_E705A.enabled = True
        col_E705A.active = True
        col_E705A.use_property_split = False
        col_E705A.use_property_decorate = False
        col_E705A.scale_x = 1.0
        col_E705A.scale_y = 1.0
        col_E705A.alignment = 'Expand'.upper()
        col_E705A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_E705A.operator('sna.toggle_workflow_options_05d4c', text='', icon_value=(31 if bpy.context.scene.sna_showwfoptions else 30), emboss=True, depress=False)
        if bpy.context.scene.sna_showwfoptions:
            row_4E062 = col_E705A.row(heading='', align=True)
            row_4E062.alert = False
            row_4E062.enabled = True
            row_4E062.active = True
            row_4E062.use_property_split = False
            row_4E062.use_property_decorate = False
            row_4E062.scale_x = 1.0
            row_4E062.scale_y = 1.0
            row_4E062.alignment = 'Expand'.upper()
            row_4E062.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_4E062.operator('sna.set_sculpt_workflow_27f56', text='Sculpt', icon_value=0, emboss=True, depress=bpy.context.scene.sna_sculptworkflow)
            op = row_4E062.operator('sna.set_vertex_paint_workflow_b1688', text='Vertex', icon_value=0, emboss=True, depress=bpy.context.scene.sna_vpworkflow)
            op = row_4E062.operator('sna.set_weight_paint_workflow_c2eda', text='Weight', icon_value=0, emboss=True, depress=bpy.context.scene.sna_wpworkflow)
        if bpy.context.scene.sna_wpworkflow:
            row_33757 = layout.row(heading='', align=True)
            row_33757.alert = False
            row_33757.enabled = True
            row_33757.active = True
            row_33757.use_property_split = False
            row_33757.use_property_decorate = False
            row_33757.scale_x = 1.0
            row_33757.scale_y = 1.0
            row_33757.alignment = 'Expand'.upper()
            row_33757.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_33757.label(text='Auto Select', icon_value=0)
            op = row_33757.operator('sna.toggleautoselectarmature_c5316', text='None', icon_value=0, emboss=True, depress=(bpy.context.scene.sna_selectweightpaintmode == 'NoAuto'))
            op.sna_selection = 'NoAuto'
            op = row_33757.operator('sna.toggleautoselectarmature_c5316', text='Vetex', icon_value=0, emboss=True, depress=(bpy.context.scene.sna_selectweightpaintmode == 'Vertex'))
            op.sna_selection = 'Vertex'
            op = row_33757.operator('sna.toggleautoselectarmature_c5316', text='Armature', icon_value=0, emboss=True, depress=(bpy.context.scene.sna_selectweightpaintmode == 'Armature'))
            op.sna_selection = 'Armature'


class SNA_OT_Toggleautoselectarmature_C5316(bpy.types.Operator):
    bl_idname = "sna.toggleautoselectarmature_c5316"
    bl_label = "ToggleAutoSelectArmature"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    def sna_selection_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_selection: bpy.props.EnumProperty(name='Selection', description='', options={'HIDDEN'}, items=[('NoAuto', 'NoAuto', '', 0, 0), ('Vertex', 'Vertex', '', 0, 1), ('Armature', 'Armature', '', 0, 2)])

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if self.sna_selection == "NoAuto":
            bpy.context.scene.sna_selectweightpaintmode = self.sna_selection
        elif self.sna_selection == "Vertex":
            bpy.context.scene.sna_selectweightpaintmode = self.sna_selection
        elif self.sna_selection == "Armature":
            bpy.context.scene.sna_selectweightpaintmode = self.sna_selection
        else:
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_MT_F2EBE(bpy.types.Menu):
    bl_idname = "SNA_MT_F2EBE"
    bl_label = "Compendium Modes Pie"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.menu_pie()
        if ('OBJECT'==bpy.context.mode or 'EDIT_MESH'==bpy.context.mode):
            if bpy.context.view_layer.objects.active.type == 'MESH':
                op = layout.operator('sna.vert_mode_34ed6', text='Vert', icon_value=560, emboss=True, depress=False)
            else:
                layout.separator(factor=1.0)
        else:
            layout.separator(factor=1.0)
        if ('OBJECT'==bpy.context.mode or 'EDIT_MESH'==bpy.context.mode):
            if bpy.context.view_layer.objects.active.type == 'MESH':
                op = layout.operator('sna.face_mode_44e6b', text='Face', icon_value=548, emboss=True, depress=False)
            else:
                layout.separator(factor=1.0)
        else:
            layout.separator(factor=1.0)
        if ('OBJECT'==bpy.context.mode or 'EDIT_MESH'==bpy.context.mode):
            if bpy.context.view_layer.objects.active.type == 'MESH':
                op = layout.operator('sna.edge_mode_74d78', text='Edge', icon_value=547, emboss=True, depress=False)
            else:
                layout.separator(factor=1.0)
        else:
            layout.separator(factor=1.0)
        if 'OBJECT'==bpy.context.mode:
            op = layout.operator('object.mode_set', text='Edit', icon_value=149, emboss=True, depress=False)
            op.mode = 'EDIT'
        else:
            op = layout.operator('object.mode_set', text='Object', icon_value=150, emboss=True, depress=False)
            op.mode = 'OBJECT'
        if 'POSE'==bpy.context.mode:
            layout.separator(factor=1.0)
        else:
            if bpy.context.view_layer.objects.active.type == 'ARMATURE':
                layout.separator(factor=1.0)
            else:
                row_43D41 = layout.row(heading='', align=True)
                row_43D41.alert = False
                row_43D41.enabled = True
                row_43D41.active = True
                row_43D41.use_property_split = False
                row_43D41.use_property_decorate = False
                row_43D41.scale_x = 1.2999999523162842
                row_43D41.scale_y = 1.2999999523162842
                row_43D41.alignment = 'Expand'.upper()
                row_43D41.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                op = row_43D41.operator('object.mode_set', text='', icon_value=154, emboss=True, depress=False)
                op.mode = 'TEXTURE_PAINT'
                op = row_43D41.operator('object.mode_set', text='', icon_value=157, emboss=True, depress=False)
                op.mode = 'WEIGHT_PAINT'
                op = row_43D41.operator('sna.set_vertex_paint_mode_8ba67', text='', icon_value=156, emboss=True, depress=False)
                op = row_43D41.operator('object.mode_set', text='', icon_value=153, emboss=True, depress=False)
                op.mode = 'SCULPT'
                op = row_43D41.operator('object.mode_set', text='', icon_value=150, emboss=True, depress=False)
                op.mode = 'OBJECT'
                op = row_43D41.operator('object.mode_set', text='', icon_value=149, emboss=True, depress=False)
                op.mode = 'EDIT'
        if ('SCULPT'==bpy.context.mode or 'POSE'==bpy.context.mode):
            op = layout.operator('object.mode_set', text='Edit', icon_value=131, emboss=True, depress=False)
            op.mode = 'EDIT'
        else:
            if bpy.context.view_layer.objects.active.type == 'ARMATURE':
                op = layout.operator('object.mode_set', text='Pose', icon_value=152, emboss=True, depress=False)
                op.mode = 'POSE'
            else:
                if bpy.context.scene.sna_vpworkflow:
                    if 'PAINT_VERTEX'==bpy.context.mode:
                        op = layout.operator('object.mode_set', text='Edit', icon_value=149, emboss=True, depress=False)
                        op.mode = 'EDIT'
                    else:
                        op = layout.operator('sna.set_vertex_paint_mode_box_select_3230d', text='Vertex Paint', icon_value=156, emboss=True, depress=False)
                else:
                    if bpy.context.scene.sna_wpworkflow:
                        if 'PAINT_WEIGHT'==bpy.context.mode:
                            op = layout.operator('object.mode_set', text='Edit', icon_value=149, emboss=True, depress=False)
                            op.mode = 'EDIT'
                        else:
                            op = layout.operator('sna.set_weight_paint_3b8d6', text='Weight Paint', icon_value=157, emboss=True, depress=False)
                    else:
                        op = layout.operator('object.mode_set', text='Sculpt', icon_value=153, emboss=True, depress=False)
                        op.mode = 'SCULPT'
        if property_exists("bpy.context.preferences.addons['retopoflow_4']", globals(), locals()):
            op = layout.operator('sna.setpolypenselect_6a432', text='Vert/Edge', icon_value=0, emboss=True, depress=False)


class SNA_OT_Face_Mode_44E6B(bpy.types.Operator):
    bl_idname = "sna.face_mode_44e6b"
    bl_label = "Face Mode"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if 'EDIT_MESH'==bpy.context.mode:
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='FACE', action='ENABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='EDGE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='DISABLE')
        else:
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='EDIT')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='FACE', action='ENABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='EDGE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='DISABLE')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Vert_Mode_34Ed6(bpy.types.Operator):
    bl_idname = "sna.vert_mode_34ed6"
    bl_label = "Vert Mode"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if 'EDIT_MESH'==bpy.context.mode:
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='FACE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='EDGE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='ENABLE')
        else:
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='EDIT')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='FACE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='EDGE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='ENABLE')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Edge_Mode_74D78(bpy.types.Operator):
    bl_idname = "sna.edge_mode_74d78"
    bl_label = "Edge Mode"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if 'EDIT_MESH'==bpy.context.mode:
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='FACE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='EDGE', action='ENABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='DISABLE')
        else:
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='EDIT')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='FACE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='EDGE', action='ENABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='DISABLE')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Weight_Paint_3B8D6(bpy.types.Operator):
    bl_idname = "sna.set_weight_paint_3b8d6"
    bl_label = "Set Weight Paint"
    bl_description = "Custom Set weight paint mode and auto set box select mode"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.scene.sna_selectweightpaintmode == "NoAuto":
            prev_context = bpy.context.area.type
            bpy.context.area.type = 'VIEW_3D'
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='WEIGHT_PAINT')
            bpy.context.area.type = prev_context
        elif bpy.context.scene.sna_selectweightpaintmode == "Armature":
            # Get the active object
            active_obj = bpy.context.active_object
            # Make sure there's an active object and it's a mesh
            if active_obj and active_obj.type == 'MESH':
                parent = active_obj.parent
                # Check if the object has a parent and if the parent is an armature
                if parent and parent.type == 'ARMATURE':
                    # Deselect all
                    bpy.ops.object.select_all(action='DESELECT')
                    # Select the parent armature (important for bone selection to work)
                    parent.select_set(True)
                    # Make sure the mesh is active (needed for weight paint mode)
                    active_obj.select_set(True)
                    bpy.context.view_layer.objects.active = active_obj
                    # Enter Weight Paint mode
                    bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
                    # Enable bone selection in weight paint mode
                    mesh = active_obj.data
                    mesh.use_paint_mask = False
                    mesh.use_paint_mask_vertex = False
                    mesh.use_paint_bone_selection = True
                    # Select the Weight Paint Brush tool (safe method)
                    try:
                        bpy.ops.wm.tool_set_by_id(name="builtin.brush")
                        print("✅ Switched to Weight Paint mode, enabled bone selection, and selected brush tool.")
                    except Exception as e:
                        print(f"⚠️ Failed to set brush tool: {e}")
                else:
                    print("⚠️ Active object's parent is not an armature.")
            else:
                print("⚠️ No active mesh object found.")
        elif bpy.context.scene.sna_selectweightpaintmode == "Vertex":
            prev_context = bpy.context.area.type
            bpy.context.area.type = 'VIEW_3D'
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='WEIGHT_PAINT')
            bpy.context.area.type = prev_context
            bpy.context.view_layer.objects.active.data.use_paint_mask_vertex = True
            prev_context = bpy.context.area.type
            bpy.context.area.type = 'VIEW_3D'
            bpy.ops.wm.tool_set_by_id('INVOKE_DEFAULT', name='builtin.select_box')
            bpy.context.area.type = prev_context
        else:
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Vertex_Paint_Mode_Box_Select_3230D(bpy.types.Operator):
    bl_idname = "sna.set_vertex_paint_mode_box_select_3230d"
    bl_label = "Set Vertex Paint Mode Box Select"
    bl_description = "Sets Vertex Paint mode with Box Select"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if ((bpy.context.view_layer.objects.active.data.use_paint_mask_vertex or bpy.context.view_layer.objects.active.data.use_paint_mask) == False):
            bpy.context.view_layer.objects.active.data.use_paint_mask_vertex = True
            prev_context = bpy.context.area.type
            bpy.context.area.type = 'VIEW_3D'
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='VERTEX_PAINT')
            bpy.context.area.type = prev_context
            prev_context = bpy.context.area.type
            bpy.context.area.type = 'VIEW_3D'
            bpy.ops.wm.tool_set_by_id('INVOKE_DEFAULT', name='builtin.select_box')
            bpy.context.area.type = prev_context
        else:
            prev_context = bpy.context.area.type
            bpy.context.area.type = 'VIEW_3D'
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='VERTEX_PAINT')
            bpy.context.area.type = prev_context
            prev_context = bpy.context.area.type
            bpy.context.area.type = 'VIEW_3D'
            bpy.ops.wm.tool_set_by_id('INVOKE_DEFAULT', name='builtin.select_box')
            bpy.context.area.type = prev_context
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Vertex_Paint_Mode_8Ba67(bpy.types.Operator):
    bl_idname = "sna.set_vertex_paint_mode_8ba67"
    bl_label = "Set Vertex Paint Mode"
    bl_description = "Sets Vertex Paint Mode. Fixes warning if user has Box Select tool and no selection mask."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.data.use_paint_mask_vertex = True
        prev_context = bpy.context.area.type
        bpy.context.area.type = 'VIEW_3D'
        bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='VERTEX_PAINT')
        bpy.context.area.type = prev_context
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Setpolypenselect_6A432(bpy.types.Operator):
    bl_idname = "sna.setpolypenselect_6a432"
    bl_label = "SetPolyPenSelect"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='EDIT')
        bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='ENABLE')
        bpy.ops.mesh.select_mode('INVOKE_DEFAULT', use_extend=True, type='EDGE', action='ENABLE')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_MT_2C530(bpy.types.Menu):
    bl_idname = "SNA_MT_2C530"
    bl_label = "Pose Pie"

    @classmethod
    def poll(cls, context):
        return not ((not 'POSE'==bpy.context.mode))

    def draw(self, context):
        layout = self.layout.menu_pie()
        op = layout.operator('sna.set_orientation_local_059e9', text='Local', icon_value=0, emboss=True, depress=False)
        layout.separator(factor=1.0)
        op = layout.operator('sna.set_orientation_global_52453', text='Global', icon_value=0, emboss=False, depress=False)
        layout.separator(factor=1.0)
        layout.separator(factor=1.0)
        layout.separator(factor=1.0)
        op = layout.operator('sna.set_orientation_parent_9fa00', text='Parent', icon_value=0, emboss=True, depress=False)
        layout.separator(factor=1.0)


class SNA_MT_5FC8E(bpy.types.Menu):
    bl_idname = "SNA_MT_5FC8E"
    bl_label = "Scupt Tools"

    @classmethod
    def poll(cls, context):
        return not ((not 'SCULPT'==bpy.context.mode))

    def draw(self, context):
        layout = self.layout.menu_pie()
        col_ACE1B = layout.column(heading='', align=True)
        col_ACE1B.alert = False
        col_ACE1B.enabled = True
        col_ACE1B.active = True
        col_ACE1B.use_property_split = False
        col_ACE1B.use_property_decorate = False
        col_ACE1B.scale_x = 1.0
        col_ACE1B.scale_y = 1.2000000476837158
        col_ACE1B.alignment = 'Expand'.upper()
        col_ACE1B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_ACE1B.operator('brush.asset_activate', text='Inflate', icon_value=0, emboss=True, depress=False)
        op.asset_library_type = 'ESSENTIALS'
        op.relative_asset_identifier = 'brushes\\essentials_brushes-mesh_sculpt.blend\\Brush\\Inflate/Deflate'
        op = col_ACE1B.operator('brush.asset_activate', text='Snake', icon_value=0, emboss=True, depress=False)
        op.asset_library_type = 'ESSENTIALS'
        op.relative_asset_identifier = 'brushes\\essentials_brushes-mesh_sculpt.blend\\Brush\\Snake Hook'
        op = col_ACE1B.operator('brush.asset_activate', text='Clay', icon_value=0, emboss=True, depress=False)
        op.asset_library_type = 'ESSENTIALS'
        op.relative_asset_identifier = 'brushes\\essentials_brushes-mesh_sculpt.blend\\Brush\\Clay'
        op = col_ACE1B.operator('brush.asset_activate', text='Smooth', icon_value=0, emboss=True, depress=False)
        op.asset_library_type = 'ESSENTIALS'
        op.relative_asset_identifier = 'brushes\\essentials_brushes-mesh_sculpt.blend\\Brush\\Smooth'
        op = layout.operator('brush.asset_activate', text='Grab', icon_value=619, emboss=True, depress=False)
        op.asset_library_type = 'ESSENTIALS'
        op.relative_asset_identifier = 'brushes\\essentials_brushes-mesh_sculpt.blend\\Brush\\Grab'
        op = layout.operator('brush.asset_activate', text='Relax', icon_value=0, emboss=True, depress=False)
        op.asset_library_type = 'ESSENTIALS'
        op.relative_asset_identifier = 'brushes\\essentials_brushes-mesh_sculpt.blend\\Brush\\Relax Slide'
        row_8FF7C = layout.row(heading='', align=False)
        row_8FF7C.alert = False
        row_8FF7C.enabled = True
        row_8FF7C.active = True
        row_8FF7C.use_property_split = False
        row_8FF7C.use_property_decorate = False
        row_8FF7C.scale_x = 1.0
        row_8FF7C.scale_y = 1.0
        row_8FF7C.alignment = 'Expand'.upper()
        row_8FF7C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_8FF7C.prop(bpy.data.scenes['Scene'].tool_settings.unified_paint_settings, 'size', text='', icon_value=0, emboss=True)
        row_8FF7C.prop(bpy.context.view_layer.objects.active, 'show_wire', text='', icon_value=613, emboss=True)
        layout.separator(factor=1.0)
        layout.separator(factor=1.0)


def sna_add_to_view3d_ht_tool_header_15313(self, context):
    if not ((not 'SCULPT'==bpy.context.mode)):
        layout = self.layout
        op = layout.operator('sna.set_smooth_strength_f31e6', text='', icon_value=7, emboss=True, depress=False)


class SNA_OT_Set_Smooth_Strength_F31E6(bpy.types.Operator):
    bl_idname = "sna.set_smooth_strength_f31e6"
    bl_label = "Set Smooth Strength"
    bl_description = "Sets the strength of the smooth brush lower for working with mouse"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        b_name = bpy.context.tool_settings.sculpt.brush.name
        brush_path = None

        def format_brush_relative_id(brush_name: str) -> str:
            return f"brushes\\essentials_brushes-mesh_sculpt.blend\\Brush\\{brush_name}"
        brush_path = format_brush_relative_id(b_name)
        pie__sculpt['sna_brushpath'] = brush_path
        bpy.ops.brush.asset_activate('INVOKE_DEFAULT', asset_library_type='ESSENTIALS', relative_asset_identifier='brushes\\essentials_brushes-mesh_sculpt.blend\\Brush\\Smooth')
        bpy.context.tool_settings.sculpt.brush.strength = 0.20000000298023224
        bpy.ops.brush.asset_activate('INVOKE_DEFAULT', asset_library_type='ESSENTIALS', relative_asset_identifier=pie__sculpt['sna_brushpath'])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_MT_30393(bpy.types.Menu):
    bl_idname = "SNA_MT_30393"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not ((not (bpy.context.area.ui_type == 'UV')))

    def draw(self, context):
        layout = self.layout.menu_pie()
        layout.separator(factor=1.0)
        layout.separator(factor=1.0)
        layout.separator(factor=1.0)
        op = layout.operator('sna.toggle_show_stretch_8ca4e', text='Show Stretch', icon_value=0, emboss=True, depress=bpy.context.area.spaces[0].uv_editor.show_stretch)


class SNA_MT_B55D7(bpy.types.Menu):
    bl_idname = "SNA_MT_B55D7"
    bl_label = "Vertex Paint Pie"

    @classmethod
    def poll(cls, context):
        return not ((not ('PAINT_VERTEX'==bpy.context.mode and property_exists("bpy.context.preferences.addons['bl_ext.user_default.vertex_color_master']", globals(), locals()))))

    def draw(self, context):
        layout = self.layout.menu_pie()
        op = layout.operator('vertexcolormaster.gradient', text='Linear Gradient', icon_value=0, emboss=True, depress=False)
        op = layout.operator('paint.vertex_color_set', text='Fill', icon_value=0, emboss=True, depress=False)


class SNA_GROUP_sna_transforminfo(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name='Name', description='', default='', subtype='NONE', maxlen=0)
    location: bpy.props.FloatVectorProperty(name='Location', description='', size=3, default=(0.0, 0.0, 0.0), subtype='TRANSLATION', unit='LENGTH', step=3, precision=6)
    rotation: bpy.props.FloatVectorProperty(name='Rotation', description='', size=4, default=(0.0, 0.0, 0.0, 0.0), subtype='QUATERNION', unit='ROTATION', step=3, precision=6)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_GROUP_sna_transforminfo)
    bpy.types.Scene.sna_newcollectionname = bpy.props.StringProperty(name='NewCollectionName', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_showtools = bpy.props.BoolProperty(name='ShowTools', description='', default=True)
    bpy.types.Scene.sna_showrendersettings = bpy.props.BoolProperty(name='ShowRenderSettings', description='', default=False)
    bpy.types.Scene.sna_showiteminfo = bpy.props.BoolProperty(name='ShowItemInfo', description='', default=False)
    bpy.types.Scene.sna_showworkflow = bpy.props.BoolProperty(name='ShowWorkflow', description='', default=False)
    bpy.types.Scene.sna_showops = bpy.props.BoolProperty(name='ShowOps', description='', default=False)
    bpy.types.Scene.sna_usecompendiumempty = bpy.props.BoolProperty(name='UseCompendiumEmpty', description='', default=True)
    bpy.types.Object.sna_lastcollection = bpy.props.StringProperty(name='LastCollection', description='', default='original', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_sculptworkflow = bpy.props.BoolProperty(name='SculptWorkflow', description='', default=True)
    bpy.types.Scene.sna_vpworkflow = bpy.props.BoolProperty(name='VPWorkflow', description='', default=False)
    bpy.types.Scene.sna_wpworkflow = bpy.props.BoolProperty(name='WPWorkflow', description='', default=False)
    bpy.types.Scene.sna_camlocs = bpy.props.CollectionProperty(name='CamLocs', description='', type=SNA_GROUP_sna_transforminfo)
    bpy.types.Scene.sna_locationname = bpy.props.StringProperty(name='LocationName', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_showwfoptions = bpy.props.BoolProperty(name='ShowWFOptions', description='', default=False)
    bpy.types.Scene.sna_margin = bpy.props.FloatProperty(name='Margin', description='Space between objects', default=1.0, subtype='NONE', unit='NONE', step=3, precision=2)
    bpy.types.Scene.sna_items = bpy.props.EnumProperty(name='Items', description='', items=[('x', 'x', 'Positive X', 0, 0), ('y', 'y', 'Positive Y', 0, 1), ('z', 'z', 'Positive Z', 0, 2), ('-x', '-x', 'Negative X', 0, 3), ('-y', '-y', 'Negative Y', 0, 4), ('-z', '-z', 'Negative Z', 0, 5)])
    bpy.types.Scene.sna_x_axis = bpy.props.BoolProperty(name='X_Axis', description='', default=True)
    bpy.types.Scene.sna_y_axis = bpy.props.BoolProperty(name='Y_Axis', description='', default=False)
    bpy.types.Scene.sna_z_axis = bpy.props.BoolProperty(name='Z_Axis', description='', default=False)
    bpy.types.Scene.sna_ispositive = bpy.props.BoolProperty(name='IsPositive', description='', default=True)
    bpy.types.Scene.sna_selectweightpaintmode = bpy.props.EnumProperty(name='SelectWeightPaintMode', description='', items=[('NoAuto', 'NoAuto', '', 0, 0), ('Vertex', 'Vertex', '', 0, 1), ('Armature', 'Armature', '', 0, 2)])
    bpy.types.DOPESHEET_MT_editor_menus.append(sna_add_to_dopesheet_mt_editor_menus_3436A)
    bpy.utils.register_class(SNA_OT_Add_New_Action_9E4B3)
    bpy.utils.register_class(SNA_PT_COMPENDIUM_00470)
    bpy.utils.register_class(SNA_OT_Toggle_Tools_F006F)
    bpy.utils.register_class(SNA_OT_Toggle_Settings_04Ec7)
    bpy.utils.register_class(SNA_OT_Toggle_Item_Info_B0C71)
    bpy.utils.register_class(SNA_OT_Toggle_Workflow_Panel_C058B)
    bpy.utils.register_class(SNA_MT_A3D1B)
    bpy.utils.register_class(SNA_OT_Forgotten_Tools_Link_F1Fdb)
    bpy.utils.register_class(SNA_OT_Edge_Flow_Link_Fd608)
    bpy.utils.register_class(SNA_AddonPreferences_63B78)
    bpy.utils.register_class(SNA_OT_Togglem3_8535A)
    bpy.utils.register_class(SNA_OT_Toggle_Off_Shift_Es_F193C)
    bpy.app.handlers.load_post.append(load_post_handler_F84BC)
    bpy.utils.register_class(SNA_OT_Toggle_On_Shift_Es_8Ad96)
    bpy.utils.register_class(SNA_OT_Set_Orientation_Global_52453)
    bpy.utils.register_class(SNA_OT_Set_Orientation_Local_059E9)
    bpy.utils.register_class(SNA_OT_Set_Orientation_Normal_B13Bc)
    bpy.utils.register_class(SNA_OT_Transform_Pivot_Median_Dfa9E)
    bpy.utils.register_class(SNA_OT_Transform_Pivot_Cursor_4Cdc9)
    bpy.utils.register_class(SNA_OT_Transform_Pivot_Individual_Ea6E3)
    bpy.utils.register_class(SNA_OT_Zero_X_Fa140)
    bpy.utils.register_class(SNA_OT_Zero_Y_4Bafe)
    bpy.utils.register_class(SNA_OT_Zero_Z_B09F4)
    bpy.utils.register_class(SNA_OT_Zero_X_Rot_4E822)
    bpy.utils.register_class(SNA_OT_Zero_Y_Rot_D3731)
    bpy.utils.register_class(SNA_OT_Zero_Z_Rot_E6449)
    bpy.utils.register_class(SNA_OT_Reset_X_Scale_2286B)
    bpy.utils.register_class(SNA_OT_Reset_Y_Scale_21706)
    bpy.utils.register_class(SNA_OT_Reset_Z_Scale_C3816)
    bpy.utils.register_class(SNA_OT_Show_Ops_F6C25)
    bpy.utils.register_class(SNA_OT_Mirror_Empty_F8D10)
    bpy.utils.register_class(SNA_OT_Send_Selectedto_Backup_5Ac5A)
    bpy.utils.register_class(SNA_OT_Snap_To_Face_Preset_5Ffa6)
    bpy.utils.register_class(SNA_OT_Toggle_Show_Creases_48169)
    bpy.utils.register_class(SNA_OT_Toggle_Show_Sharps_28E50)
    bpy.utils.register_class(SNA_OT_Toggle_Show_Bevels_Cb2F7)
    bpy.utils.register_class(SNA_OT_Toggle_Show_Seams_7408D)
    bpy.utils.register_class(SNA_OT_Set_Shading_Matcap_E9F4F)
    bpy.utils.register_class(SNA_OT_Set_Shading_Flat_87Cbc)
    bpy.utils.register_class(SNA_OT_Set_Shading_Preview_9Ad3C)
    bpy.utils.register_class(SNA_OT_Special_Hide_Selected_1C458)
    bpy.utils.register_class(SNA_OT_Special_Show_All_7E124)
    bpy.utils.register_class(SNA_OT_Special_Hide_Unselected_29928)
    bpy.utils.register_class(SNA_OT_Toggle_Wireframe_C8C58)
    bpy.utils.register_class(SNA_OT_Duplicate_Send_To_Backup_8Be30)
    bpy.utils.register_class(SNA_OT_Toggle_Display_In_Front_67De2)
    bpy.utils.register_class(SNA_OT_Toggle_Show_Stretch_8Ca4E)
    bpy.utils.register_class(SNA_OT_Set_Vertex_Paint_Workflow_B1688)
    bpy.utils.register_class(SNA_OT_Set_Weight_Paint_Workflow_C2Eda)
    bpy.utils.register_class(SNA_OT_Set_Sculpt_Workflow_27F56)
    bpy.utils.register_class(SNA_OT_Ue_Projects_Settings_D25Db)
    bpy.utils.register_class(SNA_OT_Add_Camera_Loaction_1E5F9)
    bpy.utils.register_class(SNA_OT_Setcameratolocation_78754)
    bpy.utils.register_class(SNA_OT_Remove_Camera_Location_37A38)
    bpy.utils.register_class(SNA_OT_Set_Square_Preset_18Bb4)
    bpy.utils.register_class(SNA_OT_Set_Screen_Reset_45D5E)
    bpy.utils.register_class(SNA_OT_Toggle_Workflow_Options_05D4C)
    bpy.utils.register_class(SNA_OT_Reset_Project_Settings_4A619)
    bpy.utils.register_class(SNA_OT_Setviewportgridue_B1102)
    bpy.utils.register_class(SNA_OT_Add_Single_Vert_Bfe7D)
    bpy.utils.register_class(SNA_OT_Add_Edge_2Ddef)
    bpy.utils.register_class(SNA_OT_Set_Orientation_Parent_9Fa00)
    bpy.utils.register_class(SNA_OT_Add_Bezier_Pipe_E6F6D)
    bpy.utils.register_class(SNA_OT_Set_Rotation_Axis_D9Af5)
    bpy.utils.register_class(SNA_OT_Set_Is_Positive_Axis_Fd57D)
    bpy.utils.register_class(SNA_OT_Quick_Rotate_Active_Object_Db0Ac)
    bpy.utils.register_class(SNA_OT_Add_Bezier_Rectangle_F8009)
    bpy.utils.register_class(SNA_OT_Add_Empty_Curve_43Edf)
    bpy.utils.register_class(SNA_OT_Add_Square_Curve_6290E)
    bpy.utils.register_class(SNA_PT_EDIT_TOOLS_5C0B2)
    bpy.utils.register_class(SNA_PT_ITEM_INFO_7E877)
    bpy.utils.register_class(SNA_PT_OBJECT_TOOLS_95067)
    bpy.utils.register_class(SNA_OT_Explode_Selected_05499)
    bpy.utils.register_class(SNA_OT_Reset_All_World_Origin_943B2)
    bpy.utils.register_class(SNA_PT_SETTINGS_PANEL_F2E9C)
    bpy.utils.register_class(SNA_PT_VERTEX_PAINT_TOOLS_CAE53)
    bpy.utils.register_class(SNA_PT_WEIGHT_PAINT_TOOLS_6B5ED)
    bpy.utils.register_class(SNA_OT_Custom_Set_Weight_2F5D4)
    bpy.utils.register_class(SNA_PT_WORKFLOW_304C1)
    bpy.utils.register_class(SNA_OT_Toggleautoselectarmature_C5316)
    bpy.utils.register_class(SNA_MT_F2EBE)
    bpy.utils.register_class(SNA_OT_Face_Mode_44E6B)
    bpy.utils.register_class(SNA_OT_Vert_Mode_34Ed6)
    bpy.utils.register_class(SNA_OT_Edge_Mode_74D78)
    bpy.utils.register_class(SNA_OT_Set_Weight_Paint_3B8D6)
    bpy.utils.register_class(SNA_OT_Set_Vertex_Paint_Mode_Box_Select_3230D)
    bpy.utils.register_class(SNA_OT_Set_Vertex_Paint_Mode_8Ba67)
    bpy.utils.register_class(SNA_OT_Setpolypenselect_6A432)
    bpy.utils.register_class(SNA_MT_2C530)
    bpy.utils.register_class(SNA_MT_5FC8E)
    bpy.types.VIEW3D_HT_tool_header.prepend(sna_add_to_view3d_ht_tool_header_15313)
    bpy.utils.register_class(SNA_OT_Set_Smooth_Strength_F31E6)
    bpy.utils.register_class(SNA_MT_30393)
    bpy.utils.register_class(SNA_MT_B55D7)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'E', 'PRESS',
        ctrl=False, alt=False, shift=True, repeat=False)
    kmi.properties.name = 'SNA_MT_A3D1B'
    addon_keymaps['74368'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new('sna.togglem3_8535a', 'BACK_SLASH', 'PRESS',
        ctrl=False, alt=False, shift=False, repeat=False)
    addon_keymaps['ADF2F'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'TAB', 'PRESS',
        ctrl=False, alt=False, shift=False, repeat=False)
    kmi.properties.name = 'SNA_MT_F2EBE'
    addon_keymaps['9C020'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'E', 'PRESS',
        ctrl=False, alt=False, shift=True, repeat=False)
    kmi.properties.name = 'SNA_MT_2C530'
    addon_keymaps['D7294'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'E', 'PRESS',
        ctrl=False, alt=False, shift=True, repeat=False)
    kmi.properties.name = 'SNA_MT_5FC8E'
    addon_keymaps['3EA7D'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'E', 'PRESS',
        ctrl=False, alt=False, shift=True, repeat=False)
    kmi.properties.name = 'SNA_MT_30393'
    addon_keymaps['30196'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'E', 'PRESS',
        ctrl=False, alt=False, shift=True, repeat=False)
    kmi.properties.name = 'SNA_MT_B55D7'
    addon_keymaps['555F5'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_selectweightpaintmode
    del bpy.types.Scene.sna_ispositive
    del bpy.types.Scene.sna_z_axis
    del bpy.types.Scene.sna_y_axis
    del bpy.types.Scene.sna_x_axis
    del bpy.types.Scene.sna_items
    del bpy.types.Scene.sna_margin
    del bpy.types.Scene.sna_showwfoptions
    del bpy.types.Scene.sna_locationname
    del bpy.types.Scene.sna_camlocs
    del bpy.types.Scene.sna_wpworkflow
    del bpy.types.Scene.sna_vpworkflow
    del bpy.types.Scene.sna_sculptworkflow
    del bpy.types.Object.sna_lastcollection
    del bpy.types.Scene.sna_usecompendiumempty
    del bpy.types.Scene.sna_showops
    del bpy.types.Scene.sna_showworkflow
    del bpy.types.Scene.sna_showiteminfo
    del bpy.types.Scene.sna_showrendersettings
    del bpy.types.Scene.sna_showtools
    del bpy.types.Scene.sna_newcollectionname
    bpy.utils.unregister_class(SNA_GROUP_sna_transforminfo)
    bpy.types.DOPESHEET_MT_editor_menus.remove(sna_add_to_dopesheet_mt_editor_menus_3436A)
    bpy.utils.unregister_class(SNA_OT_Add_New_Action_9E4B3)
    bpy.utils.unregister_class(SNA_PT_COMPENDIUM_00470)
    bpy.utils.unregister_class(SNA_OT_Toggle_Tools_F006F)
    bpy.utils.unregister_class(SNA_OT_Toggle_Settings_04Ec7)
    bpy.utils.unregister_class(SNA_OT_Toggle_Item_Info_B0C71)
    bpy.utils.unregister_class(SNA_OT_Toggle_Workflow_Panel_C058B)
    bpy.utils.unregister_class(SNA_MT_A3D1B)
    bpy.utils.unregister_class(SNA_OT_Forgotten_Tools_Link_F1Fdb)
    bpy.utils.unregister_class(SNA_OT_Edge_Flow_Link_Fd608)
    bpy.utils.unregister_class(SNA_AddonPreferences_63B78)
    bpy.utils.unregister_class(SNA_OT_Togglem3_8535A)
    bpy.utils.unregister_class(SNA_OT_Toggle_Off_Shift_Es_F193C)
    bpy.app.handlers.load_post.remove(load_post_handler_F84BC)
    bpy.utils.unregister_class(SNA_OT_Toggle_On_Shift_Es_8Ad96)
    bpy.utils.unregister_class(SNA_OT_Set_Orientation_Global_52453)
    bpy.utils.unregister_class(SNA_OT_Set_Orientation_Local_059E9)
    bpy.utils.unregister_class(SNA_OT_Set_Orientation_Normal_B13Bc)
    bpy.utils.unregister_class(SNA_OT_Transform_Pivot_Median_Dfa9E)
    bpy.utils.unregister_class(SNA_OT_Transform_Pivot_Cursor_4Cdc9)
    bpy.utils.unregister_class(SNA_OT_Transform_Pivot_Individual_Ea6E3)
    bpy.utils.unregister_class(SNA_OT_Zero_X_Fa140)
    bpy.utils.unregister_class(SNA_OT_Zero_Y_4Bafe)
    bpy.utils.unregister_class(SNA_OT_Zero_Z_B09F4)
    bpy.utils.unregister_class(SNA_OT_Zero_X_Rot_4E822)
    bpy.utils.unregister_class(SNA_OT_Zero_Y_Rot_D3731)
    bpy.utils.unregister_class(SNA_OT_Zero_Z_Rot_E6449)
    bpy.utils.unregister_class(SNA_OT_Reset_X_Scale_2286B)
    bpy.utils.unregister_class(SNA_OT_Reset_Y_Scale_21706)
    bpy.utils.unregister_class(SNA_OT_Reset_Z_Scale_C3816)
    bpy.utils.unregister_class(SNA_OT_Show_Ops_F6C25)
    bpy.utils.unregister_class(SNA_OT_Mirror_Empty_F8D10)
    bpy.utils.unregister_class(SNA_OT_Send_Selectedto_Backup_5Ac5A)
    bpy.utils.unregister_class(SNA_OT_Snap_To_Face_Preset_5Ffa6)
    bpy.utils.unregister_class(SNA_OT_Toggle_Show_Creases_48169)
    bpy.utils.unregister_class(SNA_OT_Toggle_Show_Sharps_28E50)
    bpy.utils.unregister_class(SNA_OT_Toggle_Show_Bevels_Cb2F7)
    bpy.utils.unregister_class(SNA_OT_Toggle_Show_Seams_7408D)
    bpy.utils.unregister_class(SNA_OT_Set_Shading_Matcap_E9F4F)
    bpy.utils.unregister_class(SNA_OT_Set_Shading_Flat_87Cbc)
    bpy.utils.unregister_class(SNA_OT_Set_Shading_Preview_9Ad3C)
    bpy.utils.unregister_class(SNA_OT_Special_Hide_Selected_1C458)
    bpy.utils.unregister_class(SNA_OT_Special_Show_All_7E124)
    bpy.utils.unregister_class(SNA_OT_Special_Hide_Unselected_29928)
    bpy.utils.unregister_class(SNA_OT_Toggle_Wireframe_C8C58)
    bpy.utils.unregister_class(SNA_OT_Duplicate_Send_To_Backup_8Be30)
    bpy.utils.unregister_class(SNA_OT_Toggle_Display_In_Front_67De2)
    bpy.utils.unregister_class(SNA_OT_Toggle_Show_Stretch_8Ca4E)
    bpy.utils.unregister_class(SNA_OT_Set_Vertex_Paint_Workflow_B1688)
    bpy.utils.unregister_class(SNA_OT_Set_Weight_Paint_Workflow_C2Eda)
    bpy.utils.unregister_class(SNA_OT_Set_Sculpt_Workflow_27F56)
    bpy.utils.unregister_class(SNA_OT_Ue_Projects_Settings_D25Db)
    bpy.utils.unregister_class(SNA_OT_Add_Camera_Loaction_1E5F9)
    bpy.utils.unregister_class(SNA_OT_Setcameratolocation_78754)
    bpy.utils.unregister_class(SNA_OT_Remove_Camera_Location_37A38)
    bpy.utils.unregister_class(SNA_OT_Set_Square_Preset_18Bb4)
    bpy.utils.unregister_class(SNA_OT_Set_Screen_Reset_45D5E)
    bpy.utils.unregister_class(SNA_OT_Toggle_Workflow_Options_05D4C)
    bpy.utils.unregister_class(SNA_OT_Reset_Project_Settings_4A619)
    bpy.utils.unregister_class(SNA_OT_Setviewportgridue_B1102)
    bpy.utils.unregister_class(SNA_OT_Add_Single_Vert_Bfe7D)
    bpy.utils.unregister_class(SNA_OT_Add_Edge_2Ddef)
    bpy.utils.unregister_class(SNA_OT_Set_Orientation_Parent_9Fa00)
    bpy.utils.unregister_class(SNA_OT_Add_Bezier_Pipe_E6F6D)
    bpy.utils.unregister_class(SNA_OT_Set_Rotation_Axis_D9Af5)
    bpy.utils.unregister_class(SNA_OT_Set_Is_Positive_Axis_Fd57D)
    bpy.utils.unregister_class(SNA_OT_Quick_Rotate_Active_Object_Db0Ac)
    bpy.utils.unregister_class(SNA_OT_Add_Bezier_Rectangle_F8009)
    bpy.utils.unregister_class(SNA_OT_Add_Empty_Curve_43Edf)
    bpy.utils.unregister_class(SNA_OT_Add_Square_Curve_6290E)
    bpy.utils.unregister_class(SNA_PT_EDIT_TOOLS_5C0B2)
    bpy.utils.unregister_class(SNA_PT_ITEM_INFO_7E877)
    bpy.utils.unregister_class(SNA_PT_OBJECT_TOOLS_95067)
    bpy.utils.unregister_class(SNA_OT_Explode_Selected_05499)
    bpy.utils.unregister_class(SNA_OT_Reset_All_World_Origin_943B2)
    bpy.utils.unregister_class(SNA_PT_SETTINGS_PANEL_F2E9C)
    bpy.utils.unregister_class(SNA_PT_VERTEX_PAINT_TOOLS_CAE53)
    bpy.utils.unregister_class(SNA_PT_WEIGHT_PAINT_TOOLS_6B5ED)
    bpy.utils.unregister_class(SNA_OT_Custom_Set_Weight_2F5D4)
    bpy.utils.unregister_class(SNA_PT_WORKFLOW_304C1)
    bpy.utils.unregister_class(SNA_OT_Toggleautoselectarmature_C5316)
    bpy.utils.unregister_class(SNA_MT_F2EBE)
    bpy.utils.unregister_class(SNA_OT_Face_Mode_44E6B)
    bpy.utils.unregister_class(SNA_OT_Vert_Mode_34Ed6)
    bpy.utils.unregister_class(SNA_OT_Edge_Mode_74D78)
    bpy.utils.unregister_class(SNA_OT_Set_Weight_Paint_3B8D6)
    bpy.utils.unregister_class(SNA_OT_Set_Vertex_Paint_Mode_Box_Select_3230D)
    bpy.utils.unregister_class(SNA_OT_Set_Vertex_Paint_Mode_8Ba67)
    bpy.utils.unregister_class(SNA_OT_Setpolypenselect_6A432)
    bpy.utils.unregister_class(SNA_MT_2C530)
    bpy.utils.unregister_class(SNA_MT_5FC8E)
    bpy.types.VIEW3D_HT_tool_header.remove(sna_add_to_view3d_ht_tool_header_15313)
    bpy.utils.unregister_class(SNA_OT_Set_Smooth_Strength_F31E6)
    bpy.utils.unregister_class(SNA_MT_30393)
    bpy.utils.unregister_class(SNA_MT_B55D7)
