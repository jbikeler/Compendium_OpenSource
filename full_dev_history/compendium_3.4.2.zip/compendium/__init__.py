# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Compendium",
    "author" : "Ben Ikeler", 
    "description" : "",
    "blender" : (4, 2, 0),
    "version" : (3, 4, 2),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
from bpy.app.handlers import persistent


addon_keymaps = {}
_icons = None
general_fns = {'sna_objectlist': [], 'sna_unselected': [], }
mirrorempty = {'sna_objectname': '', 'sna_newempty': '', 'sna_foundobject': False, 'sna_modname': '', }


def find_user_keyconfig(key):
    km, kmi = addon_keymaps[key]
    for item in bpy.context.window_manager.keyconfigs.user.keymaps[km.name].keymap_items:
        found_item = False
        if kmi.idname == item.idname:
            found_item = True
            for name in dir(kmi.properties):
                if not name in ["bl_rna", "rna_type"] and not name[0] == "_":
                    if name in kmi.properties and name in item.properties and not kmi.properties[name] == item.properties[name]:
                        found_item = False
        if found_item:
            return item
    print(f"Couldn't find keymap item for {key}, using addon keymap instead. This won't be saved across sessions!")
    return kmi


movetocollection_s3_vars_DA7BC = {'sna_objectstomove': [], }


def sna_moveobjectstocollection_397D9_DA7BC(CollectionName, ListOfOjbects):
    if (len(ListOfOjbects) > 0):
        if property_exists("bpy.data.collections[CollectionName]", globals(), locals()):
            sna_fnlinkunlink_41AEA(CollectionName, ListOfOjbects)
            return bpy.data.collections[CollectionName]
        else:
            collection_752A1 = bpy.data.collections.new(name=CollectionName, )
            bpy.context.scene.collection.children.link(child=collection_752A1, )
            sna_fnlinkunlink_41AEA(CollectionName, ListOfOjbects)
            return collection_752A1


localhidecollection_vars_04E8B = {'sna_iscollectionfound': False, 'sna_foundcollection': None, }


def sna_hidecollectioninviewport_32E38_04E8B(CollectionName, Options):
    localhidecollection_vars_04E8B['sna_iscollectionfound'] = False
    localhidecollection_vars_04E8B['sna_foundcollection'] = None
    for i_99DD9 in range(len(bpy.data.collections)):
        if (bpy.data.collections[i_99DD9].name == CollectionName):
            localhidecollection_vars_04E8B['sna_iscollectionfound'] = True
            localhidecollection_vars_04E8B['sna_foundcollection'] = bpy.data.collections[i_99DD9]
            break
    if localhidecollection_vars_04E8B['sna_iscollectionfound']:
        if Options == "Local":
            sna_hidelocal_4CC08(CollectionName)
        elif Options == "Global":
            sna_hideglobal_430FD(localhidecollection_vars_04E8B['sna_foundcollection'])
        elif Options == "Both":
            sna_hidelocal_4CC08(CollectionName)
            sna_hideglobal_430FD(localhidecollection_vars_04E8B['sna_foundcollection'])
        else:
            pass


movetocollection_s3_vars_63B66 = {'sna_objectstomove': [], }


def sna_moveobjectstocollection_397D9_63B66(CollectionName, ListOfOjbects):
    if (len(ListOfOjbects) > 0):
        if property_exists("bpy.data.collections[CollectionName]", globals(), locals()):
            sna_fnlinkunlink_41AEA(CollectionName, ListOfOjbects)
            return bpy.data.collections[CollectionName]
        else:
            collection_752A1 = bpy.data.collections.new(name=CollectionName, )
            bpy.context.scene.collection.children.link(child=collection_752A1, )
            sna_fnlinkunlink_41AEA(CollectionName, ListOfOjbects)
            return collection_752A1


localhidecollection_vars_F9EA4 = {'sna_iscollectionfound': False, 'sna_foundcollection': None, }


def sna_hidecollectioninviewport_32E38_F9EA4(CollectionName, Options):
    localhidecollection_vars_F9EA4['sna_iscollectionfound'] = False
    localhidecollection_vars_F9EA4['sna_foundcollection'] = None
    for i_99DD9 in range(len(bpy.data.collections)):
        if (bpy.data.collections[i_99DD9].name == CollectionName):
            localhidecollection_vars_F9EA4['sna_iscollectionfound'] = True
            localhidecollection_vars_F9EA4['sna_foundcollection'] = bpy.data.collections[i_99DD9]
            break
    if localhidecollection_vars_F9EA4['sna_iscollectionfound']:
        if Options == "Local":
            sna_hidelocal_4CC08(CollectionName)
        elif Options == "Global":
            sna_hideglobal_430FD(localhidecollection_vars_F9EA4['sna_foundcollection'])
        elif Options == "Both":
            sna_hidelocal_4CC08(CollectionName)
            sna_hideglobal_430FD(localhidecollection_vars_F9EA4['sna_foundcollection'])
        else:
            pass


def sna_hidelocal_4CC08(CollectionName):
    exec("bpy.context.view_layer.layer_collection.children.get('Your_Collection_Name').hide_viewport = True".replace('Your_Collection_Name', CollectionName))


def sna_hideglobal_430FD(Collection):
    Collection.hide_viewport = True


movetocollection_s3_vars_58084 = {'sna_objectstomove': [], }


def sna_moveobjectstocollection_397D9_58084(CollectionName, ListOfOjbects):
    if (len(ListOfOjbects) > 0):
        if property_exists("bpy.data.collections[CollectionName]", globals(), locals()):
            sna_fnlinkunlink_41AEA(CollectionName, ListOfOjbects)
            return bpy.data.collections[CollectionName]
        else:
            collection_752A1 = bpy.data.collections.new(name=CollectionName, )
            bpy.context.scene.collection.children.link(child=collection_752A1, )
            sna_fnlinkunlink_41AEA(CollectionName, ListOfOjbects)
            return collection_752A1


def sna_fnlinkunlink_41AEA(CollectionName, ListOfObjects):
    movetocollection_s3_vars_58084['sna_objectstomove'] = []
    for i_5B107 in range(len(ListOfObjects)):
        movetocollection_s3_vars_58084['sna_objectstomove'].append(ListOfObjects[i_5B107])
    for i_18D5A in range(len(ListOfObjects)):
        for i_BE9A3 in range(len(ListOfObjects[i_18D5A].users_collection)):
            if (ListOfObjects[i_18D5A].users_collection[i_BE9A3].name == CollectionName):
                movetocollection_s3_vars_58084['sna_objectstomove'].remove(ListOfObjects[i_18D5A])
    for i_EC7E0 in range(len(movetocollection_s3_vars_58084['sna_objectstomove'])):
        for i_726C8 in range(len(movetocollection_s3_vars_58084['sna_objectstomove'][i_EC7E0].users_collection)):
            movetocollection_s3_vars_58084['sna_objectstomove'][i_EC7E0].users_collection[i_726C8].objects.unlink(object=movetocollection_s3_vars_58084['sna_objectstomove'][i_EC7E0], )
    for i_9A186 in range(len(movetocollection_s3_vars_58084['sna_objectstomove'])):
        bpy.data.collections[CollectionName].objects.link(object=movetocollection_s3_vars_58084['sna_objectstomove'][i_9A186], )


def sna_getobjectproperty_427FF_5BA5F(ObjectName):
    return bpy.data.objects[ObjectName]


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


class SNA_PT_COMPENDIUM_7BFB0(bpy.types.Panel):
    bl_label = 'Compendium'
    bl_idname = 'SNA_PT_COMPENDIUM_7BFB0'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_83AF6 = layout.column(heading='', align=False)
        col_83AF6.alert = False
        col_83AF6.enabled = True
        col_83AF6.active = True
        col_83AF6.use_property_split = False
        col_83AF6.use_property_decorate = False
        col_83AF6.scale_x = 1.0
        col_83AF6.scale_y = 1.0
        col_83AF6.alignment = 'Expand'.upper()
        col_83AF6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        split_70E87 = col_83AF6.split(factor=0.5, align=True)
        split_70E87.alert = False
        split_70E87.enabled = True
        split_70E87.active = True
        split_70E87.use_property_split = False
        split_70E87.use_property_decorate = False
        split_70E87.scale_x = 1.0
        split_70E87.scale_y = 1.0
        split_70E87.alignment = 'Expand'.upper()
        if not True: split_70E87.operator_context = "EXEC_DEFAULT"
        op = split_70E87.operator('sna.toggle_tools_f006f', text='', icon_value=(130 if 'OBJECT'==bpy.context.mode else 131), emboss=True, depress=bpy.context.scene.sna_showtools)
        op = split_70E87.operator('sna.toggle_item_info_b0c71', text='', icon_value=110, emboss=True, depress=bpy.context.scene.sna_showiteminfo)
        split_D2038 = col_83AF6.split(factor=1.0, align=False)
        split_D2038.alert = False
        split_D2038.enabled = True
        split_D2038.active = True
        split_D2038.use_property_split = False
        split_D2038.use_property_decorate = False
        split_D2038.scale_x = 1.0
        split_D2038.scale_y = 1.0
        split_D2038.alignment = 'Expand'.upper()
        if not True: split_D2038.operator_context = "EXEC_DEFAULT"
        op = split_D2038.operator('sna.toggle_render_settings_04ec7', text='', icon_value=117, emboss=True, depress=bpy.context.scene.sna_showrendersettings)


class SNA_OT_Toggle_Tools_F006F(bpy.types.Operator):
    bl_idname = "sna.toggle_tools_f006f"
    bl_label = "Toggle Tools"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showtools = (not bpy.context.scene.sna_showtools)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Render_Settings_04Ec7(bpy.types.Operator):
    bl_idname = "sna.toggle_render_settings_04ec7"
    bl_label = "Toggle Render Settings"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showrendersettings = (not bpy.context.scene.sna_showrendersettings)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Num_Pad_A5753(bpy.types.Operator):
    bl_idname = "sna.toggle_num_pad_a5753"
    bl_label = "Toggle Num Pad"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_shownumpad = (not bpy.context.scene.sna_shownumpad)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Item_Info_B0C71(bpy.types.Operator):
    bl_idname = "sna.toggle_item_info_b0c71"
    bl_label = "Toggle Item Info"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showiteminfo = (not bpy.context.scene.sna_showiteminfo)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_MT_A3D1B(bpy.types.Menu):
    bl_idname = "SNA_MT_A3D1B"
    bl_label = "Compendium"

    @classmethod
    def poll(cls, context):
        return not ((not ('OBJECT'==bpy.context.mode or 'EDIT_MESH'==bpy.context.mode)))

    def draw(self, context):
        layout = self.layout.menu_pie()
        op = layout.operator('sna.set_orientation_global_52453', text='Global', icon_value=0, emboss=True, depress=False)
        if 'OBJECT'==bpy.context.mode:
            row_D0581 = layout.row(heading='', align=False)
            row_D0581.alert = False
            row_D0581.enabled = True
            row_D0581.active = True
            row_D0581.use_property_split = False
            row_D0581.use_property_decorate = False
            row_D0581.scale_x = 1.0
            row_D0581.scale_y = 1.0
            row_D0581.alignment = 'Expand'.upper()
            row_D0581.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            box_A45EB = row_D0581.box()
            box_A45EB.alert = False
            box_A45EB.enabled = True
            box_A45EB.active = True
            box_A45EB.use_property_split = False
            box_A45EB.use_property_decorate = False
            box_A45EB.alignment = 'Expand'.upper()
            box_A45EB.scale_x = 1.0
            box_A45EB.scale_y = 1.0
            if not True: box_A45EB.operator_context = "EXEC_DEFAULT"
            col_E2851 = box_A45EB.column(heading='', align=True)
            col_E2851.alert = False
            col_E2851.enabled = True
            col_E2851.active = True
            col_E2851.use_property_split = False
            col_E2851.use_property_decorate = False
            col_E2851.scale_x = 1.0
            col_E2851.scale_y = 1.0
            col_E2851.alignment = 'Expand'.upper()
            col_E2851.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_E2851.operator('sna.show_ops_f6c25', text='', icon_value=(6 if bpy.context.scene.sna_showops else 4), emboss=bpy.context.scene.sna_showops, depress=bpy.context.scene.sna_showops)
            op = col_E2851.operator('object.move_to_collection', text='', icon_value=250, emboss=False, depress=False)
            if bpy.context.scene.sna_showops:
                box_BE977 = row_D0581.box()
                box_BE977.alert = False
                box_BE977.enabled = True
                box_BE977.active = True
                box_BE977.use_property_split = False
                box_BE977.use_property_decorate = False
                box_BE977.alignment = 'Expand'.upper()
                box_BE977.scale_x = 1.0
                box_BE977.scale_y = 1.0
                if not True: box_BE977.operator_context = "EXEC_DEFAULT"
                col_63BC5 = box_BE977.column(heading='', align=True)
                col_63BC5.alert = False
                col_63BC5.enabled = True
                col_63BC5.active = True
                col_63BC5.use_property_split = False
                col_63BC5.use_property_decorate = False
                col_63BC5.scale_x = 1.0
                col_63BC5.scale_y = 1.0
                col_63BC5.alignment = 'Expand'.upper()
                col_63BC5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_15F16 = col_63BC5.row(heading='', align=True)
                row_15F16.alert = False
                row_15F16.enabled = True
                row_15F16.active = True
                row_15F16.use_property_split = False
                row_15F16.use_property_decorate = False
                row_15F16.scale_x = 1.2000000476837158
                row_15F16.scale_y = 1.2000000476837158
                row_15F16.alignment = 'Expand'.upper()
                row_15F16.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                op = row_15F16.operator('sna.mirror_empty_f8d10', text='', icon_value=318, emboss=True, depress=False)
                op = row_15F16.operator('object.modifier_add', text='', icon_value=446, emboss=True, depress=False)
                op.type = 'MIRROR'
                op = row_15F16.operator('sna.send_selectedto_backup_5ac5a', text='', icon_value=690, emboss=True, depress=False)
                row_ADCEE = col_63BC5.row(heading='', align=True)
                row_ADCEE.alert = False
                row_ADCEE.enabled = True
                row_ADCEE.active = True
                row_ADCEE.use_property_split = False
                row_ADCEE.use_property_decorate = False
                row_ADCEE.scale_x = 1.2000000476837158
                row_ADCEE.scale_y = 1.2000000476837158
                row_ADCEE.alignment = 'Expand'.upper()
                row_ADCEE.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                op = row_ADCEE.operator('sna.duplicate_send_to_backup_8be30', text='', icon_value=20, emboss=True, depress=False)
        else:
            op = layout.operator('mesh.vert_connect_path', text='Join', icon_value=0, emboss=True, depress=False)
        op = layout.operator('sn.dummy_button_operator', text='Local', icon_value=0, emboss=True, depress=False)
        if 'OBJECT'==bpy.context.mode:
            layout.prop(bpy.data.scenes['Scene'].tool_settings, 'use_snap', text='', icon_value=0, emboss=True)
        else:
            row_3550D = layout.row(heading='', align=True)
            row_3550D.alert = False
            row_3550D.enabled = True
            row_3550D.active = True
            row_3550D.use_property_split = False
            row_3550D.use_property_decorate = False
            row_3550D.scale_x = 1.2000000476837158
            row_3550D.scale_y = 1.5
            row_3550D.alignment = 'Expand'.upper()
            row_3550D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_3550D.prop(bpy.data.scenes['Scene'].tool_settings, 'use_mesh_automerge', text='', icon_value=0, emboss=True)
            row_3550D.prop(bpy.data.scenes['Scene'].tool_settings, 'use_proportional_edit', text='', icon_value=0, emboss=True)
            row_3550D.prop(bpy.data.scenes['Scene'].tool_settings, 'use_snap', text='', icon_value=0, emboss=True)
        row_33CC2 = layout.row(heading='', align=True)
        row_33CC2.alert = False
        row_33CC2.enabled = True
        row_33CC2.active = True
        row_33CC2.use_property_split = False
        row_33CC2.use_property_decorate = False
        row_33CC2.scale_x = 1.2000000476837158
        row_33CC2.scale_y = 1.5
        row_33CC2.alignment = 'Expand'.upper()
        row_33CC2.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_33CC2.operator('sna.transform_pivot_individual_ea6e3', text='', icon_value=553, emboss=True, depress=False)
        op = row_33CC2.operator('sna.transform_pivot_cursor_4cdc9', text='', icon_value=552, emboss=True, depress=False)
        op = row_33CC2.operator('sna.transform_pivot_median_dfa9e', text='', icon_value=554, emboss=True, depress=False)
        if 'OBJECT'==bpy.context.mode:
            layout.separator(factor=1.0)
        else:
            op = layout.operator('mesh.knife_tool', text='Knife', icon_value=0, emboss=True, depress=False)
            op.use_occlude_geometry = True
            op.xray = True
        if 'OBJECT'==bpy.context.mode:
            col_679D0 = layout.column(heading='', align=False)
            col_679D0.alert = False
            col_679D0.enabled = True
            col_679D0.active = True
            col_679D0.use_property_split = False
            col_679D0.use_property_decorate = False
            col_679D0.scale_x = 1.0
            col_679D0.scale_y = 1.0
            col_679D0.alignment = 'Expand'.upper()
            col_679D0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_679D0.label(text='Special Show/Hide', icon_value=0)
            split_3FF7B = col_679D0.split(factor=0.5, align=True)
            split_3FF7B.alert = False
            split_3FF7B.enabled = True
            split_3FF7B.active = True
            split_3FF7B.use_property_split = False
            split_3FF7B.use_property_decorate = False
            split_3FF7B.scale_x = 1.0
            split_3FF7B.scale_y = 1.2000000476837158
            split_3FF7B.alignment = 'Expand'.upper()
            if not True: split_3FF7B.operator_context = "EXEC_DEFAULT"
            op = split_3FF7B.operator('sna.special_hide_unselected_29928', text='Unselected', icon_value=253, emboss=True, depress=False)
            op = split_3FF7B.operator('sna.special_hide_selected_1c458', text='Selected', icon_value=253, emboss=True, depress=False)
            op = col_679D0.operator('sna.special_show_all_7e124', text='Show All', icon_value=254, emboss=True, depress=False)
        else:
            op = layout.operator('sna.set_orientation_normal_b13bc', text='Normal', icon_value=0, emboss=True, depress=False)
        op = layout.operator('view3d.view_selected', text='', icon_value=48, emboss=True, depress=False)


class SNA_OT_Forgotten_Tools_Link_F1Fdb(bpy.types.Operator):
    bl_idname = "sna.forgotten_tools_link_f1fdb"
    bl_label = "Forgotten Tools Link"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('bpy.ops.wm.url_open(url="https://stanpancakes.gumroad.com/l/JJNfR")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Edge_Flow_Link_Fd608(bpy.types.Operator):
    bl_idname = "sna.edge_flow_link_fd608"
    bl_label = "Edge Flow Link"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('bpy.ops.wm.url_open(url="https://github.com/BenjaminSauder/EdgeFlow/releases")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_AddonPreferences_63B78(bpy.types.AddonPreferences):
    bl_idname = 'compendium'

    def draw(self, context):
        if not (False):
            layout = self.layout 
            layout.label(text='Keyboard Shortcuts', icon_value=0)
            layout.prop(find_user_keyconfig('74368'), 'type', text='Compendium Pie Menu', full_event=True)
            layout.prop(find_user_keyconfig('9C020'), 'type', text='Modes Pie Menu', full_event=True)
            layout.prop(find_user_keyconfig('3EA7D'), 'type', text='Sculpt Pie Menu', full_event=True)
            layout.prop(find_user_keyconfig('ADF2F'), 'type', text='Emulate Mouse 3', full_event=True)
            row_4D9B3 = layout.row(heading='', align=False)
            row_4D9B3.alert = False
            row_4D9B3.enabled = True
            row_4D9B3.active = True
            row_4D9B3.use_property_split = False
            row_4D9B3.use_property_decorate = False
            row_4D9B3.scale_x = 1.0
            row_4D9B3.scale_y = 1.0
            row_4D9B3.alignment = 'Left'.upper()
            row_4D9B3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_4D9B3.label(text='Mesh > Use (Shift E) Edge Crease', icon_value=0)
            row_4D9B3.prop(bpy.context.window_manager.keyconfigs.active.keymaps['Mesh'].keymap_items['transform.edge_crease'], 'active', text='', icon_value=0, emboss=False)
            row_1C059 = layout.row(heading='', align=False)
            row_1C059.alert = False
            row_1C059.enabled = True
            row_1C059.active = True
            row_1C059.use_property_split = False
            row_1C059.use_property_decorate = False
            row_1C059.scale_x = 1.0
            row_1C059.scale_y = 1.0
            row_1C059.alignment = 'Left'.upper()
            row_1C059.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_1C059.label(text='Use Default Pie', icon_value=0)
            row_1C059.prop(bpy.context.window_manager.keyconfigs.active.keymaps['Object Non-modal'].keymap_items['wm.call_menu_pie'], 'active', text='', icon_value=0, emboss=False)
            box_B7100 = layout.box()
            box_B7100.alert = False
            box_B7100.enabled = True
            box_B7100.active = True
            box_B7100.use_property_split = False
            box_B7100.use_property_decorate = False
            box_B7100.alignment = 'Expand'.upper()
            box_B7100.scale_x = 1.0
            box_B7100.scale_y = 1.0
            if not True: box_B7100.operator_context = "EXEC_DEFAULT"
            box_B7100.label(text='Changelog Version ' + str(tuple((3, 4, 2))).replace('(', '').replace(')', '').replace(',', '.').replace(' ', '') + ':', icon_value=0)
            col_C0F38 = box_B7100.column(heading='', align=False)
            col_C0F38.alert = False
            col_C0F38.enabled = True
            col_C0F38.active = True
            col_C0F38.use_property_split = False
            col_C0F38.use_property_decorate = False
            col_C0F38.scale_x = 1.0
            col_C0F38.scale_y = 1.0
            col_C0F38.alignment = 'Expand'.upper()
            col_C0F38.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_C0F38.label(text='Added: Vertex workflow option to switch modes button options', icon_value=17)


class SNA_OT_Togglem3_8535A(bpy.types.Operator):
    bl_idname = "sna.togglem3_8535a"
    bl_label = "ToggleM3"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.preferences.inputs.use_mouse_emulate_3_button = (not bpy.context.preferences.inputs.use_mouse_emulate_3_button)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_view3d_mt_editor_menus_80153(self, context):
    if not ((not 'OBJECT'==bpy.context.mode)):
        layout = self.layout
        row_92A11 = layout.row(heading='', align=False)
        row_92A11.alert = False
        row_92A11.enabled = True
        row_92A11.active = True
        row_92A11.use_property_split = False
        row_92A11.use_property_decorate = False
        row_92A11.scale_x = 1.0
        row_92A11.scale_y = 1.0
        row_92A11.alignment = 'Expand'.upper()
        row_92A11.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_92A11.separator(factor=0.0)
        row_92A11.popover('SNA_PT_EXPORT_99553', text='Export', icon_value=707)
        row_92A11.separator(factor=0.0)


class SNA_PT_EXPORT_99553(bpy.types.Panel):
    bl_label = 'Export'
    bl_idname = 'SNA_PT_EXPORT_99553'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_4D589 = layout.column(heading='', align=False)
        col_4D589.alert = False
        col_4D589.enabled = 'OBJECT'==bpy.context.mode
        col_4D589.active = True
        col_4D589.use_property_split = False
        col_4D589.use_property_decorate = False
        col_4D589.scale_x = 1.0
        col_4D589.scale_y = 1.0
        col_4D589.alignment = 'Expand'.upper()
        col_4D589.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_4D589.label(text='Selected To FBX', icon_value=0)
        op = col_4D589.operator('export_scene.fbx', text='Static Mesh (UE)', icon_value=0, emboss=True, depress=False)
        op.use_selection = True
        op.apply_unit_scale = True
        op.use_space_transform = True
        op.object_types = {'MESH'}
        op.mesh_smooth_type = 'FACE'
        op.bake_anim = False
        op.axis_forward = '-Z'
        op.axis_up = 'Y'
        col_4D589.separator(factor=0.44999998807907104)
        col_A10F9 = col_4D589.column(heading='', align=True)
        col_A10F9.alert = False
        col_A10F9.enabled = 'OBJECT'==bpy.context.mode
        col_A10F9.active = True
        col_A10F9.use_property_split = False
        col_A10F9.use_property_decorate = False
        col_A10F9.scale_x = 1.0
        col_A10F9.scale_y = 1.0
        col_A10F9.alignment = 'Expand'.upper()
        col_A10F9.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_A10F9.operator('sna.export_fbx_skeletal_mesh_bc07e', text='Skeletal Mesh (UE)', icon_value=0, emboss=True, depress=False)
        op = col_A10F9.operator('sna.export_fbx_animation_5ee0a', text='Selected Animation (UE)', icon_value=0, emboss=True, depress=False)
        op = col_A10F9.operator('sna.export_fbx_all_animations_45844', text='All Animations (UE)', icon_value=0, emboss=True, depress=False)


class SNA_OT_Export_Fbx_Skeletal_Mesh_Bc07E(bpy.types.Operator):
    bl_idname = "sna.export_fbx_skeletal_mesh_bc07e"
    bl_label = "Export FBX Skeletal Mesh"
    bl_description = "Exports only mesh and armature. Select meshes then armature last as active. UE > Check Skeletal Mesh > Check Mesh > Uncheck Animations"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.export_scene.fbx('INVOKE_DEFAULT', use_selection=True, apply_unit_scale=True, use_space_transform=True, object_types={'ARMATURE', 'MESH'}, mesh_smooth_type='FACE', add_leaf_bones=False, bake_anim=False, axis_forward='-Z', axis_up='Y')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Export_Fbx_Animation_5Ee0A(bpy.types.Operator):
    bl_idname = "sna.export_fbx_animation_5ee0a"
    bl_label = "Export FBX Animation"
    bl_description = "Exports armature and selected animation. Select meshes then armature last as active. UE > Uncheck Mesh > Select Skeletion from previous > Check Animations"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.export_scene.fbx('INVOKE_DEFAULT', use_selection=True, apply_unit_scale=True, use_space_transform=True, object_types={'ARMATURE'}, mesh_smooth_type='FACE', add_leaf_bones=False, bake_anim=True, bake_anim_use_all_bones=True, bake_anim_use_nla_strips=False, bake_anim_use_all_actions=False, bake_anim_force_startend_keying=True, axis_forward='-Z', axis_up='Y')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Export_Fbx_All_Animations_45844(bpy.types.Operator):
    bl_idname = "sna.export_fbx_all_animations_45844"
    bl_label = "Export FBX All animations"
    bl_description = "Exports armature and all animations in file. Select meshes then armature last as active. UE > Uncheck Mesh > Select Skeletion from previous > Check Animations"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.export_scene.fbx('INVOKE_DEFAULT', use_selection=True, apply_unit_scale=True, use_space_transform=True, object_types={'ARMATURE'}, mesh_smooth_type='FACE', add_leaf_bones=False, bake_anim=True, bake_anim_use_all_bones=True, bake_anim_use_nla_strips=False, bake_anim_use_all_actions=True, bake_anim_force_startend_keying=True, axis_forward='-Z', axis_up='Y')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnsetsnaptoface_EAB45():
    bpy.context.scene.tool_settings.snap_elements = set(['FACE'])
    bpy.context.scene.tool_settings.use_snap_rotate = True
    bpy.context.scene.tool_settings.use_snap_translate = True
    bpy.context.scene.tool_settings.use_snap_align_rotation = True
    bpy.context.scene.tool_settings.snap_target = 'CENTER'


def sna_fnsendobjectstobackup_8AF45(Objects):
    if Objects:
        collection_0_da7bc = sna_moveobjectstocollection_397D9_DA7BC('Backup Objects', Objects)
        sna_hidecollectioninviewport_32E38_04E8B('Backup Objects', 'Both')
        collection_0_da7bc.hide_render = True


def sna_fnsetshadingmatcap_2CFE1():
    bpy.context.area.spaces.active.shading.type = 'SOLID'
    bpy.context.area.spaces.active.shading.light = 'MATCAP'
    bpy.context.area.spaces.active.shading.color_type = 'OBJECT'


def sna_fnsetshadingflat_3CF87():
    bpy.context.area.spaces.active.shading.type = 'SOLID'
    bpy.context.area.spaces.active.shading.light = 'FLAT'
    bpy.context.area.spaces.active.shading.color_type = 'VERTEX'


def sna_fnsetshadingpreview_A8938():
    bpy.context.area.spaces.active.shading.type = 'MATERIAL'


def sna_fnspecialhideobjects_9AA75(Objects):
    if Objects:
        for i_638E9 in range(len(Objects)):
            Objects[i_638E9].sna_lastcollection = Objects[i_638E9].users_collection[0].name
        collection_0_63b66 = sna_moveobjectstocollection_397D9_63B66('HiddenObjects', Objects)
        sna_hidecollectioninviewport_32E38_F9EA4('HiddenObjects', 'Local')


def sna_fnspecialshow_F6D84():
    general_fns['sna_objectlist'] = []
    if property_exists("bpy.data.collections['HiddenObjects']", globals(), locals()):
        for i_04CD0 in range(len(bpy.data.collections['HiddenObjects'].all_objects)):
            if (bpy.data.collections['HiddenObjects'].all_objects[i_04CD0].sna_lastcollection != 'original'):
                general_fns['sna_objectlist'].append(bpy.data.collections['HiddenObjects'].all_objects[i_04CD0])
        for i_7461B in range(len(general_fns['sna_objectlist'])):
            collection_0_58084 = sna_moveobjectstocollection_397D9_58084(general_fns['sna_objectlist'][i_7461B].sna_lastcollection, [general_fns['sna_objectlist'][i_7461B]])

            def delayed_93EF5():
                general_fns['sna_objectlist'][i_7461B].sna_lastcollection = 'original'
            bpy.app.timers.register(delayed_93EF5, first_interval=0.10000000149011612)


@persistent
def load_pre_handler_469D0(dummy):
    sna_fnspecialhideselected_5B387()


@persistent
def load_pre_handler_983F7(dummy):
    sna_fnspecialshow_F6D84()


def sna_fnspecialhideselected_5B387():
    sna_fnspecialhideobjects_9AA75(list(bpy.context.view_layer.objects.selected))


def sna_fnspecialhideunselected_75825():
    general_fns['sna_unselected'] = []
    general_fns['sna_unselected'] = list(bpy.data.objects)
    for i_87D1D in range(len(bpy.context.view_layer.objects.selected)-1,-1,-1):
        general_fns['sna_unselected'].remove(bpy.context.view_layer.objects.selected[i_87D1D])
    sna_fnspecialhideobjects_9AA75(general_fns['sna_unselected'])


def sna_fnsendselectedtobackup_26B39():
    sna_fnsendobjectstobackup_8AF45(list(bpy.context.view_layer.objects.selected))


def sna_fnduplicatesendtobackup_9725B():
    prev_context = bpy.context.area.type
    bpy.context.area.type = 'VIEW_3D'
    bpy.ops.object.duplicate('INVOKE_DEFAULT', )
    bpy.context.area.type = prev_context
    sna_fnsendobjectstobackup_8AF45(list(bpy.context.view_layer.objects.selected))


class SNA_OT_Set_Orientation_Global_52453(bpy.types.Operator):
    bl_idname = "sna.set_orientation_global_52453"
    bl_label = "Set Orientation Global"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetorientationglobal_490EC()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnsetorientationglobal_490EC():
    bpy.data.scenes['Scene'].transform_orientation_slots[0].type = 'GLOBAL'


class SNA_OT_Set_Orientation_Local_059E9(bpy.types.Operator):
    bl_idname = "sna.set_orientation_local_059e9"
    bl_label = "Set Orientation Local"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetorientationlocal_33E95()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnsetorientationlocal_33E95():
    bpy.data.scenes['Scene'].transform_orientation_slots[0].type = 'LOCAL'


class SNA_OT_Set_Orientation_Normal_B13Bc(bpy.types.Operator):
    bl_idname = "sna.set_orientation_normal_b13bc"
    bl_label = "Set Orientation Normal"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetorientationnormal_E7406()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnsetorientationnormal_E7406():
    bpy.data.scenes['Scene'].transform_orientation_slots[0].type = 'NORMAL'


class SNA_OT_Transform_Pivot_Median_Dfa9E(bpy.types.Operator):
    bl_idname = "sna.transform_pivot_median_dfa9e"
    bl_label = "Transform Pivot Median"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Transform_Pivot_Cursor_4Cdc9(bpy.types.Operator):
    bl_idname = "sna.transform_pivot_cursor_4cdc9"
    bl_label = "Transform Pivot Cursor"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Transform_Pivot_Individual_Ea6E3(bpy.types.Operator):
    bl_idname = "sna.transform_pivot_individual_ea6e3"
    bl_label = "Transform Pivot Individual"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.context.scene.tool_settings.transform_pivot_point = 'INDIVIDUAL_ORIGINS'")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_X_Fa140(bpy.types.Operator):
    bl_idname = "sna.zero_x_fa140"
    bl_label = "Zero X"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.location = (0.0, bpy.context.view_layer.objects.active.location[1], bpy.context.view_layer.objects.active.location[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_Y_4Bafe(bpy.types.Operator):
    bl_idname = "sna.zero_y_4bafe"
    bl_label = "Zero Y"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.location = (bpy.context.view_layer.objects.active.location[0], 0.0, bpy.context.view_layer.objects.active.location[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_Z_B09F4(bpy.types.Operator):
    bl_idname = "sna.zero_z_b09f4"
    bl_label = "Zero Z"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.location = (bpy.context.view_layer.objects.active.location[0], bpy.context.view_layer.objects.active.location[1], 0.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_X_Rot_4E822(bpy.types.Operator):
    bl_idname = "sna.zero_x_rot_4e822"
    bl_label = "Zero X Rot"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.rotation_euler = (0.0, bpy.context.view_layer.objects.active.rotation_euler[1], bpy.context.view_layer.objects.active.rotation_euler[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_Y_Rot_D3731(bpy.types.Operator):
    bl_idname = "sna.zero_y_rot_d3731"
    bl_label = "Zero Y Rot"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.rotation_euler = (bpy.context.view_layer.objects.active.rotation_euler[0], 0.0, bpy.context.view_layer.objects.active.rotation_euler[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_Z_Rot_E6449(bpy.types.Operator):
    bl_idname = "sna.zero_z_rot_e6449"
    bl_label = "Zero Z Rot"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.rotation_euler = (bpy.context.view_layer.objects.active.rotation_euler[0], bpy.context.view_layer.objects.active.rotation_euler[1], 0.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_X_Scale_2286B(bpy.types.Operator):
    bl_idname = "sna.reset_x_scale_2286b"
    bl_label = "Reset X Scale"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.scale = (1.0, bpy.context.view_layer.objects.active.scale[1], bpy.context.view_layer.objects.active.scale[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Y_Scale_21706(bpy.types.Operator):
    bl_idname = "sna.reset_y_scale_21706"
    bl_label = "Reset Y Scale"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.scale = (bpy.context.view_layer.objects.active.scale[0], 1.0, bpy.context.view_layer.objects.active.scale[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Z_Scale_C3816(bpy.types.Operator):
    bl_idname = "sna.reset_z_scale_c3816"
    bl_label = "Reset Z Scale"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.scale = (bpy.context.view_layer.objects.active.scale[0], bpy.context.view_layer.objects.active.scale[1], 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Show_Ops_F6C25(bpy.types.Operator):
    bl_idname = "sna.show_ops_f6c25"
    bl_label = "Show Ops"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showops = (not bpy.context.scene.sna_showops)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Mirror_Empty_F8D10(bpy.types.Operator):
    bl_idname = "sna.mirror_empty_f8d10"
    bl_label = "Mirror Empty"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnmirrorcompemtpy_CCFBA()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Send_Selectedto_Backup_5Ac5A(bpy.types.Operator):
    bl_idname = "sna.send_selectedto_backup_5ac5a"
    bl_label = "Send SelectedTo Backup"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsendselectedtobackup_26B39()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Snap_To_Face_Preset_5Ffa6(bpy.types.Operator):
    bl_idname = "sna.snap_to_face_preset_5ffa6"
    bl_label = "Snap To Face Preset"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetsnaptoface_EAB45()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Show_Creases_48169(bpy.types.Operator):
    bl_idname = "sna.toggle_show_creases_48169"
    bl_label = "Toggle Show Creases"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.area.spaces.active.overlay.show_edge_crease = (not bpy.context.area.spaces.active.overlay.show_edge_crease)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Show_Sharps_28E50(bpy.types.Operator):
    bl_idname = "sna.toggle_show_sharps_28e50"
    bl_label = "Toggle Show Sharps"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.area.spaces.active.overlay.show_edge_sharp = (not bpy.context.area.spaces.active.overlay.show_edge_sharp)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Show_Bevels_Cb2F7(bpy.types.Operator):
    bl_idname = "sna.toggle_show_bevels_cb2f7"
    bl_label = "Toggle Show Bevels"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.area.spaces.active.overlay.show_edge_bevel_weight = (not bpy.context.area.spaces.active.overlay.show_edge_bevel_weight)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Show_Seams_7408D(bpy.types.Operator):
    bl_idname = "sna.toggle_show_seams_7408d"
    bl_label = "Toggle Show Seams"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.area.spaces.active.overlay.show_edge_seams = (not bpy.context.area.spaces.active.overlay.show_edge_seams)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Shading_Matcap_E9F4F(bpy.types.Operator):
    bl_idname = "sna.set_shading_matcap_e9f4f"
    bl_label = "Set Shading MatCap"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetshadingmatcap_2CFE1()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Shading_Flat_87Cbc(bpy.types.Operator):
    bl_idname = "sna.set_shading_flat_87cbc"
    bl_label = "Set Shading Flat"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetshadingflat_3CF87()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Shading_Preview_9Ad3C(bpy.types.Operator):
    bl_idname = "sna.set_shading_preview_9ad3c"
    bl_label = "Set Shading Preview"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnsetshadingpreview_A8938()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Special_Hide_Selected_1C458(bpy.types.Operator):
    bl_idname = "sna.special_hide_selected_1c458"
    bl_label = "Special Hide Selected"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnspecialhideselected_5B387()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Special_Show_All_7E124(bpy.types.Operator):
    bl_idname = "sna.special_show_all_7e124"
    bl_label = "Special Show All"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnspecialshow_F6D84()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Special_Hide_Unselected_29928(bpy.types.Operator):
    bl_idname = "sna.special_hide_unselected_29928"
    bl_label = "Special Hide Unselected"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnspecialhideunselected_75825()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Wireframe_C8C58(bpy.types.Operator):
    bl_idname = "sna.toggle_wireframe_c8c58"
    bl_label = "Toggle Wireframe"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.show_wire = (not bpy.context.view_layer.objects.active.show_wire)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Duplicate_Send_To_Backup_8Be30(bpy.types.Operator):
    bl_idname = "sna.duplicate_send_to_backup_8be30"
    bl_label = "Duplicate Send To Backup"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnduplicatesendtobackup_9725B()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnmirrorcompemtpy_CCFBA():
    if bpy.context.view_layer.objects.selected:
        mirrorempty['sna_objectname'] = bpy.context.view_layer.objects.active.name
        if bpy.context.scene.sna_usecompendiumempty:
            sna_fnfindempty_6DACB()
        else:
            sna_fncreateempty_0F0F5()


def sna_fnfindempty_6DACB():
    for i_55B66 in range(len(bpy.data.objects)):
        if (bpy.data.objects[i_55B66].name == 'CompendiumEmpty'):
            mirrorempty['sna_foundobject'] = True
            break
    if mirrorempty['sna_foundobject']:
        sna_fnaddmirroremptymod_E16E4('CompendiumEmpty')
    else:
        sna_fncreateempty_0F0F5()


def sna_fncreateempty_0F0F5():
    bpy.ops.object.empty_add('INVOKE_DEFAULT', type='PLAIN_AXES', radius=1.0, align='WORLD', location=(0.0, 0.0, 0.0), rotation=(0.0, 0.0, 0.0), scale=(1.0, 1.0, 1.0))
    bpy.context.view_layer.objects.active.name = 'CompendiumEmpty'
    mirrorempty['sna_newempty'] = bpy.context.view_layer.objects.active.name
    sna_fnaddmirroremptymod_E16E4(mirrorempty['sna_newempty'])


def sna_fnaddmirroremptymod_E16E4(EmptyName):
    modifier_B2CEA = bpy.data.objects[mirrorempty['sna_objectname']].modifiers.new(name='Mirror Empty Mod', type='MIRROR', )
    output_0_5ba5f = sna_getobjectproperty_427FF_5BA5F(EmptyName)
    modifier_B2CEA.mirror_object = output_0_5ba5f


class SNA_PT_EDIT_TOOLS_00E1A(bpy.types.Panel):
    bl_label = 'Edit Tools'
    bl_idname = 'SNA_PT_EDIT_TOOLS_00E1A'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 1
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not (bpy.context.scene.sna_showtools and 'EDIT_MESH'==bpy.context.mode)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Viewport', icon_value=0)
        box_0C118 = layout.box()
        box_0C118.alert = False
        box_0C118.enabled = True
        box_0C118.active = True
        box_0C118.use_property_split = False
        box_0C118.use_property_decorate = False
        box_0C118.alignment = 'Expand'.upper()
        box_0C118.scale_x = 1.0
        box_0C118.scale_y = 1.0
        if not True: box_0C118.operator_context = "EXEC_DEFAULT"
        col_4AC21 = box_0C118.column(heading='', align=False)
        col_4AC21.alert = False
        col_4AC21.enabled = True
        col_4AC21.active = True
        col_4AC21.use_property_split = False
        col_4AC21.use_property_decorate = False
        col_4AC21.scale_x = 1.0
        col_4AC21.scale_y = 1.2999999523162842
        col_4AC21.alignment = 'Expand'.upper()
        col_4AC21.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_4AC21.operator('view3d.toggle_xray', text='Toggle X-Ray', icon_value=0, emboss=True, depress=bpy.context.area.spaces.active.shading.show_xray)
        col_ABD59 = box_0C118.column(heading='', align=True)
        col_ABD59.alert = False
        col_ABD59.enabled = True
        col_ABD59.active = True
        col_ABD59.use_property_split = False
        col_ABD59.use_property_decorate = False
        col_ABD59.scale_x = 1.0
        col_ABD59.scale_y = 1.100000023841858
        col_ABD59.alignment = 'Expand'.upper()
        col_ABD59.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_ABD59.operator('sna.set_shading_matcap_e9f4f', text='Matcap', icon_value=288, emboss=True, depress=False)
        op = col_ABD59.operator('sna.set_shading_flat_87cbc', text='Flat Attribute', icon_value=626, emboss=True, depress=False)
        op = col_ABD59.operator('sna.set_shading_preview_9ad3c', text='Material Preview', icon_value=628, emboss=True, depress=False)
        col_913D8 = box_0C118.column(heading='', align=False)
        col_913D8.alert = False
        col_913D8.enabled = True
        col_913D8.active = True
        col_913D8.use_property_split = False
        col_913D8.use_property_decorate = False
        col_913D8.scale_x = 1.0
        col_913D8.scale_y = 1.0
        col_913D8.alignment = 'Expand'.upper()
        col_913D8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        if 'EDIT_MESH'==bpy.context.mode:
            row_2EE1F = col_913D8.row(heading='', align=True)
            row_2EE1F.alert = False
            row_2EE1F.enabled = True
            row_2EE1F.active = True
            row_2EE1F.use_property_split = False
            row_2EE1F.use_property_decorate = False
            row_2EE1F.scale_x = 1.0
            row_2EE1F.scale_y = 1.100000023841858
            row_2EE1F.alignment = 'Expand'.upper()
            row_2EE1F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_2EE1F.operator('sna.toggle_show_creases_48169', text='Crease', icon_value=0, emboss=True, depress=bpy.context.area.spaces.active.overlay.show_edge_crease)
            op = row_2EE1F.operator('sna.toggle_show_sharps_28e50', text='Sharp', icon_value=0, emboss=True, depress=bpy.context.area.spaces.active.overlay.show_edge_sharp)
            op = row_2EE1F.operator('sna.toggle_show_bevels_cb2f7', text='Bevel', icon_value=0, emboss=True, depress=bpy.context.area.spaces.active.overlay.show_edge_bevel_weight)
            op = row_2EE1F.operator('sna.toggle_show_seams_7408d', text='Seams', icon_value=0, emboss=True, depress=bpy.context.area.spaces.active.overlay.show_edge_seams)
        layout.label(text='OPS', icon_value=0)
        box_1B8F3 = layout.box()
        box_1B8F3.alert = False
        box_1B8F3.enabled = True
        box_1B8F3.active = True
        box_1B8F3.use_property_split = False
        box_1B8F3.use_property_decorate = False
        box_1B8F3.alignment = 'Expand'.upper()
        box_1B8F3.scale_x = 1.0
        box_1B8F3.scale_y = 1.0
        if not True: box_1B8F3.operator_context = "EXEC_DEFAULT"
        col_6F0F4 = box_1B8F3.column(heading='', align=False)
        col_6F0F4.alert = False
        col_6F0F4.enabled = True
        col_6F0F4.active = True
        col_6F0F4.use_property_split = False
        col_6F0F4.use_property_decorate = False
        col_6F0F4.scale_x = 1.0
        col_6F0F4.scale_y = 1.0
        col_6F0F4.alignment = 'Expand'.upper()
        col_6F0F4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        if property_exists("bpy.context.preferences.addons['forgotten_tools']", globals(), locals()):
            col_63071 = col_6F0F4.column(heading='', align=False)
            col_63071.alert = False
            col_63071.enabled = True
            col_63071.active = True
            col_63071.use_property_split = False
            col_63071.use_property_decorate = False
            col_63071.scale_x = 1.0
            col_63071.scale_y = 1.0
            col_63071.alignment = 'Expand'.upper()
            col_63071.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_63071.label(text='Forgotten Tools', icon_value=0)
            op = col_63071.operator('mesh.forgotten_separate_duplicate', text='Separate Duplicate', icon_value=0, emboss=True, depress=False)
            op = col_63071.operator('forgotten.mesh_straighten', text='Straighten', icon_value=0, emboss=True, depress=False)
            op = col_63071.operator('forgotten.mesh_hinge', text='Hinge', icon_value=0, emboss=True, depress=False)
        if property_exists("bpy.context.preferences.addons['bl_ext.blender_org.looptools']", globals(), locals()):
            col_55FE6 = col_6F0F4.column(heading='', align=False)
            col_55FE6.alert = False
            col_55FE6.enabled = True
            col_55FE6.active = True
            col_55FE6.use_property_split = False
            col_55FE6.use_property_decorate = False
            col_55FE6.scale_x = 1.0
            col_55FE6.scale_y = 1.0
            col_55FE6.alignment = 'Expand'.upper()
            col_55FE6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_55FE6.label(text='LoopTools', icon_value=0)
            op = col_55FE6.operator('mesh.looptools_relax', text='Relax', icon_value=0, emboss=True, depress=False)
            op.regular = True
            op = col_55FE6.operator('mesh.looptools_flatten', text='Flatten', icon_value=0, emboss=True, depress=False)
            op.influence = 100.0
            op = col_55FE6.operator('mesh.looptools_circle', text='Circle', icon_value=0, emboss=True, depress=False)
        if property_exists("bpy.context.preferences.addons['bl_ext.user_default.EdgeFlow']", globals(), locals()):
            col_77A4E = col_6F0F4.column(heading='', align=False)
            col_77A4E.alert = False
            col_77A4E.enabled = True
            col_77A4E.active = True
            col_77A4E.use_property_split = False
            col_77A4E.use_property_decorate = False
            col_77A4E.scale_x = 1.0
            col_77A4E.scale_y = 1.0
            col_77A4E.alignment = 'Expand'.upper()
            col_77A4E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_77A4E.label(text='Edge Flow', icon_value=0)
            op = col_77A4E.operator('mesh.set_edge_flow', text='Set Edge Flow', icon_value=0, emboss=True, depress=False)
            op = col_77A4E.operator('mesh.set_edge_linear', text='Set Linear Flow', icon_value=0, emboss=True, depress=False)
            op = col_77A4E.operator('mesh.set_edge_curve', text='Set Edge Curve', icon_value=0, emboss=True, depress=False)


class SNA_PT_ITEM_INFO_68721(bpy.types.Panel):
    bl_label = 'Item Info'
    bl_idname = 'SNA_PT_ITEM_INFO_68721'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not bpy.context.scene.sna_showiteminfo))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if bpy.context.view_layer.objects.active:
            col_81D10 = layout.column(heading='', align=False)
            col_81D10.alert = False
            col_81D10.enabled = True
            col_81D10.active = True
            col_81D10.use_property_split = False
            col_81D10.use_property_decorate = False
            col_81D10.scale_x = 1.0
            col_81D10.scale_y = 1.0
            col_81D10.alignment = 'Expand'.upper()
            col_81D10.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_81D10.label(text='Location', icon_value=0)
            split_B377C = col_81D10.split(factor=0.8399999737739563, align=True)
            split_B377C.alert = False
            split_B377C.enabled = True
            split_B377C.active = True
            split_B377C.use_property_split = False
            split_B377C.use_property_decorate = False
            split_B377C.scale_x = 1.0
            split_B377C.scale_y = 1.0
            split_B377C.alignment = 'Expand'.upper()
            if not True: split_B377C.operator_context = "EXEC_DEFAULT"
            col_31DDF = split_B377C.column(heading='', align=True)
            col_31DDF.alert = False
            col_31DDF.enabled = True
            col_31DDF.active = True
            col_31DDF.use_property_split = False
            col_31DDF.use_property_decorate = False
            col_31DDF.scale_x = 1.0
            col_31DDF.scale_y = 1.0
            col_31DDF.alignment = 'Expand'.upper()
            col_31DDF.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_31DDF.prop(bpy.context.view_layer.objects.active, 'location', text='', icon_value=0, emboss=True)
            col_7500E = split_B377C.column(heading='', align=True)
            col_7500E.alert = False
            col_7500E.enabled = True
            col_7500E.active = True
            col_7500E.use_property_split = False
            col_7500E.use_property_decorate = False
            col_7500E.scale_x = 1.0
            col_7500E.scale_y = 1.0
            col_7500E.alignment = 'Expand'.upper()
            col_7500E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_7500E.operator('sna.zero_x_fa140', text='', icon_value=643, emboss=True, depress=False)
            op = col_7500E.operator('sna.zero_y_4bafe', text='', icon_value=643, emboss=True, depress=False)
            op = col_7500E.operator('sna.zero_z_b09f4', text='', icon_value=643, emboss=True, depress=False)
            col_81D10.label(text='Rotation', icon_value=0)
            split_85090 = col_81D10.split(factor=0.8399999737739563, align=True)
            split_85090.alert = False
            split_85090.enabled = True
            split_85090.active = True
            split_85090.use_property_split = False
            split_85090.use_property_decorate = False
            split_85090.scale_x = 1.0
            split_85090.scale_y = 1.0
            split_85090.alignment = 'Expand'.upper()
            if not True: split_85090.operator_context = "EXEC_DEFAULT"
            col_69E30 = split_85090.column(heading='', align=True)
            col_69E30.alert = False
            col_69E30.enabled = True
            col_69E30.active = True
            col_69E30.use_property_split = False
            col_69E30.use_property_decorate = False
            col_69E30.scale_x = 1.0
            col_69E30.scale_y = 1.0
            col_69E30.alignment = 'Expand'.upper()
            col_69E30.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_69E30.prop(bpy.context.view_layer.objects.active, 'rotation_euler', text='', icon_value=0, emboss=True)
            col_D81DD = split_85090.column(heading='', align=True)
            col_D81DD.alert = False
            col_D81DD.enabled = True
            col_D81DD.active = True
            col_D81DD.use_property_split = False
            col_D81DD.use_property_decorate = False
            col_D81DD.scale_x = 1.0
            col_D81DD.scale_y = 1.0
            col_D81DD.alignment = 'Expand'.upper()
            col_D81DD.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_D81DD.operator('sna.zero_x_rot_4e822', text='', icon_value=643, emboss=True, depress=False)
            op = col_D81DD.operator('sna.zero_y_rot_d3731', text='', icon_value=643, emboss=True, depress=False)
            op = col_D81DD.operator('sna.zero_z_rot_e6449', text='', icon_value=643, emboss=True, depress=False)
            col_81D10.label(text='Scale', icon_value=0)
            split_93B6A = col_81D10.split(factor=0.8399999737739563, align=True)
            split_93B6A.alert = False
            split_93B6A.enabled = True
            split_93B6A.active = True
            split_93B6A.use_property_split = False
            split_93B6A.use_property_decorate = False
            split_93B6A.scale_x = 1.0
            split_93B6A.scale_y = 1.0
            split_93B6A.alignment = 'Expand'.upper()
            if not True: split_93B6A.operator_context = "EXEC_DEFAULT"
            col_B814F = split_93B6A.column(heading='', align=True)
            col_B814F.alert = False
            col_B814F.enabled = True
            col_B814F.active = True
            col_B814F.use_property_split = False
            col_B814F.use_property_decorate = False
            col_B814F.scale_x = 1.0
            col_B814F.scale_y = 1.0
            col_B814F.alignment = 'Expand'.upper()
            col_B814F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_B814F.prop(bpy.context.view_layer.objects.active, 'scale', text='', icon_value=0, emboss=True)
            col_98DBC = split_93B6A.column(heading='', align=True)
            col_98DBC.alert = False
            col_98DBC.enabled = True
            col_98DBC.active = True
            col_98DBC.use_property_split = False
            col_98DBC.use_property_decorate = False
            col_98DBC.scale_x = 1.0
            col_98DBC.scale_y = 1.0
            col_98DBC.alignment = 'Expand'.upper()
            col_98DBC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_98DBC.operator('sna.reset_x_scale_2286b', text='', icon_value=643, emboss=True, depress=False)
            op = col_98DBC.operator('sna.reset_y_scale_21706', text='', icon_value=643, emboss=True, depress=False)
            op = col_98DBC.operator('sna.reset_z_scale_c3816', text='', icon_value=643, emboss=True, depress=False)
        else:
            layout.label(text='No Active Item', icon_value=0)
        if bpy.context.view_layer.objects.active:
            col_0A475 = layout.column(heading='', align=False)
            col_0A475.alert = False
            col_0A475.enabled = True
            col_0A475.active = True
            col_0A475.use_property_split = False
            col_0A475.use_property_decorate = False
            col_0A475.scale_x = 1.0
            col_0A475.scale_y = 1.2000000476837158
            col_0A475.alignment = 'Expand'.upper()
            col_0A475.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_0A475.operator('sna.toggle_wireframe_c8c58', text='Show Wireframe', icon_value=625, emboss=True, depress=bpy.context.view_layer.objects.active.show_wire)


class SNA_PT_OBJECTTOOLS_73861(bpy.types.Panel):
    bl_label = 'ObjectTools'
    bl_idname = 'SNA_PT_OBJECTTOOLS_73861'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 1
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not (bpy.context.scene.sna_showtools and 'OBJECT'==bpy.context.mode)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Viewport', icon_value=0)
        box_B5126 = layout.box()
        box_B5126.alert = False
        box_B5126.enabled = True
        box_B5126.active = True
        box_B5126.use_property_split = False
        box_B5126.use_property_decorate = False
        box_B5126.alignment = 'Expand'.upper()
        box_B5126.scale_x = 1.0
        box_B5126.scale_y = 1.0
        if not True: box_B5126.operator_context = "EXEC_DEFAULT"
        col_AE10E = box_B5126.column(heading='', align=False)
        col_AE10E.alert = False
        col_AE10E.enabled = True
        col_AE10E.active = True
        col_AE10E.use_property_split = False
        col_AE10E.use_property_decorate = False
        col_AE10E.scale_x = 1.0
        col_AE10E.scale_y = 1.2999999523162842
        col_AE10E.alignment = 'Expand'.upper()
        col_AE10E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_AE10E.operator('view3d.toggle_xray', text='Toggle X-Ray', icon_value=0, emboss=True, depress=bpy.context.area.spaces.active.shading.show_xray)
        col_6CDA1 = box_B5126.column(heading='', align=True)
        col_6CDA1.alert = False
        col_6CDA1.enabled = True
        col_6CDA1.active = True
        col_6CDA1.use_property_split = False
        col_6CDA1.use_property_decorate = False
        col_6CDA1.scale_x = 1.0
        col_6CDA1.scale_y = 1.100000023841858
        col_6CDA1.alignment = 'Expand'.upper()
        col_6CDA1.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_6CDA1.operator('sna.set_shading_matcap_e9f4f', text='Matcap', icon_value=288, emboss=True, depress=False)
        op = col_6CDA1.operator('sna.set_shading_flat_87cbc', text='Flat Attribute', icon_value=626, emboss=True, depress=False)
        op = col_6CDA1.operator('sna.set_shading_preview_9ad3c', text='Material Preview', icon_value=628, emboss=True, depress=False)
        layout.label(text='OPS', icon_value=0)
        box_0A9C5 = layout.box()
        box_0A9C5.alert = False
        box_0A9C5.enabled = True
        box_0A9C5.active = True
        box_0A9C5.use_property_split = False
        box_0A9C5.use_property_decorate = False
        box_0A9C5.alignment = 'Expand'.upper()
        box_0A9C5.scale_x = 1.0
        box_0A9C5.scale_y = 1.0
        if not True: box_0A9C5.operator_context = "EXEC_DEFAULT"
        col_6FAD6 = box_0A9C5.column(heading='', align=False)
        col_6FAD6.alert = False
        col_6FAD6.enabled = True
        col_6FAD6.active = True
        col_6FAD6.use_property_split = False
        col_6FAD6.use_property_decorate = False
        col_6FAD6.scale_x = 1.0
        col_6FAD6.scale_y = 1.0
        col_6FAD6.alignment = 'Expand'.upper()
        col_6FAD6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_6FAD6.operator('object.origin_set', text='Set Origin (Volume)', icon_value=0, emboss=True, depress=False)
        op.type = 'ORIGIN_CENTER_OF_VOLUME'
        op = col_6FAD6.operator('object.origin_set', text='Set Origin (Cursor)', icon_value=0, emboss=True, depress=False)
        op.type = 'ORIGIN_CENTER_OF_VOLUME'
        op = col_6FAD6.operator('object.convert', text='Convert To Mesh', icon_value=0, emboss=True, depress=False)
        op.target = 'MESH'


class SNA_PT_SETTINGS_PANEL_9ABCF(bpy.types.Panel):
    bl_label = 'Settings Panel'
    bl_idname = 'SNA_PT_SETTINGS_PANEL_9ABCF'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not bpy.context.scene.sna_showrendersettings))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Compendium Settings', icon_value=0)
        box_407F8 = layout.box()
        box_407F8.alert = False
        box_407F8.enabled = True
        box_407F8.active = True
        box_407F8.use_property_split = False
        box_407F8.use_property_decorate = False
        box_407F8.alignment = 'Expand'.upper()
        box_407F8.scale_x = 1.0
        box_407F8.scale_y = 1.0
        if not True: box_407F8.operator_context = "EXEC_DEFAULT"
        box_407F8.prop(bpy.context.scene, 'sna_usecompendiumempty', text='Use Compendium Empty', icon_value=0, emboss=True)
        box_407F8.prop(bpy.context.preferences.inputs, 'use_mouse_emulate_3_button', text='Emulate Mouse 3', icon_value=0, emboss=True)
        box_407F8.prop(bpy.context.scene, 'sna_vpworkflow', text='Vertex Paint Workflow', icon_value=0, emboss=True)
        layout.label(text='Presets:', icon_value=0)
        box_11461 = layout.box()
        box_11461.alert = False
        box_11461.enabled = True
        box_11461.active = True
        box_11461.use_property_split = False
        box_11461.use_property_decorate = False
        box_11461.alignment = 'Expand'.upper()
        box_11461.scale_x = 1.0
        box_11461.scale_y = 1.0
        if not True: box_11461.operator_context = "EXEC_DEFAULT"
        op = box_11461.operator('sna.snap_to_face_preset_5ffa6', text='Snap To Face (Preset)', icon_value=582, emboss=True, depress=False)
        layout.label(text='Viewport Settings:', icon_value=0)
        box_5B3E9 = layout.box()
        box_5B3E9.alert = False
        box_5B3E9.enabled = True
        box_5B3E9.active = True
        box_5B3E9.use_property_split = False
        box_5B3E9.use_property_decorate = False
        box_5B3E9.alignment = 'Expand'.upper()
        box_5B3E9.scale_x = 1.0
        box_5B3E9.scale_y = 1.0
        if not True: box_5B3E9.operator_context = "EXEC_DEFAULT"
        box_5B3E9.prop(bpy.context.area.spaces[0], 'lock_camera', text='Camera To View', icon_value=(41 if bpy.context.area.spaces[0].lock_camera else 40), emboss=True)
        layout.label(text='Render Settings:', icon_value=0)
        box_DBA4D = layout.box()
        box_DBA4D.alert = False
        box_DBA4D.enabled = True
        box_DBA4D.active = True
        box_DBA4D.use_property_split = False
        box_DBA4D.use_property_decorate = False
        box_DBA4D.alignment = 'Expand'.upper()
        box_DBA4D.scale_x = 1.0
        box_DBA4D.scale_y = 1.0
        if not True: box_DBA4D.operator_context = "EXEC_DEFAULT"
        box_DBA4D.prop(bpy.context.scene.render, 'film_transparent', text='Transparent Background', icon_value=0, emboss=True)
        layout.label(text='Export Presets:', icon_value=0)
        box_5AA6B = layout.box()
        box_5AA6B.alert = False
        box_5AA6B.enabled = 'OBJECT'==bpy.context.mode
        box_5AA6B.active = True
        box_5AA6B.use_property_split = False
        box_5AA6B.use_property_decorate = False
        box_5AA6B.alignment = 'Expand'.upper()
        box_5AA6B.scale_x = 1.0
        box_5AA6B.scale_y = 1.0
        if not True: box_5AA6B.operator_context = "EXEC_DEFAULT"
        op = box_5AA6B.operator('export_scene.fbx', text='Selected To FBX', icon_value=0, emboss=True, depress=False)
        op.use_selection = True
        op.apply_unit_scale = True
        op.use_space_transform = True
        op.object_types = {'MESH'}
        op.bake_anim = False
        op.axis_forward = '-Z'
        op.axis_up = 'Y'


class SNA_MT_F2EBE(bpy.types.Menu):
    bl_idname = "SNA_MT_F2EBE"
    bl_label = "Modes"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.menu_pie()
        if ('OBJECT'==bpy.context.mode or 'EDIT_MESH'==bpy.context.mode):
            if bpy.context.view_layer.objects.active.type == 'MESH':
                op = layout.operator('sna.vert_mode_34ed6', text='Vert', icon_value=546, emboss=True, depress=False)
            else:
                layout.separator(factor=1.0)
        else:
            layout.separator(factor=1.0)
        if ('OBJECT'==bpy.context.mode or 'EDIT_MESH'==bpy.context.mode):
            if bpy.context.view_layer.objects.active.type == 'MESH':
                op = layout.operator('sna.face_mode_44e6b', text='Face', icon_value=548, emboss=True, depress=False)
            else:
                layout.separator(factor=1.0)
        else:
            layout.separator(factor=1.0)
        if ('OBJECT'==bpy.context.mode or 'EDIT_MESH'==bpy.context.mode):
            if bpy.context.view_layer.objects.active.type == 'MESH':
                op = layout.operator('sna.edge_mode_74d78', text='Edge', icon_value=547, emboss=True, depress=False)
            else:
                layout.separator(factor=1.0)
        else:
            layout.separator(factor=1.0)
        if 'OBJECT'==bpy.context.mode:
            op = layout.operator('object.mode_set', text='Edit', icon_value=548, emboss=True, depress=False)
            op.mode = 'EDIT'
        else:
            op = layout.operator('object.mode_set', text='Object', icon_value=548, emboss=True, depress=False)
            op.mode = 'OBJECT'
        if 'POSE'==bpy.context.mode:
            layout.separator(factor=1.0)
        else:
            if bpy.context.view_layer.objects.active.type == 'ARMATURE':
                layout.separator(factor=1.0)
            else:
                row_43D41 = layout.row(heading='', align=True)
                row_43D41.alert = False
                row_43D41.enabled = True
                row_43D41.active = True
                row_43D41.use_property_split = False
                row_43D41.use_property_decorate = False
                row_43D41.scale_x = 1.2999999523162842
                row_43D41.scale_y = 1.2999999523162842
                row_43D41.alignment = 'Expand'.upper()
                row_43D41.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                op = row_43D41.operator('object.mode_set', text='', icon_value=134, emboss=True, depress=False)
                op.mode = 'TEXTURE_PAINT'
                op = row_43D41.operator('object.mode_set', text='', icon_value=135, emboss=True, depress=False)
                op.mode = 'WEIGHT_PAINT'
                op = row_43D41.operator('object.mode_set', text='', icon_value=133, emboss=True, depress=False)
                op.mode = 'VERTEX_PAINT'
                op = row_43D41.operator('object.mode_set', text='', icon_value=136, emboss=True, depress=False)
                op.mode = 'SCULPT'
                op = row_43D41.operator('object.mode_set', text='', icon_value=130, emboss=True, depress=False)
                op.mode = 'OBJECT'
                op = row_43D41.operator('object.mode_set', text='', icon_value=131, emboss=True, depress=False)
                op.mode = 'EDIT'
        if ('SCULPT'==bpy.context.mode or 'POSE'==bpy.context.mode):
            op = layout.operator('object.mode_set', text='Edit', icon_value=131, emboss=True, depress=False)
            op.mode = 'EDIT'
        else:
            if bpy.context.view_layer.objects.active.type == 'ARMATURE':
                op = layout.operator('object.mode_set', text='Pose', icon_value=131, emboss=True, depress=False)
                op.mode = 'POSE'
            else:
                if bpy.context.scene.sna_vpworkflow:
                    if 'PAINT_VERTEX'==bpy.context.mode:
                        op = layout.operator('object.mode_set', text='Edit', icon_value=131, emboss=True, depress=False)
                        op.mode = 'EDIT'
                    else:
                        op = layout.operator('object.mode_set', text='Vertex Paint', icon_value=133, emboss=True, depress=False)
                        op.mode = 'VERTEX_PAINT'
                else:
                    op = layout.operator('object.mode_set', text='Sculpt', icon_value=131, emboss=True, depress=False)
                    op.mode = 'SCULPT'


class SNA_OT_Face_Mode_44E6B(bpy.types.Operator):
    bl_idname = "sna.face_mode_44e6b"
    bl_label = "Face Mode"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if 'EDIT_MESH'==bpy.context.mode:
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='FACE', action='ENABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='EDGE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='DISABLE')
        else:
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='EDIT')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='FACE', action='ENABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='EDGE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='DISABLE')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Vert_Mode_34Ed6(bpy.types.Operator):
    bl_idname = "sna.vert_mode_34ed6"
    bl_label = "Vert Mode"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if 'EDIT_MESH'==bpy.context.mode:
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='FACE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='EDGE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='ENABLE')
        else:
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='EDIT')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='FACE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='EDGE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='ENABLE')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Edge_Mode_74D78(bpy.types.Operator):
    bl_idname = "sna.edge_mode_74d78"
    bl_label = "Edge Mode"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if 'EDIT_MESH'==bpy.context.mode:
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='FACE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='EDGE', action='ENABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='DISABLE')
        else:
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='EDIT')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='FACE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='EDGE', action='ENABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='DISABLE')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_MT_5FC8E(bpy.types.Menu):
    bl_idname = "SNA_MT_5FC8E"
    bl_label = "Scupt Tools"

    @classmethod
    def poll(cls, context):
        return not ((not 'SCULPT'==bpy.context.mode))

    def draw(self, context):
        layout = self.layout.menu_pie()
        col_ACE1B = layout.column(heading='', align=True)
        col_ACE1B.alert = False
        col_ACE1B.enabled = True
        col_ACE1B.active = True
        col_ACE1B.use_property_split = False
        col_ACE1B.use_property_decorate = False
        col_ACE1B.scale_x = 1.0
        col_ACE1B.scale_y = 1.2000000476837158
        col_ACE1B.alignment = 'Expand'.upper()
        col_ACE1B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_ACE1B.operator('wm.tool_set_by_id', text='Crease', icon_value=0, emboss=True, depress=False)
        op.name = 'builtin_brush.Crease'
        op.space_type = 'VIEW_3D'
        op = col_ACE1B.operator('wm.tool_set_by_id', text='Snake', icon_value=0, emboss=True, depress=False)
        op.name = 'builtin_brush.Snake Hook'
        op.space_type = 'VIEW_3D'
        op = col_ACE1B.operator('wm.tool_set_by_id', text='Draw S', icon_value=0, emboss=True, depress=False)
        op.name = 'builtin_brush.Draw Sharp'
        op.space_type = 'VIEW_3D'
        op = col_ACE1B.operator('wm.tool_set_by_id', text='Scrape', icon_value=0, emboss=True, depress=False)
        op.name = 'builtin_brush.Scrape'
        op.space_type = 'VIEW_3D'
        op = col_ACE1B.operator('wm.tool_set_by_id', text='Buildup', icon_value=0, emboss=True, depress=False)
        op.name = 'builtin_brush.Clay Strips'
        op.space_type = 'VIEW_3D'
        op = layout.operator('wm.tool_set_by_id', text='Grab', icon_value=778, emboss=True, depress=False)
        op.name = 'builtin_brush.Grab'
        op.space_type = 'VIEW_3D'
        op = layout.operator('wm.tool_set_by_id', text='Relax', icon_value=0, emboss=True, depress=False)
        op.name = 'builtin_brush.Slide Relax'
        op.space_type = 'VIEW_3D'
        row_8FF7C = layout.row(heading='', align=False)
        row_8FF7C.alert = False
        row_8FF7C.enabled = True
        row_8FF7C.active = True
        row_8FF7C.use_property_split = False
        row_8FF7C.use_property_decorate = False
        row_8FF7C.scale_x = 1.0
        row_8FF7C.scale_y = 1.0
        row_8FF7C.alignment = 'Expand'.upper()
        row_8FF7C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_8FF7C.prop(bpy.data.scenes['Scene'].tool_settings.unified_paint_settings, 'size', text='', icon_value=0, emboss=True)
        row_8FF7C.prop(bpy.context.view_layer.objects.active, 'show_wire', text='', icon_value=625, emboss=True)
        layout.separator(factor=1.0)
        layout.separator(factor=1.0)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_newcollectionname = bpy.props.StringProperty(name='NewCollectionName', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_showtools = bpy.props.BoolProperty(name='ShowTools', description='', default=True)
    bpy.types.Scene.sna_showrendersettings = bpy.props.BoolProperty(name='ShowRenderSettings', description='', default=False)
    bpy.types.Scene.sna_shownumpad = bpy.props.BoolProperty(name='ShowNumPad', description='', default=False)
    bpy.types.Scene.sna_showiteminfo = bpy.props.BoolProperty(name='ShowItemInfo', description='', default=False)
    bpy.types.Scene.sna_showops = bpy.props.BoolProperty(name='ShowOps', description='', default=False)
    bpy.types.Scene.sna_usecompendiumempty = bpy.props.BoolProperty(name='UseCompendiumEmpty', description='', default=True)
    bpy.types.Object.sna_lastcollection = bpy.props.StringProperty(name='LastCollection', description='', default='original', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_vpworkflow = bpy.props.BoolProperty(name='VPWorkflow', description='', default=False)
    bpy.utils.register_class(SNA_PT_COMPENDIUM_7BFB0)
    bpy.utils.register_class(SNA_OT_Toggle_Tools_F006F)
    bpy.utils.register_class(SNA_OT_Toggle_Render_Settings_04Ec7)
    bpy.utils.register_class(SNA_OT_Toggle_Num_Pad_A5753)
    bpy.utils.register_class(SNA_OT_Toggle_Item_Info_B0C71)
    bpy.utils.register_class(SNA_MT_A3D1B)
    bpy.utils.register_class(SNA_OT_Forgotten_Tools_Link_F1Fdb)
    bpy.utils.register_class(SNA_OT_Edge_Flow_Link_Fd608)
    bpy.utils.register_class(SNA_AddonPreferences_63B78)
    bpy.utils.register_class(SNA_OT_Togglem3_8535A)
    bpy.types.VIEW3D_MT_editor_menus.prepend(sna_add_to_view3d_mt_editor_menus_80153)
    bpy.utils.register_class(SNA_PT_EXPORT_99553)
    bpy.utils.register_class(SNA_OT_Export_Fbx_Skeletal_Mesh_Bc07E)
    bpy.utils.register_class(SNA_OT_Export_Fbx_Animation_5Ee0A)
    bpy.utils.register_class(SNA_OT_Export_Fbx_All_Animations_45844)
    bpy.app.handlers.load_pre.append(load_pre_handler_469D0)
    bpy.app.handlers.load_pre.append(load_pre_handler_983F7)
    bpy.utils.register_class(SNA_OT_Set_Orientation_Global_52453)
    bpy.utils.register_class(SNA_OT_Set_Orientation_Local_059E9)
    bpy.utils.register_class(SNA_OT_Set_Orientation_Normal_B13Bc)
    bpy.utils.register_class(SNA_OT_Transform_Pivot_Median_Dfa9E)
    bpy.utils.register_class(SNA_OT_Transform_Pivot_Cursor_4Cdc9)
    bpy.utils.register_class(SNA_OT_Transform_Pivot_Individual_Ea6E3)
    bpy.utils.register_class(SNA_OT_Zero_X_Fa140)
    bpy.utils.register_class(SNA_OT_Zero_Y_4Bafe)
    bpy.utils.register_class(SNA_OT_Zero_Z_B09F4)
    bpy.utils.register_class(SNA_OT_Zero_X_Rot_4E822)
    bpy.utils.register_class(SNA_OT_Zero_Y_Rot_D3731)
    bpy.utils.register_class(SNA_OT_Zero_Z_Rot_E6449)
    bpy.utils.register_class(SNA_OT_Reset_X_Scale_2286B)
    bpy.utils.register_class(SNA_OT_Reset_Y_Scale_21706)
    bpy.utils.register_class(SNA_OT_Reset_Z_Scale_C3816)
    bpy.utils.register_class(SNA_OT_Show_Ops_F6C25)
    bpy.utils.register_class(SNA_OT_Mirror_Empty_F8D10)
    bpy.utils.register_class(SNA_OT_Send_Selectedto_Backup_5Ac5A)
    bpy.utils.register_class(SNA_OT_Snap_To_Face_Preset_5Ffa6)
    bpy.utils.register_class(SNA_OT_Toggle_Show_Creases_48169)
    bpy.utils.register_class(SNA_OT_Toggle_Show_Sharps_28E50)
    bpy.utils.register_class(SNA_OT_Toggle_Show_Bevels_Cb2F7)
    bpy.utils.register_class(SNA_OT_Toggle_Show_Seams_7408D)
    bpy.utils.register_class(SNA_OT_Set_Shading_Matcap_E9F4F)
    bpy.utils.register_class(SNA_OT_Set_Shading_Flat_87Cbc)
    bpy.utils.register_class(SNA_OT_Set_Shading_Preview_9Ad3C)
    bpy.utils.register_class(SNA_OT_Special_Hide_Selected_1C458)
    bpy.utils.register_class(SNA_OT_Special_Show_All_7E124)
    bpy.utils.register_class(SNA_OT_Special_Hide_Unselected_29928)
    bpy.utils.register_class(SNA_OT_Toggle_Wireframe_C8C58)
    bpy.utils.register_class(SNA_OT_Duplicate_Send_To_Backup_8Be30)
    bpy.utils.register_class(SNA_PT_EDIT_TOOLS_00E1A)
    bpy.utils.register_class(SNA_PT_ITEM_INFO_68721)
    bpy.utils.register_class(SNA_PT_OBJECTTOOLS_73861)
    bpy.utils.register_class(SNA_PT_SETTINGS_PANEL_9ABCF)
    bpy.utils.register_class(SNA_MT_F2EBE)
    bpy.utils.register_class(SNA_OT_Face_Mode_44E6B)
    bpy.utils.register_class(SNA_OT_Vert_Mode_34Ed6)
    bpy.utils.register_class(SNA_OT_Edge_Mode_74D78)
    bpy.utils.register_class(SNA_MT_5FC8E)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'E', 'PRESS',
        ctrl=False, alt=False, shift=True, repeat=False)
    kmi.properties.name = 'SNA_MT_A3D1B'
    addon_keymaps['74368'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new('sna.togglem3_8535a', 'BACK_SLASH', 'PRESS',
        ctrl=False, alt=False, shift=False, repeat=False)
    addon_keymaps['ADF2F'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'TAB', 'PRESS',
        ctrl=False, alt=False, shift=False, repeat=False)
    kmi.properties.name = 'SNA_MT_F2EBE'
    addon_keymaps['9C020'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'E', 'PRESS',
        ctrl=False, alt=False, shift=True, repeat=False)
    kmi.properties.name = 'SNA_MT_5FC8E'
    addon_keymaps['3EA7D'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_vpworkflow
    del bpy.types.Object.sna_lastcollection
    del bpy.types.Scene.sna_usecompendiumempty
    del bpy.types.Scene.sna_showops
    del bpy.types.Scene.sna_showiteminfo
    del bpy.types.Scene.sna_shownumpad
    del bpy.types.Scene.sna_showrendersettings
    del bpy.types.Scene.sna_showtools
    del bpy.types.Scene.sna_newcollectionname
    bpy.utils.unregister_class(SNA_PT_COMPENDIUM_7BFB0)
    bpy.utils.unregister_class(SNA_OT_Toggle_Tools_F006F)
    bpy.utils.unregister_class(SNA_OT_Toggle_Render_Settings_04Ec7)
    bpy.utils.unregister_class(SNA_OT_Toggle_Num_Pad_A5753)
    bpy.utils.unregister_class(SNA_OT_Toggle_Item_Info_B0C71)
    bpy.utils.unregister_class(SNA_MT_A3D1B)
    bpy.utils.unregister_class(SNA_OT_Forgotten_Tools_Link_F1Fdb)
    bpy.utils.unregister_class(SNA_OT_Edge_Flow_Link_Fd608)
    bpy.utils.unregister_class(SNA_AddonPreferences_63B78)
    bpy.utils.unregister_class(SNA_OT_Togglem3_8535A)
    bpy.types.VIEW3D_MT_editor_menus.remove(sna_add_to_view3d_mt_editor_menus_80153)
    bpy.utils.unregister_class(SNA_PT_EXPORT_99553)
    bpy.utils.unregister_class(SNA_OT_Export_Fbx_Skeletal_Mesh_Bc07E)
    bpy.utils.unregister_class(SNA_OT_Export_Fbx_Animation_5Ee0A)
    bpy.utils.unregister_class(SNA_OT_Export_Fbx_All_Animations_45844)
    bpy.app.handlers.load_pre.remove(load_pre_handler_469D0)
    bpy.app.handlers.load_pre.remove(load_pre_handler_983F7)
    bpy.utils.unregister_class(SNA_OT_Set_Orientation_Global_52453)
    bpy.utils.unregister_class(SNA_OT_Set_Orientation_Local_059E9)
    bpy.utils.unregister_class(SNA_OT_Set_Orientation_Normal_B13Bc)
    bpy.utils.unregister_class(SNA_OT_Transform_Pivot_Median_Dfa9E)
    bpy.utils.unregister_class(SNA_OT_Transform_Pivot_Cursor_4Cdc9)
    bpy.utils.unregister_class(SNA_OT_Transform_Pivot_Individual_Ea6E3)
    bpy.utils.unregister_class(SNA_OT_Zero_X_Fa140)
    bpy.utils.unregister_class(SNA_OT_Zero_Y_4Bafe)
    bpy.utils.unregister_class(SNA_OT_Zero_Z_B09F4)
    bpy.utils.unregister_class(SNA_OT_Zero_X_Rot_4E822)
    bpy.utils.unregister_class(SNA_OT_Zero_Y_Rot_D3731)
    bpy.utils.unregister_class(SNA_OT_Zero_Z_Rot_E6449)
    bpy.utils.unregister_class(SNA_OT_Reset_X_Scale_2286B)
    bpy.utils.unregister_class(SNA_OT_Reset_Y_Scale_21706)
    bpy.utils.unregister_class(SNA_OT_Reset_Z_Scale_C3816)
    bpy.utils.unregister_class(SNA_OT_Show_Ops_F6C25)
    bpy.utils.unregister_class(SNA_OT_Mirror_Empty_F8D10)
    bpy.utils.unregister_class(SNA_OT_Send_Selectedto_Backup_5Ac5A)
    bpy.utils.unregister_class(SNA_OT_Snap_To_Face_Preset_5Ffa6)
    bpy.utils.unregister_class(SNA_OT_Toggle_Show_Creases_48169)
    bpy.utils.unregister_class(SNA_OT_Toggle_Show_Sharps_28E50)
    bpy.utils.unregister_class(SNA_OT_Toggle_Show_Bevels_Cb2F7)
    bpy.utils.unregister_class(SNA_OT_Toggle_Show_Seams_7408D)
    bpy.utils.unregister_class(SNA_OT_Set_Shading_Matcap_E9F4F)
    bpy.utils.unregister_class(SNA_OT_Set_Shading_Flat_87Cbc)
    bpy.utils.unregister_class(SNA_OT_Set_Shading_Preview_9Ad3C)
    bpy.utils.unregister_class(SNA_OT_Special_Hide_Selected_1C458)
    bpy.utils.unregister_class(SNA_OT_Special_Show_All_7E124)
    bpy.utils.unregister_class(SNA_OT_Special_Hide_Unselected_29928)
    bpy.utils.unregister_class(SNA_OT_Toggle_Wireframe_C8C58)
    bpy.utils.unregister_class(SNA_OT_Duplicate_Send_To_Backup_8Be30)
    bpy.utils.unregister_class(SNA_PT_EDIT_TOOLS_00E1A)
    bpy.utils.unregister_class(SNA_PT_ITEM_INFO_68721)
    bpy.utils.unregister_class(SNA_PT_OBJECTTOOLS_73861)
    bpy.utils.unregister_class(SNA_PT_SETTINGS_PANEL_9ABCF)
    bpy.utils.unregister_class(SNA_MT_F2EBE)
    bpy.utils.unregister_class(SNA_OT_Face_Mode_44E6B)
    bpy.utils.unregister_class(SNA_OT_Vert_Mode_34Ed6)
    bpy.utils.unregister_class(SNA_OT_Edge_Mode_74D78)
    bpy.utils.unregister_class(SNA_MT_5FC8E)
