# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Compendium",
    "author" : "Ben Ikeler", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (2, 0, 1),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None
gen_functions = {'sna_foundbackupcollection': False, 'sna_moveobjectslist': [], }
mirrorempty = {'sna_objectname': '', 'sna_newempty': '', 'sna_foundobject': False, 'sna_modname': '', }


def find_user_keyconfig(key):
    km, kmi = addon_keymaps[key]
    for item in bpy.context.window_manager.keyconfigs.user.keymaps[km.name].keymap_items:
        found_item = False
        if kmi.idname == item.idname:
            found_item = True
            for name in dir(kmi.properties):
                if not name in ["bl_rna", "rna_type"] and not name[0] == "_":
                    if not kmi.properties[name] == item.properties[name]:
                        found_item = False
        if found_item:
            return item
    print(f"Couldn't find keymap item for {key}, using addon keymap instead. This won't be saved across sessions!")
    return kmi


movetocollection_s3_vars_0B530 = {'sna_objectstomove': [], }


def sna_fnmovetocollection_397D9_0B530(CollectionName):
    if (len(bpy.context.view_layer.objects.selected.values()) > 0):
        if property_exists("bpy.data.collections[CollectionName]", globals(), locals()):
            sna_fnlinkunlink_41AEA(CollectionName)
        else:
            collection_752A1 = bpy.data.collections.new(name=CollectionName, )
            bpy.context.scene.collection.children.link(child=collection_752A1, )
            sna_fnlinkunlink_41AEA(CollectionName)


def sna_fnlinkunlink_41AEA(CollectionName):
    movetocollection_s3_vars_0B530['sna_objectstomove'] = []
    for i_5B107 in range(len(bpy.context.view_layer.objects.selected)):
        movetocollection_s3_vars_0B530['sna_objectstomove'].append(bpy.context.view_layer.objects.selected[i_5B107])
    for i_18D5A in range(len(bpy.context.view_layer.objects.selected)):
        for i_BE9A3 in range(len(bpy.context.view_layer.objects.selected[i_18D5A].users_collection)):
            if (bpy.context.view_layer.objects.selected[i_18D5A].users_collection[i_BE9A3].name == CollectionName):
                movetocollection_s3_vars_0B530['sna_objectstomove'].remove(bpy.context.view_layer.objects.selected[i_18D5A])
    for i_EC7E0 in range(len(movetocollection_s3_vars_0B530['sna_objectstomove'])):
        for i_726C8 in range(len(movetocollection_s3_vars_0B530['sna_objectstomove'][i_EC7E0].users_collection)):
            movetocollection_s3_vars_0B530['sna_objectstomove'][i_EC7E0].users_collection[i_726C8].objects.unlink(object=movetocollection_s3_vars_0B530['sna_objectstomove'][i_EC7E0], )
    for i_9A186 in range(len(movetocollection_s3_vars_0B530['sna_objectstomove'])):
        bpy.data.collections[CollectionName].objects.link(object=movetocollection_s3_vars_0B530['sna_objectstomove'][i_9A186], )


def sna_getobjectproperty_427FF_8F820(ObjectName):
    return bpy.data.objects[ObjectName]


def sna_move_to_collection_ECC8E_92E25(Object, Collection):
    for i_BFDED in range(len(bpy.data.collections[Collection].objects)):
        if bpy.data.collections[Collection].objects[i_BFDED] == Object:
            return
        else:
            pass
    bpy.data.collections[Collection].objects.link(object=Object, )
    for i_E9673 in range(len(bpy.context.scene.collection.children)):
        if bpy.context.scene.collection.children[i_E9673].name != Collection:
            for i_11C41 in range(len(bpy.context.scene.collection.children[i_E9673].objects)):
                if bpy.context.scene.collection.children[i_E9673].objects[i_11C41] == Object:
                    bpy.context.scene.collection.children[i_E9673].objects.unlink(object=bpy.context.scene.collection.children[i_E9673].objects[i_11C41], )
                    break
                else:
                    pass
        else:
            pass
    for i_F2059 in range(len(bpy.context.scene.collection.objects)):
        if bpy.context.scene.collection.objects[i_F2059] == Object:
            bpy.context.scene.collection.objects.unlink(object=bpy.context.scene.collection.objects[i_F2059], )
            break
        else:
            pass


def sna_move_to_collection_ECC8E_FD59D(Object, Collection):
    for i_BFDED in range(len(bpy.data.collections[Collection].objects)):
        if bpy.data.collections[Collection].objects[i_BFDED] == Object:
            return
        else:
            pass
    bpy.data.collections[Collection].objects.link(object=Object, )
    for i_E9673 in range(len(bpy.context.scene.collection.children)):
        if bpy.context.scene.collection.children[i_E9673].name != Collection:
            for i_11C41 in range(len(bpy.context.scene.collection.children[i_E9673].objects)):
                if bpy.context.scene.collection.children[i_E9673].objects[i_11C41] == Object:
                    bpy.context.scene.collection.children[i_E9673].objects.unlink(object=bpy.context.scene.collection.children[i_E9673].objects[i_11C41], )
                    break
                else:
                    pass
        else:
            pass
    for i_F2059 in range(len(bpy.context.scene.collection.objects)):
        if bpy.context.scene.collection.objects[i_F2059] == Object:
            bpy.context.scene.collection.objects.unlink(object=bpy.context.scene.collection.objects[i_F2059], )
            break
        else:
            pass


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


class SNA_OT_Forgotten_Tools_Link_F9933(bpy.types.Operator):
    bl_idname = "sna.forgotten_tools_link_f9933"
    bl_label = "Forgotten Tools Link"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        exec('bpy.ops.wm.url_open(url="https://stanpancakes.gumroad.com/l/JJNfR")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Edge_Flow_Link_60D20(bpy.types.Operator):
    bl_idname = "sna.edge_flow_link_60d20"
    bl_label = "Edge Flow Link"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        exec('bpy.ops.wm.url_open(url="https://github.com/BenjaminSauder/EdgeFlow/releases")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_AddonPreferences_FEDC5(bpy.types.AddonPreferences):
    bl_idname = 'compendium'

    def draw(self, context):
        if not (False):
            layout = self.layout 
            layout.label(text='Keyboard Shortcuts', icon_value=0)
            layout.prop(find_user_keyconfig('951EF'), 'type', text='Compendium Pie Menu', full_event=True)
            row_21DE3 = layout.row(heading='', align=False)
            row_21DE3.alert = False
            row_21DE3.enabled = True
            row_21DE3.active = True
            row_21DE3.use_property_split = False
            row_21DE3.use_property_decorate = False
            row_21DE3.scale_x = 1.0
            row_21DE3.scale_y = 1.0
            row_21DE3.alignment = 'Left'.upper()
            row_21DE3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_21DE3.label(text='Mesh > (Shift E) Edge Crease?', icon_value=0)
            row_21DE3.prop(bpy.context.window_manager.keyconfigs.user.keymaps['Mesh'].keymap_items['transform.edge_crease'], 'active', text='', icon_value=0, emboss=False)
            layout.label(text='Addon Links:', icon_value=0)
            op = layout.operator('sna.forgotten_tools_link_f9933', text='Forgotten Tools Gumroad Link', icon_value=0, emboss=True, depress=False)
            op = layout.operator('sna.edge_flow_link_60d20', text='Edge Flow Github Link', icon_value=0, emboss=True, depress=False)


class SNA_MT_37755(bpy.types.Menu):
    bl_idname = "SNA_MT_37755"
    bl_label = "Compendium"

    @classmethod
    def poll(cls, context):
        return not ((not ('EDIT_MESH'==bpy.context.mode or 'OBJECT'==bpy.context.mode)))

    def draw(self, context):
        layout = self.layout.menu_pie()
        op = layout.operator('sna.set_orientation_global_0546f', text='Global', icon_value=0, emboss=True, depress=False)
        if 'OBJECT'==bpy.context.mode:
            row_3ACCD = layout.row(heading='', align=False)
            row_3ACCD.alert = False
            row_3ACCD.enabled = True
            row_3ACCD.active = True
            row_3ACCD.use_property_split = False
            row_3ACCD.use_property_decorate = False
            row_3ACCD.scale_x = 1.0
            row_3ACCD.scale_y = 1.0
            row_3ACCD.alignment = 'Expand'.upper()
            row_3ACCD.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            box_38599 = row_3ACCD.box()
            box_38599.alert = False
            box_38599.enabled = True
            box_38599.active = True
            box_38599.use_property_split = False
            box_38599.use_property_decorate = False
            box_38599.alignment = 'Expand'.upper()
            box_38599.scale_x = 1.0
            box_38599.scale_y = 1.0
            box_38599.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_AD1A5 = box_38599.column(heading='', align=False)
            col_AD1A5.alert = False
            col_AD1A5.enabled = True
            col_AD1A5.active = True
            col_AD1A5.use_property_split = False
            col_AD1A5.use_property_decorate = False
            col_AD1A5.scale_x = 1.0
            col_AD1A5.scale_y = 1.0
            col_AD1A5.alignment = 'Expand'.upper()
            col_AD1A5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_AD1A5.operator('sna.show_ops_579ea', text='', icon_value=(6 if bpy.context.scene.sna_showops else 4), emboss=bpy.context.scene.sna_showops, depress=bpy.context.scene.sna_showops)
            op = col_AD1A5.operator('object.hide_view_set', text='', icon_value=254, emboss=False, depress=True)
            op = col_AD1A5.operator('object.move_to_collection', text='', icon_value=250, emboss=False, depress=False)
            if bpy.context.scene.sna_showops:
                box_56651 = row_3ACCD.box()
                box_56651.alert = False
                box_56651.enabled = True
                box_56651.active = True
                box_56651.use_property_split = False
                box_56651.use_property_decorate = False
                box_56651.alignment = 'Expand'.upper()
                box_56651.scale_x = 1.0
                box_56651.scale_y = 1.0
                box_56651.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                col_EF514 = box_56651.column(heading='', align=True)
                col_EF514.alert = False
                col_EF514.enabled = True
                col_EF514.active = True
                col_EF514.use_property_split = False
                col_EF514.use_property_decorate = False
                col_EF514.scale_x = 1.0
                col_EF514.scale_y = 1.0
                col_EF514.alignment = 'Expand'.upper()
                col_EF514.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_36D9E = col_EF514.row(heading='', align=True)
                row_36D9E.alert = False
                row_36D9E.enabled = True
                row_36D9E.active = True
                row_36D9E.use_property_split = False
                row_36D9E.use_property_decorate = False
                row_36D9E.scale_x = 1.2000000476837158
                row_36D9E.scale_y = 1.2000000476837158
                row_36D9E.alignment = 'Expand'.upper()
                row_36D9E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                op = row_36D9E.operator('sna.mirror_empty_785c0', text='', icon_value=318, emboss=True, depress=False)
                op = row_36D9E.operator('object.modifier_add', text='', icon_value=446, emboss=True, depress=False)
                op.type = 'MIRROR'
                op = row_36D9E.operator('sna.send_to_backup_708c1', text='', icon_value=718, emboss=True, depress=False)
                row_D8FF3 = col_EF514.row(heading='', align=True)
                row_D8FF3.alert = False
                row_D8FF3.enabled = True
                row_D8FF3.active = True
                row_D8FF3.use_property_split = False
                row_D8FF3.use_property_decorate = False
                row_D8FF3.scale_x = 1.2000000476837158
                row_D8FF3.scale_y = 1.2000000476837158
                row_D8FF3.alignment = 'Expand'.upper()
                row_D8FF3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                op = row_D8FF3.operator('sna.zero_x_36fc3', text='', icon_value=331, emboss=True, depress=False)
                op = row_D8FF3.operator('sna.zero_y_241f7', text='', icon_value=332, emboss=True, depress=False)
                op = row_D8FF3.operator('sna.zero_z_014f0', text='', icon_value=333, emboss=True, depress=False)
        else:
            op = layout.operator('mesh.vert_connect_path', text='Join', icon_value=0, emboss=True, depress=False)
        op = layout.operator('sna.set_orientation_local_20ae4', text='Local', icon_value=0, emboss=True, depress=False)
        if 'OBJECT'==bpy.context.mode:
            layout.prop(bpy.data.scenes['Scene'].tool_settings, 'use_snap', text='', icon_value=0, emboss=True)
        else:
            split_7E95E = layout.split(factor=0.5, align=True)
            split_7E95E.alert = False
            split_7E95E.enabled = True
            split_7E95E.active = True
            split_7E95E.use_property_split = False
            split_7E95E.use_property_decorate = False
            split_7E95E.scale_x = 1.2000000476837158
            split_7E95E.scale_y = 1.5
            split_7E95E.alignment = 'Expand'.upper()
            split_7E95E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            split_7E95E.prop(bpy.context.scene.tool_settings, 'use_mesh_automerge', text='', icon_value=0, emboss=True)
            split_7E95E.prop(bpy.context.scene.tool_settings, 'use_proportional_edit', text='', icon_value=0, emboss=True)
        row_C83F5 = layout.row(heading='', align=True)
        row_C83F5.alert = False
        row_C83F5.enabled = True
        row_C83F5.active = True
        row_C83F5.use_property_split = False
        row_C83F5.use_property_decorate = False
        row_C83F5.scale_x = 1.2000000476837158
        row_C83F5.scale_y = 1.5
        row_C83F5.alignment = 'Expand'.upper()
        row_C83F5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_C83F5.operator('sna.transform_pivot_individual_5c668', text='', icon_value=553, emboss=True, depress=False)
        op = row_C83F5.operator('sna.transform_pivot_cursor_e69f0', text='', icon_value=552, emboss=True, depress=False)
        op = row_C83F5.operator('sna.transform_pivot_median_de0d8', text='', icon_value=554, emboss=True, depress=False)
        if 'OBJECT'==bpy.context.mode:
            layout.separator(factor=1.0)
        else:
            op = layout.operator('mesh.knife_tool', text='Knife', icon_value=0, emboss=True, depress=False)
            op.use_occlude_geometry = True
            op.xray = True
        if 'OBJECT'==bpy.context.mode:
            col_16E51 = layout.column(heading='', align=False)
            col_16E51.alert = False
            col_16E51.enabled = True
            col_16E51.active = True
            col_16E51.use_property_split = False
            col_16E51.use_property_decorate = False
            col_16E51.scale_x = 1.0
            col_16E51.scale_y = 1.5
            col_16E51.alignment = 'Expand'.upper()
            col_16E51.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_16E51.operator('object.hide_view_set', text='Hide Unselected', icon_value=253, emboss=True, depress=False)
            op.unselected = True
            op = col_16E51.operator('object.hide_view_clear', text='Show All', icon_value=254, emboss=True, depress=False)
        else:
            op = layout.operator('sna.set_orientation_normal_01f59', text='Normal', icon_value=0, emboss=True, depress=False)
        op = layout.operator('view3d.view_selected', text='', icon_value=624, emboss=True, depress=False)


class SNA_OT_Snap_To_Face_67E1E(bpy.types.Operator):
    bl_idname = "sna.snap_to_face_67e1e"
    bl_label = "Snap To Face"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_fnsetsnaptoface_7B181()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_OBJECT_TOOLS_4E8CE(bpy.types.Panel):
    bl_label = 'Object Tools'
    bl_idname = 'SNA_PT_OBJECT_TOOLS_4E8CE'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 1
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not (bpy.context.scene.sna_showtools and 'OBJECT'==bpy.context.mode)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_910F0 = layout.column(heading='', align=True)
        col_910F0.alert = False
        col_910F0.enabled = True
        col_910F0.active = True
        col_910F0.use_property_split = False
        col_910F0.use_property_decorate = False
        col_910F0.scale_x = 1.0
        col_910F0.scale_y = 1.100000023841858
        col_910F0.alignment = 'Expand'.upper()
        col_910F0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_910F0.operator('object.origin_set', text='Set Origin (Volume)', icon_value=0, emboss=True, depress=False)
        op.type = 'ORIGIN_CENTER_OF_VOLUME'
        op = col_910F0.operator('object.origin_set', text='Set Origin (Cursor)', icon_value=0, emboss=True, depress=False)
        op.type = 'ORIGIN_CURSOR'
        op = col_910F0.operator('object.convert', text='Convert To Mesh', icon_value=0, emboss=True, depress=False)
        op.target = 'MESH'


class SNA_PT_COMPENDIUM_7EA56(bpy.types.Panel):
    bl_label = 'Compendium'
    bl_idname = 'SNA_PT_COMPENDIUM_7EA56'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_84680 = layout.column(heading='', align=False)
        col_84680.alert = False
        col_84680.enabled = True
        col_84680.active = True
        col_84680.use_property_split = False
        col_84680.use_property_decorate = False
        col_84680.scale_x = 1.0
        col_84680.scale_y = 1.0
        col_84680.alignment = 'Expand'.upper()
        col_84680.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        split_95490 = col_84680.split(factor=0.5, align=True)
        split_95490.alert = False
        split_95490.enabled = True
        split_95490.active = True
        split_95490.use_property_split = False
        split_95490.use_property_decorate = False
        split_95490.scale_x = 1.0
        split_95490.scale_y = 1.0
        split_95490.alignment = 'Expand'.upper()
        split_95490.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = split_95490.operator('sna.toggletools_3347c', text='', icon_value=(159 if 'OBJECT'==bpy.context.mode else 131), emboss=True, depress=bpy.context.scene.sna_showtools)
        op = split_95490.operator('sna.toggleiteminfo_2f513', text='', icon_value=110, emboss=True, depress=bpy.context.scene.sna_showiteminfo)
        split_7FCD3 = col_84680.split(factor=0.5, align=True)
        split_7FCD3.alert = False
        split_7FCD3.enabled = True
        split_7FCD3.active = True
        split_7FCD3.use_property_split = False
        split_7FCD3.use_property_decorate = False
        split_7FCD3.scale_x = 1.0
        split_7FCD3.scale_y = 1.0
        split_7FCD3.alignment = 'Expand'.upper()
        split_7FCD3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = split_7FCD3.operator('sna.togglenumpad_bf0dc', text='', icon_value=291, emboss=True, depress=bpy.context.scene.sna_shownumpad)
        op = split_7FCD3.operator('sna.togglerendersettings_f2a23', text='', icon_value=117, emboss=True, depress=bpy.context.scene.sna_showrendersettings)


class SNA_OT_Togglerendersettings_F2A23(bpy.types.Operator):
    bl_idname = "sna.togglerendersettings_f2a23"
    bl_label = "ToggleRenderSettings"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showrendersettings = (not bpy.context.scene.sna_showrendersettings)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggleiteminfo_2F513(bpy.types.Operator):
    bl_idname = "sna.toggleiteminfo_2f513"
    bl_label = "ToggleItemInfo"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showiteminfo = (not bpy.context.scene.sna_showiteminfo)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Togglenumpad_Bf0Dc(bpy.types.Operator):
    bl_idname = "sna.togglenumpad_bf0dc"
    bl_label = "ToggleNumPad"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.scene.sna_shownumpad = (not bpy.context.scene.sna_shownumpad)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggletools_3347C(bpy.types.Operator):
    bl_idname = "sna.toggletools_3347c"
    bl_label = "ToggleTools"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showtools = (not bpy.context.scene.sna_showtools)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_SETTINGS_PANEL_133E0(bpy.types.Panel):
    bl_label = 'Settings Panel'
    bl_idname = 'SNA_PT_SETTINGS_PANEL_133E0'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not bpy.context.scene.sna_showrendersettings))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Compendium Shortcuts', icon_value=0)
        box_22726 = layout.box()
        box_22726.alert = False
        box_22726.enabled = True
        box_22726.active = True
        box_22726.use_property_split = False
        box_22726.use_property_decorate = False
        box_22726.alignment = 'Expand'.upper()
        box_22726.scale_x = 1.0
        box_22726.scale_y = 1.0
        box_22726.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        box_22726.prop(bpy.context.scene, 'sna_usecompendiumempty', text='Use Compendium Empty', icon_value=0, emboss=True)
        box_C9C94 = layout.box()
        box_C9C94.alert = False
        box_C9C94.enabled = True
        box_C9C94.active = True
        box_C9C94.use_property_split = False
        box_C9C94.use_property_decorate = False
        box_C9C94.alignment = 'Left'.upper()
        box_C9C94.scale_x = 1.0
        box_C9C94.scale_y = 1.0
        box_C9C94.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = box_C9C94.operator('sna.snap_to_face_67e1e', text='', icon_value=582, emboss=True, depress=False)
        layout.label(text='Rendering', icon_value=0)
        box_6D7AD = layout.box()
        box_6D7AD.alert = False
        box_6D7AD.enabled = True
        box_6D7AD.active = True
        box_6D7AD.use_property_split = False
        box_6D7AD.use_property_decorate = False
        box_6D7AD.alignment = 'Expand'.upper()
        box_6D7AD.scale_x = 1.0
        box_6D7AD.scale_y = 1.0
        box_6D7AD.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        box_6D7AD.prop(bpy.context.scene.render, 'film_transparent', text='Transparent BG', icon_value=0, emboss=True)
        if bpy.context.view_layer.objects.active:
            box_6D7AD.prop(bpy.context.view_layer.objects.active, 'show_wire', text='Display Wire', icon_value=0, emboss=True)


def sna_fnsetsnaptoface_7B181():
    bpy.context.tool_settings.snap_elements = bpy.context.scene.tool_settings.snap_elements = {'FACE'}
    bpy.context.scene.tool_settings.use_snap_rotate = True
    bpy.context.scene.tool_settings.use_snap_translate = True
    bpy.context.scene.tool_settings.use_snap_align_rotation = True
    bpy.context.scene.tool_settings.snap_target = 'CENTER'


def sna_fnseparatenew_FF6C9():
    bpy.ops.mesh.duplicate_move()
    bpy.ops.mesh.separate('INVOKE_DEFAULT', type='SELECTED')


def sna_fnsendtobackup_89B05():
    sna_fnmovetocollection_397D9_0B530('Backup Objects')


def sna_fnsetorientationglobal_3D348():
    bpy.data.scenes['Scene'].transform_orientation_slots[0].type = 'GLOBAL'


def sna_fnsetorientationlocal_7D745():
    bpy.data.scenes['Scene'].transform_orientation_slots[0].type = 'LOCAL'


class SNA_OT_Set_Orientation_Normal_01F59(bpy.types.Operator):
    bl_idname = "sna.set_orientation_normal_01f59"
    bl_label = "Set Orientation Normal"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_fnsetorientationnormal_C0B8E()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnsetorientationnormal_C0B8E():
    bpy.data.scenes['Scene'].transform_orientation_slots[0].type = 'NORMAL'


class SNA_OT_Set_Orientation_Local_20Ae4(bpy.types.Operator):
    bl_idname = "sna.set_orientation_local_20ae4"
    bl_label = "Set Orientation Local"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_fnsetorientationlocal_7D745()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Testoperator_B9Ae4(bpy.types.Operator):
    bl_idname = "sna.testoperator_b9ae4"
    bl_label = "TestOperator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Orientation_Global_0546F(bpy.types.Operator):
    bl_idname = "sna.set_orientation_global_0546f"
    bl_label = "Set Orientation Global"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_fnsetorientationglobal_3D348()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Transform_Pivot_Cursor_E69F0(bpy.types.Operator):
    bl_idname = "sna.transform_pivot_cursor_e69f0"
    bl_label = "Transform Pivot Cursor"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        exec("bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Transform_Pivot_Individual_5C668(bpy.types.Operator):
    bl_idname = "sna.transform_pivot_individual_5c668"
    bl_label = "Transform Pivot Individual"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        exec("bpy.context.scene.tool_settings.transform_pivot_point = 'INDIVIDUAL_ORIGINS'")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Transform_Pivot_Median_De0D8(bpy.types.Operator):
    bl_idname = "sna.transform_pivot_median_de0d8"
    bl_label = "Transform Pivot Median"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        exec("bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_X_36Fc3(bpy.types.Operator):
    bl_idname = "sna.zero_x_36fc3"
    bl_label = "Zero X"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.location = (0.0, bpy.context.view_layer.objects.active.location[1], bpy.context.view_layer.objects.active.location[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_Z_014F0(bpy.types.Operator):
    bl_idname = "sna.zero_z_014f0"
    bl_label = "Zero Z"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.location = (bpy.context.view_layer.objects.active.location[0], bpy.context.view_layer.objects.active.location[1], 0.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_Y_241F7(bpy.types.Operator):
    bl_idname = "sna.zero_y_241f7"
    bl_label = "Zero Y"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.location = (bpy.context.view_layer.objects.active.location[0], 0.0, bpy.context.view_layer.objects.active.location[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_X_Rot_Aee95(bpy.types.Operator):
    bl_idname = "sna.zero_x_rot_aee95"
    bl_label = "Zero X Rot"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.rotation_euler = (0.0, bpy.context.view_layer.objects.active.rotation_euler[1], bpy.context.view_layer.objects.active.rotation_euler[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_Y_Rot_5B61A(bpy.types.Operator):
    bl_idname = "sna.zero_y_rot_5b61a"
    bl_label = "Zero Y Rot"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.rotation_euler = (bpy.context.view_layer.objects.active.rotation_euler[0], 0.0, bpy.context.view_layer.objects.active.rotation_euler[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Zero_Z_Rot_477Bd(bpy.types.Operator):
    bl_idname = "sna.zero_z_rot_477bd"
    bl_label = "Zero Z Rot"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.rotation_euler = (bpy.context.view_layer.objects.active.rotation_euler[0], bpy.context.view_layer.objects.active.rotation_euler[1], 0.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Show_Ops_579Ea(bpy.types.Operator):
    bl_idname = "sna.show_ops_579ea"
    bl_label = "Show Ops"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showops = (not bpy.context.scene.sna_showops)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_X_Scale_690Ab(bpy.types.Operator):
    bl_idname = "sna.reset_x_scale_690ab"
    bl_label = "Reset X Scale"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.scale = (1.0, bpy.context.view_layer.objects.active.scale[1], bpy.context.view_layer.objects.active.scale[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Y_Scale_470Ec(bpy.types.Operator):
    bl_idname = "sna.reset_y_scale_470ec"
    bl_label = "Reset Y Scale"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.scale = (bpy.context.view_layer.objects.active.scale[0], 1.0, bpy.context.view_layer.objects.active.scale[2])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Z_Scale_6Eca8(bpy.types.Operator):
    bl_idname = "sna.reset_z_scale_6eca8"
    bl_label = "Reset Z Scale"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.scale = (bpy.context.view_layer.objects.active.scale[0], bpy.context.view_layer.objects.active.scale[1], 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Mirror_Empty_785C0(bpy.types.Operator):
    bl_idname = "sna.mirror_empty_785c0"
    bl_label = "Mirror Empty"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_fnmirrorcompempty_42F20()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Separate_New_05008(bpy.types.Operator):
    bl_idname = "sna.separate_new_05008"
    bl_label = "Separate New"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_fnseparatenew_FF6C9()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Send_To_Backup_708C1(bpy.types.Operator):
    bl_idname = "sna.send_to_backup_708c1"
    bl_label = "Send To Backup"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_fnsendtobackup_89B05()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnfindempty_44FF6():
    for i_657D3 in range(len(bpy.data.objects)):
        if (bpy.data.objects[i_657D3].name == 'CompendiumEmpty'):
            mirrorempty['sna_foundobject'] = True
            break
    if mirrorempty['sna_foundobject']:
        sna_fnaddmirroremptymod_F745C('CompendiumEmpty')
    else:
        sna_fncreateempty_B2706()


def sna_fncreateempty_B2706():
    bpy.ops.object.empty_add('INVOKE_DEFAULT', type='PLAIN_AXES', radius=1.0, align='WORLD', location=(0.0, 0.0, 0.0), rotation=(0.0, 0.0, 0.0), scale=(1.0, 1.0, 1.0))
    bpy.context.view_layer.objects.active.name = 'CompendiumEmpty'
    mirrorempty['sna_newempty'] = bpy.context.view_layer.objects.active.name
    sna_fnaddmirroremptymod_F745C(mirrorempty['sna_newempty'])


def sna_fnaddmirroremptymod_F745C(EmptyName):
    modifier_71071 = bpy.data.objects[mirrorempty['sna_objectname']].modifiers.new(name='Mirror Empty Mod', type='MIRROR', )
    output_0_8f820 = sna_getobjectproperty_427FF_8F820(EmptyName)
    modifier_71071.mirror_object = output_0_8f820


def sna_fnmirrorcompempty_42F20():
    if bpy.context.view_layer.objects.selected:
        mirrorempty['sna_objectname'] = bpy.context.view_layer.objects.active.name
        if bpy.context.scene.sna_usecompendiumempty:
            sna_fnfindempty_44FF6()
        else:
            sna_fncreateempty_B2706()


class SNA_OT_Move_Menu__E0845(bpy.types.Operator):
    bl_idname = "sna.move_menu__e0845"
    bl_label = "Move Menu +"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        split_B66AB = layout.split(factor=0.75, align=True)
        split_B66AB.alert = False
        split_B66AB.enabled = True
        split_B66AB.use_property_split = False
        split_B66AB.use_property_decorate = False
        split_B66AB.scale_x = 1.0
        split_B66AB.scale_y = 1.0
        split_B66AB.alignment = 'Expand'.upper()
        layout.prop(bpy.context.scene, 'sna_newcollectionname', text='', icon_value=0, emboss=True)
        op = layout.operator('sna.move_to_new_collection_13f48', text='', icon_value=31, emboss=True, depress=False)
        for i_9EFB9 in range(len(bpy.context.scene.collection.children)):
            split_746DC = layout.split(factor=0.75, align=True)
            split_746DC.alert = False
            split_746DC.enabled = True
            split_746DC.use_property_split = False
            split_746DC.use_property_decorate = False
            split_746DC.scale_x = 1.0
            split_746DC.scale_y = 1.0
            split_746DC.alignment = 'Expand'.upper()
            op = layout.operator('sna.move_to_collection_0ff1c', text=bpy.context.scene.collection.children[i_9EFB9].name, icon_value=0, emboss=True, depress=False)
            op.sna_collection_name = bpy.context.scene.collection.children[i_9EFB9].name
            op = layout.operator('sna.set_collection_visibility_05974', text='', icon_value=(253 if bpy.context.scene.collection.children[i_9EFB9].hide_viewport else 254), emboss=True, depress=False)
            op.sna_collection_name = bpy.context.scene.collection.children[i_9EFB9].name

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=250)


class SNA_OT_Move_To_New_Collection_13F48(bpy.types.Operator):
    bl_idname = "sna.move_to_new_collection_13f48"
    bl_label = "Move to New Collection"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        collection_1155E = bpy.context.blend_data.collections.new(name=bpy.context.scene.sna_newcollectionname, )
        bpy.context.scene.collection.children.link(child=collection_1155E, )
        for i_73911 in range(len(bpy.context.view_layer.objects.selected)):
            sna_move_to_collection_ECC8E_92E25(bpy.context.view_layer.objects.selected[i_73911], collection_1155E.name)
        bpy.context.scene.sna_newcollectionname = ''
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Collection_Visibility_05974(bpy.types.Operator):
    bl_idname = "sna.set_collection_visibility_05974"
    bl_label = "Set Collection Visibility"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_collection_name: bpy.props.StringProperty(name='Collection Name', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.data.collections[self.sna_collection_name].hide_viewport = (not bpy.data.collections[self.sna_collection_name].hide_viewport)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Move_To_Collection_0Ff1C(bpy.types.Operator):
    bl_idname = "sna.move_to_collection_0ff1c"
    bl_label = "Move To Collection"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_collection_name: bpy.props.StringProperty(name='Collection Name', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        for i_53093 in range(len(bpy.context.view_layer.objects.selected)):
            sna_move_to_collection_ECC8E_FD59D(bpy.context.view_layer.objects.selected[i_53093], self.sna_collection_name)
            print(bpy.context.view_layer.objects.selected[i_53093].name)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_EDIT_TOOLS_A3727(bpy.types.Panel):
    bl_label = 'Edit Tools'
    bl_idname = 'SNA_PT_EDIT_TOOLS_A3727'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 1
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not (bpy.context.scene.sna_showtools and 'EDIT_MESH'==bpy.context.mode)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_7CE96 = layout.column(heading='', align=False)
        col_7CE96.alert = False
        col_7CE96.enabled = True
        col_7CE96.active = True
        col_7CE96.use_property_split = False
        col_7CE96.use_property_decorate = False
        col_7CE96.scale_x = 1.0
        col_7CE96.scale_y = 1.100000023841858
        col_7CE96.alignment = 'Expand'.upper()
        col_7CE96.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_7CE96.operator('sna.separate_new_05008', text='Separate New', icon_value=0, emboss=True, depress=False)
        if property_exists("bpy.context.preferences.addons['forgotten_tools']", globals(), locals()):
            col_16C86 = col_7CE96.column(heading='', align=True)
            col_16C86.alert = False
            col_16C86.enabled = True
            col_16C86.active = True
            col_16C86.use_property_split = False
            col_16C86.use_property_decorate = False
            col_16C86.scale_x = 1.0
            col_16C86.scale_y = 1.100000023841858
            col_16C86.alignment = 'Expand'.upper()
            col_16C86.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_16C86.label(text='Forgotten Tools', icon_value=0)
            op = col_16C86.operator('forgotten.mesh_straighten', text='Straighten', icon_value=0, emboss=True, depress=False)
            op = col_16C86.operator('forgotten.mesh_hinge', text='Hinge', icon_value=0, emboss=True, depress=False)
        if property_exists("bpy.context.preferences.addons['mesh_looptools']", globals(), locals()):
            col_5763B = col_7CE96.column(heading='', align=True)
            col_5763B.alert = False
            col_5763B.enabled = True
            col_5763B.active = True
            col_5763B.use_property_split = False
            col_5763B.use_property_decorate = False
            col_5763B.scale_x = 1.0
            col_5763B.scale_y = 1.100000023841858
            col_5763B.alignment = 'Expand'.upper()
            col_5763B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_5763B.label(text='Loop Tools', icon_value=0)
            op = col_5763B.operator('mesh.looptools_relax', text='Relax', icon_value=0, emboss=True, depress=False)
            op.regular = True
            op = col_5763B.operator('mesh.looptools_flatten', text='Flatten', icon_value=0, emboss=True, depress=False)
            op.influence = 100.0
            op = col_5763B.operator('mesh.looptools_circle', text='Circle', icon_value=0, emboss=True, depress=False)
            op.fit = 'best'
            op.flatten = True
            op.influence = 100.0
            op.radius = 1.0
            op.regular = True
        if property_exists("bpy.context.preferences.addons['EdgeFlow']", globals(), locals()):
            col_5326A = col_7CE96.column(heading='', align=True)
            col_5326A.alert = False
            col_5326A.enabled = True
            col_5326A.active = True
            col_5326A.use_property_split = False
            col_5326A.use_property_decorate = False
            col_5326A.scale_x = 1.0
            col_5326A.scale_y = 1.100000023841858
            col_5326A.alignment = 'Expand'.upper()
            col_5326A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_5326A.label(text='Edge Flow', icon_value=0)
            op = col_5326A.operator('mesh.set_edge_flow', text='Set Flow', icon_value=0, emboss=True, depress=False)
            op.tension = 180
            op.iterations = 1
            op = col_5326A.operator('mesh.set_edge_linear', text='Set Linear', icon_value=0, emboss=True, depress=False)


class SNA_PT_ITEM_INFO_82ECB(bpy.types.Panel):
    bl_label = 'Item Info'
    bl_idname = 'SNA_PT_ITEM_INFO_82ECB'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not bpy.context.scene.sna_showiteminfo))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if bpy.context.view_layer.objects.active:
            col_E0112 = layout.column(heading='', align=False)
            col_E0112.alert = False
            col_E0112.enabled = True
            col_E0112.active = True
            col_E0112.use_property_split = False
            col_E0112.use_property_decorate = False
            col_E0112.scale_x = 1.0
            col_E0112.scale_y = 1.0
            col_E0112.alignment = 'Expand'.upper()
            col_E0112.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_E0112.label(text='Location', icon_value=0)
            split_4DAE0 = col_E0112.split(factor=0.8388888835906982, align=True)
            split_4DAE0.alert = False
            split_4DAE0.enabled = True
            split_4DAE0.active = True
            split_4DAE0.use_property_split = False
            split_4DAE0.use_property_decorate = False
            split_4DAE0.scale_x = 1.0
            split_4DAE0.scale_y = 1.100000023841858
            split_4DAE0.alignment = 'Expand'.upper()
            split_4DAE0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_4C446 = split_4DAE0.column(heading='', align=True)
            col_4C446.alert = False
            col_4C446.enabled = True
            col_4C446.active = True
            col_4C446.use_property_split = False
            col_4C446.use_property_decorate = False
            col_4C446.scale_x = 1.0
            col_4C446.scale_y = 1.0
            col_4C446.alignment = 'Expand'.upper()
            col_4C446.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_4C446.prop(bpy.context.view_layer.objects.active, 'location', text='', icon_value=0, emboss=True)
            col_F956E = split_4DAE0.column(heading='', align=True)
            col_F956E.alert = False
            col_F956E.enabled = True
            col_F956E.active = True
            col_F956E.use_property_split = False
            col_F956E.use_property_decorate = False
            col_F956E.scale_x = 1.0
            col_F956E.scale_y = 1.0
            col_F956E.alignment = 'Expand'.upper()
            col_F956E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_F956E.operator('sna.zero_x_36fc3', text='', icon_value=643, emboss=True, depress=False)
            op = col_F956E.operator('sna.zero_y_241f7', text='', icon_value=643, emboss=True, depress=False)
            op = col_F956E.operator('sna.zero_z_014f0', text='', icon_value=643, emboss=True, depress=False)
            col_E0112.label(text='Rotation', icon_value=0)
            split_7E5CF = col_E0112.split(factor=0.8388888835906982, align=True)
            split_7E5CF.alert = False
            split_7E5CF.enabled = True
            split_7E5CF.active = True
            split_7E5CF.use_property_split = False
            split_7E5CF.use_property_decorate = False
            split_7E5CF.scale_x = 1.0
            split_7E5CF.scale_y = 1.100000023841858
            split_7E5CF.alignment = 'Expand'.upper()
            split_7E5CF.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_BA114 = split_7E5CF.column(heading='', align=True)
            col_BA114.alert = False
            col_BA114.enabled = True
            col_BA114.active = True
            col_BA114.use_property_split = False
            col_BA114.use_property_decorate = False
            col_BA114.scale_x = 1.0
            col_BA114.scale_y = 1.0
            col_BA114.alignment = 'Expand'.upper()
            col_BA114.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_BA114.prop(bpy.context.view_layer.objects.active, 'rotation_euler', text='', icon_value=0, emboss=True)
            col_7BF23 = split_7E5CF.column(heading='', align=True)
            col_7BF23.alert = False
            col_7BF23.enabled = True
            col_7BF23.active = True
            col_7BF23.use_property_split = False
            col_7BF23.use_property_decorate = False
            col_7BF23.scale_x = 1.0
            col_7BF23.scale_y = 1.0
            col_7BF23.alignment = 'Expand'.upper()
            col_7BF23.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_7BF23.operator('sna.zero_x_rot_aee95', text='', icon_value=643, emboss=True, depress=False)
            op = col_7BF23.operator('sna.zero_y_rot_5b61a', text='', icon_value=643, emboss=True, depress=False)
            op = col_7BF23.operator('sna.zero_z_rot_477bd', text='', icon_value=643, emboss=True, depress=False)
            col_E0112.label(text='Scale', icon_value=0)
            split_C0290 = col_E0112.split(factor=0.8388888835906982, align=True)
            split_C0290.alert = False
            split_C0290.enabled = True
            split_C0290.active = True
            split_C0290.use_property_split = False
            split_C0290.use_property_decorate = False
            split_C0290.scale_x = 1.0
            split_C0290.scale_y = 1.100000023841858
            split_C0290.alignment = 'Expand'.upper()
            split_C0290.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_C98EC = split_C0290.column(heading='', align=True)
            col_C98EC.alert = False
            col_C98EC.enabled = True
            col_C98EC.active = True
            col_C98EC.use_property_split = False
            col_C98EC.use_property_decorate = False
            col_C98EC.scale_x = 1.0
            col_C98EC.scale_y = 1.0
            col_C98EC.alignment = 'Expand'.upper()
            col_C98EC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_C98EC.prop(bpy.context.view_layer.objects.active, 'scale', text='', icon_value=0, emboss=True)
            col_E3227 = split_C0290.column(heading='', align=True)
            col_E3227.alert = False
            col_E3227.enabled = True
            col_E3227.active = True
            col_E3227.use_property_split = False
            col_E3227.use_property_decorate = False
            col_E3227.scale_x = 1.0
            col_E3227.scale_y = 1.0
            col_E3227.alignment = 'Expand'.upper()
            col_E3227.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_E3227.operator('sna.reset_x_scale_690ab', text='', icon_value=643, emboss=True, depress=False)
            op = col_E3227.operator('sna.reset_y_scale_470ec', text='', icon_value=643, emboss=True, depress=False)
            op = col_E3227.operator('sna.reset_z_scale_6eca8', text='', icon_value=643, emboss=True, depress=False)
        else:
            layout.label(text='No Active Item', icon_value=0)


class SNA_PT_NUMBER_PAD_1B457(bpy.types.Panel):
    bl_label = 'Number Pad'
    bl_idname = 'SNA_PT_NUMBER_PAD_1B457'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not bpy.context.scene.sna_shownumpad))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Viewpoint', icon_value=0)
        row_AC5C7 = layout.row(heading='', align=True)
        row_AC5C7.alert = False
        row_AC5C7.enabled = True
        row_AC5C7.active = True
        row_AC5C7.use_property_split = False
        row_AC5C7.use_property_decorate = False
        row_AC5C7.scale_x = 1.0
        row_AC5C7.scale_y = 1.0
        row_AC5C7.alignment = 'Expand'.upper()
        row_AC5C7.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_F5CA7 = row_AC5C7.column(heading='', align=True)
        col_F5CA7.alert = False
        col_F5CA7.enabled = True
        col_F5CA7.active = True
        col_F5CA7.use_property_split = False
        col_F5CA7.use_property_decorate = False
        col_F5CA7.scale_x = 1.0
        col_F5CA7.scale_y = 1.0
        col_F5CA7.alignment = 'Expand'.upper()
        col_F5CA7.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_F5CA7.operator('view3d.view_axis', text='Top', icon_value=0, emboss=True, depress=False)
        op.type = 'TOP'
        op = col_F5CA7.operator('view3d.view_axis', text='Left', icon_value=0, emboss=True, depress=False)
        op.type = 'LEFT'
        op = col_F5CA7.operator('view3d.view_axis', text='Front', icon_value=0, emboss=True, depress=False)
        op.type = 'FRONT'
        col_B4A8D = row_AC5C7.column(heading='', align=True)
        col_B4A8D.alert = False
        col_B4A8D.enabled = True
        col_B4A8D.active = True
        col_B4A8D.use_property_split = False
        col_B4A8D.use_property_decorate = False
        col_B4A8D.scale_x = 1.0
        col_B4A8D.scale_y = 1.0
        col_B4A8D.alignment = 'Expand'.upper()
        col_B4A8D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_B4A8D.operator('view3d.view_axis', text='Bottom', icon_value=0, emboss=True, depress=False)
        op.type = 'BOTTOM'
        op = col_B4A8D.operator('view3d.view_axis', text='Right', icon_value=0, emboss=True, depress=False)
        op.type = 'RIGHT'
        op = col_B4A8D.operator('view3d.view_axis', text='Back', icon_value=0, emboss=True, depress=False)
        op.type = 'BACK'
        layout.label(text='Align View', icon_value=0)
        row_55660 = layout.row(heading='', align=True)
        row_55660.alert = False
        row_55660.enabled = True
        row_55660.active = True
        row_55660.use_property_split = False
        row_55660.use_property_decorate = False
        row_55660.scale_x = 1.0
        row_55660.scale_y = 1.0
        row_55660.alignment = 'Expand'.upper()
        row_55660.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_3162A = row_55660.column(heading='', align=True)
        col_3162A.alert = False
        col_3162A.enabled = True
        col_3162A.active = True
        col_3162A.use_property_split = False
        col_3162A.use_property_decorate = False
        col_3162A.scale_x = 1.0
        col_3162A.scale_y = 1.0
        col_3162A.alignment = 'Expand'.upper()
        col_3162A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_3162A.operator('view3d.view_axis', text='Top', icon_value=0, emboss=True, depress=False)
        op.type = 'TOP'
        op.align_active = True
        op = col_3162A.operator('view3d.view_axis', text='Left', icon_value=0, emboss=True, depress=False)
        op.type = 'LEFT'
        op.align_active = True
        op = col_3162A.operator('view3d.view_axis', text='Front', icon_value=0, emboss=True, depress=False)
        op.type = 'FRONT'
        op.align_active = True
        col_4E69B = row_55660.column(heading='', align=True)
        col_4E69B.alert = False
        col_4E69B.enabled = True
        col_4E69B.active = True
        col_4E69B.use_property_split = False
        col_4E69B.use_property_decorate = False
        col_4E69B.scale_x = 1.0
        col_4E69B.scale_y = 1.0
        col_4E69B.alignment = 'Expand'.upper()
        col_4E69B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_4E69B.operator('view3d.view_axis', text='Bottom', icon_value=0, emboss=True, depress=False)
        op.type = 'BOTTOM'
        op.align_active = True
        op = col_4E69B.operator('view3d.view_axis', text='Right', icon_value=0, emboss=True, depress=False)
        op.type = 'RIGHT'
        op.align_active = True
        op = col_4E69B.operator('view3d.view_axis', text='Back', icon_value=0, emboss=True, depress=False)
        op.type = 'BACK'
        op.align_active = True
        split_B5407 = layout.split(factor=0.5, align=True)
        split_B5407.alert = False
        split_B5407.enabled = True
        split_B5407.active = True
        split_B5407.use_property_split = False
        split_B5407.use_property_decorate = False
        split_B5407.scale_x = 1.0
        split_B5407.scale_y = 1.2000000476837158
        split_B5407.alignment = 'Expand'.upper()
        split_B5407.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = split_B5407.operator('view3d.view_camera', text='', icon_value=416, emboss=True, depress=False)
        op = split_B5407.operator('view3d.view_persportho', text='PH', icon_value=0, emboss=True, depress=False)
        split_F0D83 = layout.split(factor=1.0, align=True)
        split_F0D83.alert = False
        split_F0D83.enabled = True
        split_F0D83.active = True
        split_F0D83.use_property_split = False
        split_F0D83.use_property_decorate = False
        split_F0D83.scale_x = 1.0
        split_F0D83.scale_y = 1.2000000476837158
        split_F0D83.alignment = 'Expand'.upper()
        split_F0D83.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = split_F0D83.operator('view3d.view_persportho', text='Perspective', icon_value=775, emboss=True, depress=False)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_newcollectionname = bpy.props.StringProperty(name='NewCollectionName', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_showtools = bpy.props.BoolProperty(name='ShowTools', description='', default=True)
    bpy.types.Scene.sna_showrendersettings = bpy.props.BoolProperty(name='ShowRenderSettings', description='', default=False)
    bpy.types.Scene.sna_shownumpad = bpy.props.BoolProperty(name='ShowNumPad', description='', default=False)
    bpy.types.Scene.sna_showiteminfo = bpy.props.BoolProperty(name='ShowItemInfo', description='', default=False)
    bpy.types.Scene.sna_showops = bpy.props.BoolProperty(name='ShowOps', description='', default=False)
    bpy.types.Scene.sna_usecompendiumempty = bpy.props.BoolProperty(name='UseCompendiumEmpty', description='', default=True)
    bpy.utils.register_class(SNA_OT_Forgotten_Tools_Link_F9933)
    bpy.utils.register_class(SNA_OT_Edge_Flow_Link_60D20)
    bpy.utils.register_class(SNA_AddonPreferences_FEDC5)
    bpy.utils.register_class(SNA_MT_37755)
    bpy.utils.register_class(SNA_OT_Snap_To_Face_67E1E)
    bpy.utils.register_class(SNA_PT_OBJECT_TOOLS_4E8CE)
    bpy.utils.register_class(SNA_PT_COMPENDIUM_7EA56)
    bpy.utils.register_class(SNA_OT_Togglerendersettings_F2A23)
    bpy.utils.register_class(SNA_OT_Toggleiteminfo_2F513)
    bpy.utils.register_class(SNA_OT_Togglenumpad_Bf0Dc)
    bpy.utils.register_class(SNA_OT_Toggletools_3347C)
    bpy.utils.register_class(SNA_PT_SETTINGS_PANEL_133E0)
    bpy.utils.register_class(SNA_OT_Set_Orientation_Normal_01F59)
    bpy.utils.register_class(SNA_OT_Set_Orientation_Local_20Ae4)
    bpy.utils.register_class(SNA_OT_Testoperator_B9Ae4)
    bpy.utils.register_class(SNA_OT_Set_Orientation_Global_0546F)
    bpy.utils.register_class(SNA_OT_Transform_Pivot_Cursor_E69F0)
    bpy.utils.register_class(SNA_OT_Transform_Pivot_Individual_5C668)
    bpy.utils.register_class(SNA_OT_Transform_Pivot_Median_De0D8)
    bpy.utils.register_class(SNA_OT_Zero_X_36Fc3)
    bpy.utils.register_class(SNA_OT_Zero_Z_014F0)
    bpy.utils.register_class(SNA_OT_Zero_Y_241F7)
    bpy.utils.register_class(SNA_OT_Zero_X_Rot_Aee95)
    bpy.utils.register_class(SNA_OT_Zero_Y_Rot_5B61A)
    bpy.utils.register_class(SNA_OT_Zero_Z_Rot_477Bd)
    bpy.utils.register_class(SNA_OT_Show_Ops_579Ea)
    bpy.utils.register_class(SNA_OT_Reset_X_Scale_690Ab)
    bpy.utils.register_class(SNA_OT_Reset_Y_Scale_470Ec)
    bpy.utils.register_class(SNA_OT_Reset_Z_Scale_6Eca8)
    bpy.utils.register_class(SNA_OT_Mirror_Empty_785C0)
    bpy.utils.register_class(SNA_OT_Separate_New_05008)
    bpy.utils.register_class(SNA_OT_Send_To_Backup_708C1)
    bpy.utils.register_class(SNA_OT_Move_Menu__E0845)
    bpy.utils.register_class(SNA_OT_Move_To_New_Collection_13F48)
    bpy.utils.register_class(SNA_OT_Set_Collection_Visibility_05974)
    bpy.utils.register_class(SNA_OT_Move_To_Collection_0Ff1C)
    bpy.utils.register_class(SNA_PT_EDIT_TOOLS_A3727)
    bpy.utils.register_class(SNA_PT_ITEM_INFO_82ECB)
    bpy.utils.register_class(SNA_PT_NUMBER_PAD_1B457)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'E', 'PRESS',
        ctrl=False, alt=False, shift=True, repeat=False)
    kmi.properties.name = 'SNA_MT_37755'
    addon_keymaps['951EF'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_usecompendiumempty
    del bpy.types.Scene.sna_showops
    del bpy.types.Scene.sna_showiteminfo
    del bpy.types.Scene.sna_shownumpad
    del bpy.types.Scene.sna_showrendersettings
    del bpy.types.Scene.sna_showtools
    del bpy.types.Scene.sna_newcollectionname
    bpy.utils.unregister_class(SNA_OT_Forgotten_Tools_Link_F9933)
    bpy.utils.unregister_class(SNA_OT_Edge_Flow_Link_60D20)
    bpy.utils.unregister_class(SNA_AddonPreferences_FEDC5)
    bpy.utils.unregister_class(SNA_MT_37755)
    bpy.utils.unregister_class(SNA_OT_Snap_To_Face_67E1E)
    bpy.utils.unregister_class(SNA_PT_OBJECT_TOOLS_4E8CE)
    bpy.utils.unregister_class(SNA_PT_COMPENDIUM_7EA56)
    bpy.utils.unregister_class(SNA_OT_Togglerendersettings_F2A23)
    bpy.utils.unregister_class(SNA_OT_Toggleiteminfo_2F513)
    bpy.utils.unregister_class(SNA_OT_Togglenumpad_Bf0Dc)
    bpy.utils.unregister_class(SNA_OT_Toggletools_3347C)
    bpy.utils.unregister_class(SNA_PT_SETTINGS_PANEL_133E0)
    bpy.utils.unregister_class(SNA_OT_Set_Orientation_Normal_01F59)
    bpy.utils.unregister_class(SNA_OT_Set_Orientation_Local_20Ae4)
    bpy.utils.unregister_class(SNA_OT_Testoperator_B9Ae4)
    bpy.utils.unregister_class(SNA_OT_Set_Orientation_Global_0546F)
    bpy.utils.unregister_class(SNA_OT_Transform_Pivot_Cursor_E69F0)
    bpy.utils.unregister_class(SNA_OT_Transform_Pivot_Individual_5C668)
    bpy.utils.unregister_class(SNA_OT_Transform_Pivot_Median_De0D8)
    bpy.utils.unregister_class(SNA_OT_Zero_X_36Fc3)
    bpy.utils.unregister_class(SNA_OT_Zero_Z_014F0)
    bpy.utils.unregister_class(SNA_OT_Zero_Y_241F7)
    bpy.utils.unregister_class(SNA_OT_Zero_X_Rot_Aee95)
    bpy.utils.unregister_class(SNA_OT_Zero_Y_Rot_5B61A)
    bpy.utils.unregister_class(SNA_OT_Zero_Z_Rot_477Bd)
    bpy.utils.unregister_class(SNA_OT_Show_Ops_579Ea)
    bpy.utils.unregister_class(SNA_OT_Reset_X_Scale_690Ab)
    bpy.utils.unregister_class(SNA_OT_Reset_Y_Scale_470Ec)
    bpy.utils.unregister_class(SNA_OT_Reset_Z_Scale_6Eca8)
    bpy.utils.unregister_class(SNA_OT_Mirror_Empty_785C0)
    bpy.utils.unregister_class(SNA_OT_Separate_New_05008)
    bpy.utils.unregister_class(SNA_OT_Send_To_Backup_708C1)
    bpy.utils.unregister_class(SNA_OT_Move_Menu__E0845)
    bpy.utils.unregister_class(SNA_OT_Move_To_New_Collection_13F48)
    bpy.utils.unregister_class(SNA_OT_Set_Collection_Visibility_05974)
    bpy.utils.unregister_class(SNA_OT_Move_To_Collection_0Ff1C)
    bpy.utils.unregister_class(SNA_PT_EDIT_TOOLS_A3727)
    bpy.utils.unregister_class(SNA_PT_ITEM_INFO_82ECB)
    bpy.utils.unregister_class(SNA_PT_NUMBER_PAD_1B457)
